package com.example.data.repositories

import android.util.Log
import com.example.data.models.Family
import com.example.data.models.UserRole
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FamilyRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "FamilyRepository"
        const val COLLECTION_FAMILIES = "families"
        const val COLLECTION_COUNTERS = "counters"
        const val DOC_FAMILY_COUNTER = "family_code"
        const val COLLECTION_FAMILY_COUNTERS = "family_counters"
    }

    /**
     * Creates a new family using an atomic Firestore transaction.
     * Generates FAM-001, FAM-002, etc. and initializes corresponding family_counters document.
     * Strictly enforces case-insensitive uniqueness of familyName and familyCode.
     */
    suspend fun createFamily(familyName: String, user: String): Result<Family> {
        return try {
            val trimmedName = familyName.trim()
            if (trimmedName.isBlank()) {
                return Result.failure(Exception("Nama Family tidak boleh kosong"))
            }

            // Check if family name already exists (case-insensitive)
            val allFamiliesSnap = db.collection(COLLECTION_FAMILIES).get().await()
            val existingFamilies = allFamiliesSnap.documents.mapNotNull { it.toObject(Family::class.java) }
            val nameDuplicate = existingFamilies.any { it.familyName.equals(trimmedName, ignoreCase = true) }
            if (nameDuplicate) {
                return Result.failure(Exception("Nama Family '$trimmedName' sudah digunakan (Family Name harus unik)"))
            }

            val counterRef = db.collection(COLLECTION_COUNTERS).document(DOC_FAMILY_COUNTER)

            val createdFamily = db.runTransaction { transaction ->
                val counterSnap = transaction.get(counterRef)
                val currentNumber = if (counterSnap.exists()) {
                    counterSnap.getLong("currentNumber") ?: 0L
                } else {
                    0L
                }
                val nextNumber = currentNumber + 1L
                val familyCode = String.format("FAM-%03d", nextNumber)

                // Check if code already exists
                val codeDuplicate = existingFamilies.any { it.familyCode.equals(familyCode, ignoreCase = true) }
                if (codeDuplicate) {
                    throw IllegalStateException("Kode Family '$familyCode' sudah digunakan")
                }

                // Update global family counter
                transaction.set(counterRef, mapOf("currentNumber" to nextNumber))

                // Create family document
                val familyDocRef = db.collection(COLLECTION_FAMILIES).document(familyCode)
                val family = Family(
                    familyId = familyCode,
                    familyCode = familyCode,
                    familyName = trimmedName,
                    isActive = true,
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now(),
                    createdBy = user,
                    updatedBy = user
                )
                transaction.set(familyDocRef, family)

                // Initialize the family-scoped product counter
                val familyCounterRef = db.collection(COLLECTION_FAMILY_COUNTERS).document(familyCode)
                transaction.set(familyCounterRef, mapOf(
                    "familyCode" to familyCode,
                    "currentProductNumber" to 0L,
                    "updatedAt" to Timestamp.now()
                ))

                family
            }.await()

            Log.d(TAG, "Family created successfully: ${createdFamily.familyCode}")
            Result.success(createdFamily)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating family: ${e.message}", e)
            Result.failure(Exception("Gagal membuat Family: ${e.localizedMessage ?: "Error database"}"))
        }
    }

    suspend fun updateFamily(
        familyId: String,
        newCode: String,
        newName: String,
        user: String,
        userRole: String = ""
    ): Result<Unit> {
        return try {
            if (userRole.isNotBlank() && userRole != UserRole.ROOT_ADMIN.label) {
                return Result.failure(SecurityException("Akses Ditolak: Hanya Root Admin yang berhak mengedit Family."))
            }

            val trimmedName = newName.trim()
            val trimmedCode = newCode.trim().uppercase()
            if (trimmedName.isBlank()) return Result.failure(Exception("Nama Family tidak boleh kosong"))
            if (trimmedCode.isBlank()) return Result.failure(Exception("Kode Family tidak boleh kosong"))

            val allFamiliesSnap = db.collection(COLLECTION_FAMILIES).get().await()
            val existing = allFamiliesSnap.documents.mapNotNull { it.toObject(Family::class.java) }

            // Name uniqueness among other families
            val nameDuplicate = existing.any {
                (it.familyId != familyId && it.familyCode != familyId) &&
                it.familyName.equals(trimmedName, ignoreCase = true)
            }
            if (nameDuplicate) {
                return Result.failure(Exception("Nama Family '$trimmedName' sudah digunakan oleh Family lain"))
            }

            // Code uniqueness among other families
            val codeDuplicate = existing.any {
                (it.familyId != familyId && it.familyCode != familyId) &&
                it.familyCode.equals(trimmedCode, ignoreCase = true)
            }
            if (codeDuplicate) {
                return Result.failure(Exception("Kode Family '$trimmedCode' sudah digunakan oleh Family lain"))
            }

            val docRef = db.collection(COLLECTION_FAMILIES).document(familyId)
            docRef.update(
                mapOf(
                    "familyCode" to trimmedCode,
                    "familyName" to trimmedName,
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating family: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun deleteFamily(familyCode: String, userRole: String = ""): Result<Unit> {
        return try {
            if (userRole.isNotBlank() && userRole != UserRole.ROOT_ADMIN.label) {
                return Result.failure(SecurityException("Akses Ditolak: Hanya Root Admin yang berhak menghapus Family."))
            }

            // Check if any product is using this family
            val productsSnap = db.collection(ProductRepository.COLLECTION_PRODUCTS)
                .whereEqualTo("familyCode", familyCode)
                .limit(1)
                .get()
                .await()

            if (!productsSnap.isEmpty) {
                return Result.failure(Exception("Family '$familyCode' tidak dapat dihapus karena masih digunakan oleh produk/SKU"))
            }

            // Delete family document and counter
            db.collection(COLLECTION_FAMILIES).document(familyCode).delete().await()
            db.collection(COLLECTION_FAMILY_COUNTERS).document(familyCode).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleFamilyStatus(familyId: String, isActive: Boolean, user: String): Result<Unit> {
        return try {
            db.collection(COLLECTION_FAMILIES).document(familyId).update(
                mapOf(
                    "isActive" to isActive,
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listenFamilies(): Flow<List<Family>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_FAMILIES)
            .orderBy("familyCode", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "listenFamilies error: ${error.message}", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(Family::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun getAllFamilies(): List<Family> {
        return try {
            val snap = db.collection(COLLECTION_FAMILIES)
                .orderBy("familyCode", Query.Direction.ASCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(Family::class.java) }
        } catch (e: Exception) {
            Log.e(TAG, "getAllFamilies error: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Audit duplicate Family codes in database and check counter health
     */
    suspend fun auditFamilyDuplicates(): Map<String, Any> {
        return try {
            val snap = db.collection(COLLECTION_FAMILIES).get().await()
            val families = snap.documents.mapNotNull { it.toObject(Family::class.java) }
            val grouped = families.groupBy { it.familyCode }
            val duplicates = grouped.filter { it.value.size > 1 }

            val counterDoc = db.collection(COLLECTION_COUNTERS).document(DOC_FAMILY_COUNTER).get().await()
            val currentCounter = counterDoc.getLong("currentNumber") ?: 0L

            mapOf(
                "totalFamilies" to families.size,
                "uniqueCodes" to grouped.size,
                "currentCounter" to currentCounter,
                "duplicateCount" to duplicates.size,
                "duplicates" to duplicates.keys.toList()
            )
        } catch (e: Exception) {
            mapOf("error" to (e.localizedMessage ?: "Audit error"))
        }
    }
}
