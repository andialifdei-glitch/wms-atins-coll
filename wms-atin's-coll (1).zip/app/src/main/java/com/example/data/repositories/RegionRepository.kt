package com.example.data.repositories

import android.content.Context
import android.util.Log
import com.example.data.models.Region
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

class RegionRepository(
    private val db: FirebaseFirestore,
    private val context: Context
) {
    companion object {
        private const val TAG = "RegionRepository"
        const val COLLECTION_REGIONS = "regions"
        private const val BASE_API_URL = "https://www.emsifa.com/api-wilayah-indonesia/v2"
    }

    // In-memory cache for fast lookups & instant UI responsiveness (Section 19)
    private val cache = ConcurrentHashMap<String, List<Region>>()

    /**
     * Loads all Indonesian provinces lazily from Firestore (source of truth).
     * If not present in Firestore yet, fetches from master API/asset, seeds Firestore, and caches.
     */
    suspend fun getProvinces(): Result<List<Region>> = withContext(Dispatchers.IO) {
        val cacheKey = "PROVINCES"
        val cached = cache[cacheKey]
        if (!cached.isNullOrEmpty()) {
            return@withContext Result.success(cached)
        }

        try {
            // 1. Query Firestore
            val snap = db.collection(COLLECTION_REGIONS)
                .whereEqualTo("level", "PROVINCE")
                .get()
                .await()

            if (!snap.isEmpty) {
                val provinces = snap.documents.mapNotNull { it.toObject(Region::class.java) }
                    .sortedBy { it.name }
                cache[cacheKey] = provinces
                Log.d(TAG, "Loaded ${provinces.size} provinces from Firestore")
                return@withContext Result.success(provinces)
            }

            // 2. Fallback to API or Asset to seed Firestore
            Log.d(TAG, "Provinces empty in Firestore. Seeding from API/Asset...")
            val jsonStr = try {
                fetchJsonFromUrl("$BASE_API_URL/provinces.json")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to fetch provinces from API: ${e.message}, falling back to asset", e)
                readAssetJson("regions/provinces.json") ?: throw e
            }

            val provinces = parseRegionsJson(jsonStr, "PROVINCE", null)
            if (provinces.isNotEmpty()) {
                saveRegionsToFirestore(provinces)
                cache[cacheKey] = provinces
                Log.d(TAG, "Successfully seeded and cached ${provinces.size} provinces")
                Result.success(provinces)
            } else {
                Result.failure(Exception("Gagal memuat data provinsi. Format data tidak sesuai."))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading provinces: ${e.message}", e)
            Result.failure(Exception("Gagal memuat data provinsi. Silakan coba lagi."))
        }
    }

    /**
     * Loads Regencies/Cities for a specific Province lazily.
     * Query parentCode == selectedProvinceCode AND level == "REGENCY".
     */
    suspend fun getRegencies(provinceCode: String): Result<List<Region>> = withContext(Dispatchers.IO) {
        val cleanCode = provinceCode.trim()
        if (cleanCode.isBlank()) return@withContext Result.success(emptyList())

        val cacheKey = "REGENCY_$cleanCode"
        val cached = cache[cacheKey]
        if (!cached.isNullOrEmpty()) {
            return@withContext Result.success(cached)
        }

        try {
            // 1. Query Firestore by parentCode
            val snap = db.collection(COLLECTION_REGIONS)
                .whereEqualTo("level", "REGENCY")
                .whereEqualTo("parentCode", cleanCode)
                .get()
                .await()

            if (!snap.isEmpty) {
                val regencies = snap.documents.mapNotNull { it.toObject(Region::class.java) }
                    .sortedBy { it.name }
                cache[cacheKey] = regencies
                Log.d(TAG, "Loaded ${regencies.size} regencies for province $cleanCode from Firestore")
                return@withContext Result.success(regencies)
            }

            // 2. Fetch from API or Asset to seed Firestore
            Log.d(TAG, "Regencies for $cleanCode empty in Firestore. Seeding from API/Asset...")
            val jsonStr = try {
                fetchJsonFromUrl("$BASE_API_URL/regencies/$cleanCode.json")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to fetch regencies from API for $cleanCode: ${e.message}, checking asset", e)
                readAssetJson("regions/regencies_$cleanCode.json") ?: throw e
            }

            val regencies = parseRegionsJson(jsonStr, "REGENCY", cleanCode)
            if (regencies.isNotEmpty()) {
                saveRegionsToFirestore(regencies)
                cache[cacheKey] = regencies
                Log.d(TAG, "Successfully seeded ${regencies.size} regencies for province $cleanCode")
                Result.success(regencies)
            } else {
                Result.failure(Exception("Data Kabupaten/Kota tidak ditemukan untuk provinsi ini."))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading regencies for $cleanCode: ${e.message}", e)
            Result.failure(Exception("Gagal memuat data Kabupaten/Kota. Silakan coba lagi."))
        }
    }

    /**
     * Loads Districts (Kecamatan) for a specific Regency lazily.
     * Query parentCode == selectedRegencyCode AND level == "DISTRICT".
     */
    suspend fun getDistricts(regencyCode: String): Result<List<Region>> = withContext(Dispatchers.IO) {
        val cleanCode = regencyCode.trim()
        if (cleanCode.isBlank()) return@withContext Result.success(emptyList())

        val cacheKey = "DISTRICT_$cleanCode"
        val cached = cache[cacheKey]
        if (!cached.isNullOrEmpty()) {
            return@withContext Result.success(cached)
        }

        try {
            // 1. Query Firestore by parentCode
            val snap = db.collection(COLLECTION_REGIONS)
                .whereEqualTo("level", "DISTRICT")
                .whereEqualTo("parentCode", cleanCode)
                .get()
                .await()

            if (!snap.isEmpty) {
                val districts = snap.documents.mapNotNull { it.toObject(Region::class.java) }
                    .sortedBy { it.name }
                cache[cacheKey] = districts
                Log.d(TAG, "Loaded ${districts.size} districts for regency $cleanCode from Firestore")
                return@withContext Result.success(districts)
            }

            // 2. Fetch from API or Asset to seed Firestore
            Log.d(TAG, "Districts for $cleanCode empty in Firestore. Seeding from API/Asset...")
            val jsonStr = try {
                fetchJsonFromUrl("$BASE_API_URL/districts/$cleanCode.json")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to fetch districts from API for $cleanCode: ${e.message}, checking asset", e)
                readAssetJson("regions/districts_$cleanCode.json") ?: throw e
            }

            val districts = parseRegionsJson(jsonStr, "DISTRICT", cleanCode)
            if (districts.isNotEmpty()) {
                saveRegionsToFirestore(districts)
                cache[cacheKey] = districts
                Log.d(TAG, "Successfully seeded ${districts.size} districts for regency $cleanCode")
                Result.success(districts)
            } else {
                Result.failure(Exception("Data Kecamatan tidak ditemukan untuk Kabupaten/Kota ini."))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading districts for $cleanCode: ${e.message}", e)
            Result.failure(Exception("Gagal memuat data Kecamatan. Silakan coba lagi."))
        }
    }

    /**
     * Loads Villages/Desa/Kelurahan for a specific District lazily.
     * Query parentCode == selectedDistrictCode AND level == "VILLAGE".
     */
    suspend fun getVillages(districtCode: String): Result<List<Region>> = withContext(Dispatchers.IO) {
        val cleanCode = districtCode.trim()
        if (cleanCode.isBlank()) return@withContext Result.success(emptyList())

        val cacheKey = "VILLAGE_$cleanCode"
        val cached = cache[cacheKey]
        if (!cached.isNullOrEmpty()) {
            return@withContext Result.success(cached)
        }

        try {
            // 1. Query Firestore by parentCode
            val snap = db.collection(COLLECTION_REGIONS)
                .whereEqualTo("level", "VILLAGE")
                .whereEqualTo("parentCode", cleanCode)
                .get()
                .await()

            if (!snap.isEmpty) {
                val villages = snap.documents.mapNotNull { it.toObject(Region::class.java) }
                    .sortedBy { it.name }
                cache[cacheKey] = villages
                Log.d(TAG, "Loaded ${villages.size} villages for district $cleanCode from Firestore")
                return@withContext Result.success(villages)
            }

            // 2. Fetch from API or Asset to seed Firestore
            Log.d(TAG, "Villages for $cleanCode empty in Firestore. Seeding from API/Asset...")
            val jsonStr = try {
                fetchJsonFromUrl("$BASE_API_URL/villages/$cleanCode.json")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to fetch villages from API for $cleanCode: ${e.message}, checking asset", e)
                readAssetJson("regions/villages_$cleanCode.json") ?: throw e
            }

            val villages = parseRegionsJson(jsonStr, "VILLAGE", cleanCode)
            if (villages.isNotEmpty()) {
                saveRegionsToFirestore(villages)
                cache[cacheKey] = villages
                Log.d(TAG, "Successfully seeded ${villages.size} villages for district $cleanCode")
                Result.success(villages)
            } else {
                Result.failure(Exception("Data Desa/Kelurahan tidak ditemukan untuk Kecamatan ini."))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading villages for $cleanCode: ${e.message}", e)
            Result.failure(Exception("Gagal memuat data Desa/Kelurahan. Silakan coba lagi."))
        }
    }

    private fun parseRegionsJson(jsonString: String, level: String, parentCode: String?): List<Region> {
        val trimmed = jsonString.trim()
        val jsonArray = when {
            trimmed.startsWith("{") -> {
                val root = JSONObject(trimmed)
                if (root.has("data")) root.getJSONArray("data") else JSONArray()
            }
            trimmed.startsWith("[") -> JSONArray(trimmed)
            else -> JSONArray()
        }

        val list = mutableListOf<Region>()
        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)
            val code = item.optString("id", item.optString("code", ""))
            val name = item.optString("name", "")
            if (code.isNotBlank() && name.isNotBlank()) {
                list.add(Region(code = code, name = name, level = level, parentCode = parentCode))
            }
        }
        return list.sortedBy { it.name }
    }

    private fun fetchJsonFromUrl(urlString: String): String {
        val url = URL(urlString)
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android; WmsAtin)")
        conn.setRequestProperty("Accept", "application/json")
        val responseCode = conn.responseCode
        if (responseCode !in 200..299) {
            throw IOException("HTTP error $responseCode while fetching $urlString")
        }
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    private fun readAssetJson(assetPath: String): String? {
        return try {
            context.assets.open(assetPath).bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun saveRegionsToFirestore(regions: List<Region>) {
        if (regions.isEmpty()) return
        // Firestore batch max operations is 500
        regions.chunked(400).forEach { chunk ->
            val batch = db.batch()
            for (r in chunk) {
                val docRef = db.collection(COLLECTION_REGIONS).document(r.code)
                batch.set(docRef, r)
            }
            try {
                batch.commit().await()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to commit region batch: ${e.message}")
            }
        }
    }
}
