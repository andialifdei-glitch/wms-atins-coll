package com.example.data.repositories

import android.util.Log
import com.example.data.models.BreakageRecord
import com.example.data.models.MovementType
import com.example.data.models.Product
import com.example.data.models.ReturnRecord
import com.example.data.models.StockAdjustment
import com.example.data.models.StockMovement
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class InventoryRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "InventoryRepository"
        const val COLLECTION_ADJUSTMENTS = "stock_adjustments"
        const val COLLECTION_BREAKAGES = "breakages"
        const val COLLECTION_RETURNS = "returns"
        const val COLLECTION_MOVEMENTS = "stock_movements"
        const val COLLECTION_PRODUCTS = "products"
    }

    /**
     * Stock Adjustment (Increase or Decrease) with atomic stock update and movement log.
     */
    suspend fun adjustStock(
        sku: String,
        adjustmentType: String, // "INCREASE" or "DECREASE"
        qty: Int,
        reason: String,
        notes: String,
        user: String
    ): Result<StockAdjustment> {
        return try {
            if (qty <= 0) return Result.failure(Exception("Jumlah penyesuaian harus lebih dari 0"))
            if (reason.isBlank()) return Result.failure(Exception("Alasan penyesuaian wajib diisi"))

            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val productRef = db.collection(COLLECTION_PRODUCTS).document(sku)
            val adjRef = db.collection(COLLECTION_ADJUSTMENTS).document()
            val movementRef = db.collection(COLLECTION_MOVEMENTS).document()

            val resultAdj = db.runTransaction { transaction ->
                val prodSnap = transaction.get(productRef)
                if (!prodSnap.exists()) throw IllegalStateException("Produk $sku tidak ditemukan")
                val product = prodSnap.toObject(Product::class.java)
                    ?: throw IllegalStateException("Format data produk tidak valid")

                val currentStock = product.stock
                val newStock = if (adjustmentType == "INCREASE") {
                    currentStock + qty
                } else {
                    if (currentStock < qty) {
                        throw IllegalStateException("Stock tidak mencukupi untuk pengurangan. Stock: $currentStock, Kurangi: $qty")
                    }
                    currentStock - qty
                }

                // Update product stock
                transaction.update(
                    productRef,
                    mapOf(
                        "stock" to newStock,
                        "updatedAt" to Timestamp.now(),
                        "updatedBy" to user
                    )
                )

                // Record adjustment
                val adj = StockAdjustment(
                    adjustmentId = adjRef.id,
                    date = todayStr,
                    sku = sku,
                    itemName = product.itemName,
                    currentStock = currentStock,
                    adjustmentType = adjustmentType,
                    adjustmentQty = qty,
                    newStock = newStock,
                    reason = reason.trim(),
                    notes = notes.trim(),
                    user = user,
                    status = "COMPLETED",
                    executedBy = user,
                    executedAt = Timestamp.now(),
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )
                transaction.set(adjRef, adj)

                // Record movement
                val movement = StockMovement(
                    movementId = movementRef.id,
                    date = todayStr,
                    itemCode = sku,
                    itemNameSnapshot = product.itemName,
                    type = MovementType.ADJUSTMENT.name,
                    referenceId = adjRef.id,
                    qtyIn = if (adjustmentType == "INCREASE") qty else 0,
                    qtyOut = if (adjustmentType == "DECREASE") qty else 0,
                    previousStock = currentStock,
                    newStock = newStock,
                    reason = "$adjustmentType: ${reason.trim()}",
                    user = user,
                    timestamp = Timestamp.now()
                )
                transaction.set(movementRef, movement)

                adj
            }.await()

            Log.d(TAG, "Stock adjustment success for $sku: ${resultAdj.adjustmentId}")
            Result.success(resultAdj)
        } catch (e: Exception) {
            Log.e(TAG, "Stock adjustment error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Executes an INITIALIZED stock adjustment from the Web Portal.
     * Atomically modifies the product's stock in `products`, creates a ledger entry
     * in `stock_movements` (MovementType: ADJUSTMENT), and marks the adjustment document as "COMPLETED".
     */
     suspend fun executeAdjustment(
        adjustmentId: String,
        user: String
    ): Result<StockAdjustment> {
        return try {
            val adjRef = db.collection(COLLECTION_ADJUSTMENTS).document(adjustmentId)
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            val completedAdj = db.runTransaction { transaction ->
                val adjSnap = transaction.get(adjRef)
                if (!adjSnap.exists()) {
                    throw IllegalStateException("Dokumen penyesuaian stok $adjustmentId tidak ditemukan")
                }
                val adj = adjSnap.toObject(StockAdjustment::class.java)
                    ?: throw IllegalStateException("Format dokumen penyesuaian stok tidak valid")

                if (adj.status == "COMPLETED") {
                    throw IllegalStateException("Penyesuaian stok ini sudah berstatus COMPLETED")
                }
                if (adj.status == "CANCELLED") {
                    throw IllegalStateException("Penyesuaian stok ini telah dibatalkan")
                }

                val sku = adj.sku
                if (sku.isBlank()) {
                    throw IllegalStateException("SKU pada dokumen penyesuaian stok kosong")
                }

                val productRef = db.collection(COLLECTION_PRODUCTS).document(sku)
                val prodSnap = transaction.get(productRef)
                if (!prodSnap.exists()) {
                    throw IllegalStateException("Produk dengan SKU $sku tidak ditemukan di master produk")
                }
                val product = prodSnap.toObject(Product::class.java)
                    ?: throw IllegalStateException("Format data produk $sku tidak valid")

                val currentStock = product.stock
                val qty = adj.adjustmentQty
                val adjType = adj.adjustmentType.uppercase()

                val newStock = if (adjType == "INCREASE") {
                    currentStock + qty
                } else {
                    if (currentStock < qty) {
                        throw IllegalStateException("Stok saat ini ($currentStock) tidak mencukupi untuk pengurangan ($qty)")
                    }
                    currentStock - qty
                }

                // 1. Update product stock
                transaction.update(
                    productRef,
                    mapOf(
                        "stock" to newStock,
                        "updatedAt" to Timestamp.now(),
                        "updatedBy" to user
                    )
                )

                // 2. Update stock adjustment document
                transaction.update(
                    adjRef,
                    mapOf(
                        "currentStock" to currentStock,
                        "newStock" to newStock,
                        "status" to "COMPLETED",
                        "executedBy" to user,
                        "executedAt" to Timestamp.now(),
                        "updatedAt" to Timestamp.now()
                    )
                )

                // 3. Create ledger entry in stock_movements
                val movementRef = db.collection(COLLECTION_MOVEMENTS).document()
                val movement = StockMovement(
                    movementId = movementRef.id,
                    date = todayStr,
                    itemCode = sku,
                    itemNameSnapshot = product.itemName,
                    type = MovementType.ADJUSTMENT.name,
                    referenceId = adjustmentId,
                    qtyIn = if (adjType == "INCREASE") qty else 0,
                    qtyOut = if (adjType == "DECREASE") qty else 0,
                    previousStock = currentStock,
                    newStock = newStock,
                    reason = "Eksekusi Penyesuaian Web Portal: ${adj.reason.ifBlank { adjType }}",
                    user = user,
                    timestamp = Timestamp.now()
                )
                transaction.set(movementRef, movement)

                adj.copy(
                    currentStock = currentStock,
                    newStock = newStock,
                    status = "COMPLETED",
                    executedBy = user,
                    executedAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )
            }.await()

            Log.d(TAG, "Stock adjustment $adjustmentId executed successfully by $user")
            Result.success(completedAdj)
        } catch (e: Exception) {
            Log.e(TAG, "Error executing stock adjustment: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Real-time listener for stock adjustments.
     */
    fun listenAdjustments(): Flow<List<StockAdjustment>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_ADJUSTMENTS)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to adjustments: ${error.message}", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(StockAdjustment::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    /**
     * Records product breakage (rusak / cacat) and deducts stock with movement record.
     */
    suspend fun recordBreakage(
        sku: String,
        qty: Int,
        reason: String,
        notes: String,
        user: String
    ): Result<BreakageRecord> {
        return try {
            if (qty <= 0) return Result.failure(Exception("Jumlah kerusakan harus lebih dari 0"))
            if (reason.isBlank()) return Result.failure(Exception("Alasan kerusakan wajib diisi"))

            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val productRef = db.collection(COLLECTION_PRODUCTS).document(sku)
            val breakageRef = db.collection(COLLECTION_BREAKAGES).document()
            val movementRef = db.collection(COLLECTION_MOVEMENTS).document()

            val breakage = db.runTransaction { transaction ->
                val prodSnap = transaction.get(productRef)
                if (!prodSnap.exists()) throw IllegalStateException("Produk $sku tidak ditemukan")
                val product = prodSnap.toObject(Product::class.java)
                    ?: throw IllegalStateException("Format data produk tidak valid")

                val currentStock = product.stock
                if (currentStock < qty) {
                    throw IllegalStateException("Stock tidak mencukupi untuk breakage. Stock: $currentStock, Rusak: $qty")
                }
                val newStock = currentStock - qty

                transaction.update(
                    productRef,
                    mapOf(
                        "stock" to newStock,
                        "updatedAt" to Timestamp.now(),
                        "updatedBy" to user
                    )
                )

                val rec = BreakageRecord(
                    breakageId = breakageRef.id,
                    date = todayStr,
                    sku = sku,
                    itemName = product.itemName,
                    currentStock = currentStock,
                    qty = qty,
                    newStock = newStock,
                    reason = reason.trim(),
                    notes = notes.trim(),
                    user = user,
                    createdAt = Timestamp.now()
                )
                transaction.set(breakageRef, rec)

                val movement = StockMovement(
                    movementId = movementRef.id,
                    date = todayStr,
                    itemCode = sku,
                    itemNameSnapshot = product.itemName,
                    type = MovementType.BREAKAGE.name,
                    referenceId = breakageRef.id,
                    qtyIn = 0,
                    qtyOut = qty,
                    previousStock = currentStock,
                    newStock = newStock,
                    reason = "Breakage: ${reason.trim()}",
                    user = user,
                    timestamp = Timestamp.now()
                )
                transaction.set(movementRef, movement)

                rec
            }.await()

            Result.success(breakage)
        } catch (e: Exception) {
            Log.e(TAG, "Breakage error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Records product return from customer, restores stock and logs movement.
     */
    suspend fun recordReturn(
        reference: String,
        customer: String,
        sku: String,
        qty: Int,
        reason: String,
        condition: String,
        notes: String,
        user: String
    ): Result<ReturnRecord> {
        return try {
            if (qty <= 0) return Result.failure(Exception("Jumlah return harus lebih dari 0"))
            if (reason.isBlank()) return Result.failure(Exception("Alasan return wajib diisi"))

            val productRef = db.collection(COLLECTION_PRODUCTS).document(sku)
            val returnRef = db.collection(COLLECTION_RETURNS).document()
            val movementRef = db.collection(COLLECTION_MOVEMENTS).document()
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            val returnRecord = db.runTransaction { transaction ->
                val prodSnap = transaction.get(productRef)
                if (!prodSnap.exists()) throw IllegalStateException("Produk $sku tidak ditemukan")
                val product = prodSnap.toObject(Product::class.java)
                    ?: throw IllegalStateException("Format data produk tidak valid")

                val currentStock = product.stock
                val newStock = currentStock + qty

                transaction.update(
                    productRef,
                    mapOf(
                        "stock" to newStock,
                        "updatedAt" to Timestamp.now(),
                        "updatedBy" to user
                    )
                )

                val rec = ReturnRecord(
                    returnId = returnRef.id,
                    reference = reference.trim(),
                    customer = customer.trim(),
                    sku = sku,
                    itemName = product.itemName,
                    qty = qty,
                    reason = reason.trim(),
                    condition = condition.trim(),
                    notes = notes.trim(),
                    user = user,
                    createdAt = Timestamp.now()
                )
                transaction.set(returnRef, rec)

                val movement = StockMovement(
                    movementId = movementRef.id,
                    date = todayStr,
                    itemCode = sku,
                    itemNameSnapshot = product.itemName,
                    type = MovementType.RETURN.name,
                    referenceId = returnRef.id,
                    qtyIn = qty,
                    qtyOut = 0,
                    previousStock = currentStock,
                    newStock = newStock,
                    reason = "Return dari $customer: ${reason.trim()}",
                    user = user,
                    timestamp = Timestamp.now()
                )
                transaction.set(movementRef, movement)

                rec
            }.await()

            Result.success(returnRecord)
        } catch (e: Exception) {
            Log.e(TAG, "Return error: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun recordSupplierReturn(
        reference: String,
        supplier: String,
        sku: String,
        qty: Int,
        reason: String,
        notes: String,
        user: String
    ): Result<ReturnRecord> {
        return try {
            if (qty <= 0) return Result.failure(Exception("Jumlah retur supplier harus lebih dari 0"))
            if (reason.isBlank()) return Result.failure(Exception("Alasan retur supplier wajib diisi"))

            val productRef = db.collection(COLLECTION_PRODUCTS).document(sku)
            val returnRef = db.collection(COLLECTION_RETURNS).document()
            val movementRef = db.collection(COLLECTION_MOVEMENTS).document()
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            val returnRecord = db.runTransaction { transaction ->
                val prodSnap = transaction.get(productRef)
                if (!prodSnap.exists()) throw IllegalStateException("Produk $sku tidak ditemukan")
                val product = prodSnap.toObject(Product::class.java)
                    ?: throw IllegalStateException("Format data produk tidak valid")

                val currentStock = product.stock
                if (currentStock < qty) {
                    throw IllegalStateException("Stok tidak mencukupi untuk retur ke supplier. Stok saat ini: $currentStock pcs, Diminta: $qty pcs")
                }
                val newStock = currentStock - qty

                transaction.update(
                    productRef,
                    mapOf(
                        "stock" to newStock,
                        "updatedAt" to Timestamp.now(),
                        "updatedBy" to user
                    )
                )

                val rec = ReturnRecord(
                    returnId = returnRef.id,
                    reference = reference.trim(),
                    customer = "[Supplier] " + supplier.trim(),
                    sku = sku,
                    itemName = product.itemName,
                    qty = qty,
                    reason = "[Retur Supplier] " + reason.trim(),
                    condition = "Dikembalikan ke Supplier",
                    notes = notes.trim(),
                    user = user,
                    createdAt = Timestamp.now()
                )
                transaction.set(returnRef, rec)

                val movement = StockMovement(
                    movementId = movementRef.id,
                    date = todayStr,
                    itemCode = sku,
                    itemNameSnapshot = product.itemName,
                    type = "RETURN_SUPPLIER",
                    referenceId = returnRef.id,
                    qtyIn = 0,
                    qtyOut = qty,
                    previousStock = currentStock,
                    newStock = newStock,
                    reason = "Retur ke Supplier $supplier: ${reason.trim()}",
                    user = user,
                    timestamp = Timestamp.now()
                )
                transaction.set(movementRef, movement)

                rec
            }.await()

            Result.success(returnRecord)
        } catch (e: Exception) {
            Log.e(TAG, "Supplier Return error: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun listenStockMovements(): Flow<List<StockMovement>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_MOVEMENTS)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(150)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(StockMovement::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun getAllMovements(): List<StockMovement> {
        return try {
            val snap = db.collection(COLLECTION_MOVEMENTS)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(StockMovement::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAllAdjustments(): List<StockAdjustment> {
        return try {
            val snap = db.collection(COLLECTION_ADJUSTMENTS)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(StockAdjustment::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAllBreakages(): List<BreakageRecord> {
        return try {
            val snap = db.collection(COLLECTION_BREAKAGES)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(BreakageRecord::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getAllReturns(): List<ReturnRecord> {
        return try {
            val snap = db.collection(COLLECTION_RETURNS)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(ReturnRecord::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
