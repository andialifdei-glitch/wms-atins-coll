package com.example.data.repositories

import android.util.Log
import com.example.data.models.PromoPrice
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class PromoPriceRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "PromoPriceRepository"
        const val COLLECTION_PROMOTIONS = "promotions"
    }

    suspend fun addPromoPrice(
        sku: String,
        itemName: String,
        promoPrice: Long,
        startDate: String,
        endDate: String
    ): Result<PromoPrice> {
        return try {
            val docRef = db.collection(COLLECTION_PROMOTIONS).document()
            val promo = PromoPrice(
                promoId = docRef.id,
                sku = sku,
                itemName = itemName,
                promoPrice = promoPrice,
                startDate = startDate,
                endDate = endDate,
                isActive = true,
                createdAt = Timestamp.now()
            )
            docRef.set(promo).await()
            Result.success(promo)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding promo: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun togglePromoStatus(promoId: String, isActive: Boolean): Result<Unit> {
        return try {
            db.collection(COLLECTION_PROMOTIONS).document(promoId).update("isActive", isActive).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePromo(promoId: String): Result<Unit> {
        return try {
            db.collection(COLLECTION_PROMOTIONS).document(promoId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listenPromotions(): Flow<List<PromoPrice>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_PROMOTIONS)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(PromoPrice::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }
}
