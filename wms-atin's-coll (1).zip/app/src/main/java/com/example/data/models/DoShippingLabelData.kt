package com.example.data.models

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Whitelist Data Model for DO External Shipping Label (Print & Preview).
 * Strictly adheres to the revised specification:
 *
 * DELIVERY ORDER (Centered, bold, uppercase, main title)
 * DO : [Nomor DO]
 * Ekspedisi : [Layanan pengiriman]
 * ---
 * PENGIRIM
 * [Nama toko/pengirim dari Pengaturan]
 * NO HANDPHONE
 * [Nomor HP pengirim dari Pengaturan]
 * ---
 * PENERIMA
 * [Nama penerima dari data DO/customer]
 * ALAMAT
 * [Alamat lengkap penerima dari data DO/customer]
 * NO HANDPHONE
 * [Nomor HP penerima dari data DO/customer]
 * ---
 * SO : [Nomor SO]
 * Tanggal Cetak : [Tanggal dan waktu timestamp aktual]
 * By : [Nama pengguna login]
 *
 * SENSITIVE FIELDS EXCLUDED BY DESIGN (WHITELIST PRINCIPLE):
 * - NO sender address (origin address excluded)
 * - NO shipping cost, shipping markup
 * - NO items, product names, product SKU, quantities
 * - NO sell price, purchasing price (HPP), subtotal, grand total, or internal financial data
 */
data class DoShippingLabelData(
    val doNumber: String,
    val shippingService: String,
    val senderName: String,
    val senderPhone: String,
    val recipientName: String,
    val recipientAddress: String,
    val recipientPhone: String,
    val soNumber: String,
    val printDate: String,
    val printedBy: String
) {
    companion object {
        fun formatCurrentTimestamp(date: Date = Date()): String {
            val sdf = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("id", "ID"))
            sdf.timeZone = TimeZone.getDefault()
            return sdf.format(date)
        }

        fun resolveCurrentUserIdentity(
            userAccount: UserAccount? = null,
            fallbackUser: String = ""
        ): String {
            if (userAccount != null) {
                if (userAccount.name.isNotBlank()) return userAccount.name.trim()
                if (userAccount.email.isNotBlank()) return userAccount.email.trim()
                if (userAccount.userId.isNotBlank()) return userAccount.userId.trim()
            }
            if (fallbackUser.isNotBlank()) return fallbackUser.trim()

            val fbUser = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser } catch (e: Exception) { null }
            if (fbUser != null) {
                fbUser.displayName?.takeIf { it.isNotBlank() }?.let { return it.trim() }
                fbUser.email?.takeIf { it.isNotBlank() }?.let { return it.trim() }
                fbUser.uid.takeIf { it.isNotBlank() }?.let { return it.trim() }
            }
            return "-"
        }

        /**
         * Safely maps a DeliveryOrder and StoreSettings to the sanitized DoShippingLabelData.
         * Enforces strict whitelist sanitization so no internal data ever leaks to the label renderer.
         */
        fun fromDeliveryOrder(
            doOrder: DeliveryOrder,
            storeSettings: StoreSettings? = null,
            userAccount: UserAccount? = null,
            fallbackUser: String = "",
            printDate: String = formatCurrentTimestamp()
        ): DoShippingLabelData {
            val cleanExpedition = doOrder.shippingServiceName.ifBlank {
                doOrder.expedition
            }.replace(" - None", "")
                .replace("(None)", "")
                .replace(" None", "")
                .trim()
                .ifBlank { "Standard Delivery" }

            val cleanSenderName = storeSettings?.storeName?.trim()?.takeIf { it.isNotBlank() }
                ?: doOrder.senderName.trim().ifBlank { "Atin's Collection" }
            val cleanSenderPhone = storeSettings?.storePhone?.trim()?.takeIf { it.isNotBlank() }
                ?: doOrder.senderPhone.trim().ifBlank { "-" }

            val cleanBy = resolveCurrentUserIdentity(userAccount, fallbackUser)

            return DoShippingLabelData(
                doNumber = doOrder.doId.trim(),
                shippingService = cleanExpedition,
                senderName = cleanSenderName,
                senderPhone = cleanSenderPhone,
                recipientName = doOrder.recipientName.trim().ifBlank { "-" },
                recipientAddress = doOrder.recipientAddress.trim().ifBlank { "-" },
                recipientPhone = doOrder.recipientPhone.trim().ifBlank { "-" },
                soNumber = doOrder.soId.trim(),
                printDate = printDate.trim().ifBlank { formatCurrentTimestamp() },
                printedBy = cleanBy
            )
        }
    }
}
