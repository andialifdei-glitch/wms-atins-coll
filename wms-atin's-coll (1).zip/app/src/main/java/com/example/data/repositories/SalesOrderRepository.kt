package com.example.data.repositories

import android.util.Log
import com.example.data.models.SalesOrder
import com.example.data.models.SoItem
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SalesOrderRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "SalesOrderRepository"
        const val COLLECTION_SO = "sales_orders"
        const val COLLECTION_COUNTERS = "counters"
        const val DOC_SO_COUNTER = "sales_order"
    }

    suspend fun createSalesOrder(
        customerId: String,
        customerName: String,
        phone: String,
        address: String,
        expedition: String,
        items: List<SoItem>,
        user: String,
        shippingCost: Long = 0L,
        shippingCourier: String = "",
        shippingServiceName: String = "",
        totalWeightInGrams: Int = 0
    ): Result<SalesOrder> {
        return try {
            if (customerName.isBlank()) return Result.failure(Exception("Nama customer wajib diisi"))
            if (items.isEmpty()) return Result.failure(Exception("Minimal harus ada satu item produk"))

            val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
            val displayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val counterRef = db.collection(COLLECTION_COUNTERS).document(DOC_SO_COUNTER)

            val computedWeight = if (totalWeightInGrams > 0) totalWeightInGrams else items.sumOf { it.qty * it.weightInGrams }
            val subtotal = items.sumOf { it.subtotal }
            val grandTotal = subtotal + shippingCost

            val createdSo = db.runTransaction { transaction ->
                val counterSnap = transaction.get(counterRef)
                val currentNumber = if (counterSnap.exists()) {
                    counterSnap.getLong("currentNumber") ?: 0L
                } else {
                    0L
                }
                val nextNumber = currentNumber + 1L
                val soId = String.format("SO-%s-%05d", dateStr, nextNumber)

                transaction.set(counterRef, mapOf("currentNumber" to nextNumber, "updatedAt" to Timestamp.now()))

                // SO status is always CONFIRMED upon creation, stock is NOT deducted
                val so = SalesOrder(
                    soId = soId,
                    date = displayDate,
                    customerId = customerId,
                    customerName = customerName.trim(),
                    phone = phone.trim(),
                    address = address.trim(),
                    expedition = expedition.trim(),
                    items = items,
                    total = grandTotal,
                    totalWeightInGrams = computedWeight,
                    shippingCost = shippingCost,
                    shippingCourier = shippingCourier,
                    shippingServiceName = shippingServiceName,
                    status = "CONFIRMED",
                    cancelReason = "",
                    createdBy = user,
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )

                val docRef = db.collection(COLLECTION_SO).document(soId)
                transaction.set(docRef, so)
                so
            }.await()

            Log.d(TAG, "SO created: ${createdSo.soId}")
            Result.success(createdSo)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating SO: ${e.message}", e)
            Result.failure(Exception("Gagal membuat SO: ${e.localizedMessage ?: "Error database"}"))
        }
    }

    suspend fun updateSalesOrder(
        soId: String,
        customerName: String,
        phone: String,
        address: String,
        expedition: String,
        items: List<SoItem>,
        user: String,
        shippingCost: Long = 0L,
        shippingCourier: String = "",
        shippingServiceName: String = "",
        totalWeightInGrams: Int = 0
    ): Result<Unit> {
        return try {
            val computedWeight = if (totalWeightInGrams > 0) totalWeightInGrams else items.sumOf { it.qty * it.weightInGrams }
            val subtotal = items.sumOf { it.subtotal }
            val grandTotal = subtotal + shippingCost
            val updateMap = mutableMapOf<String, Any>(
                "customerName" to customerName.trim(),
                "phone" to phone.trim(),
                "address" to address.trim(),
                "expedition" to expedition.trim(),
                "items" to items,
                "total" to grandTotal,
                "totalWeightInGrams" to computedWeight,
                "updatedAt" to Timestamp.now(),
                "updatedBy" to user
            )
            if (shippingCost > 0L) {
                updateMap["shippingCost"] = shippingCost
            }
            if (shippingCourier.isNotBlank()) {
                updateMap["shippingCourier"] = shippingCourier
            }
            if (shippingServiceName.isNotBlank()) {
                updateMap["shippingServiceName"] = shippingServiceName
            }

            db.collection(COLLECTION_SO).document(soId).update(updateMap).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markProcessing(soId: String, user: String): Result<Unit> {
        return try {
            val docRef = db.collection(COLLECTION_SO).document(soId)
            val snap = docRef.get().await()
            val status = snap.getString("status") ?: ""
            if (status != "CONFIRMED") {
                return Result.failure(Exception("Hanya SO berstatus CONFIRMED yang dapat diubah ke PROCESSING (Status saat ini: $status)"))
            }
            docRef.update(
                mapOf(
                    "status" to "PROCESSING",
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateSoItems(soId: String, items: List<SoItem>, user: String): Result<Unit> {
        return try {
            val docRef = db.collection(COLLECTION_SO).document(soId)
            val snap = docRef.get().await()
            val status = snap.getString("status") ?: ""
            if (status != "CONFIRMED") {
                return Result.failure(Exception("Item hanya dapat diubah saat SO berstatus CONFIRMED (Status: $status)"))
            }
            val shippingCost = snap.getLong("shippingCost") ?: 0L
            val totalWeight = items.sumOf { it.qty * it.weightInGrams }
            val subtotal = items.sumOf { it.subtotal }
            val grandTotal = subtotal + shippingCost
            docRef.update(
                mapOf(
                    "items" to items,
                    "total" to grandTotal,
                    "totalWeightInGrams" to totalWeight,
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markReadyToDeliver(soId: String, user: String): Result<Unit> {
        return try {
            val docRef = db.collection(COLLECTION_SO).document(soId)
            val snap = docRef.get().await()
            val status = snap.getString("status") ?: ""
            if (status != "PROCESSING") {
                return Result.failure(Exception("Hanya SO berstatus PROCESSING yang dapat diubah ke READY TO DELIVER (Status saat ini: $status)"))
            }
            docRef.update(
                mapOf(
                    "status" to "READY TO DELIVER",
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun cancelSalesOrder(soId: String, reason: String, user: String): Result<Unit> {
        return try {
            val cleanReason = reason.trim()
            if (cleanReason.isBlank()) {
                return Result.failure(Exception("Alasan pembatalan wajib diisi"))
            }

            db.collection(COLLECTION_SO).document(soId).update(
                mapOf(
                    "status" to "CANCELLED",
                    "cancelReason" to cleanReason,
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error cancelling SO: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun getSalesOrder(soId: String): SalesOrder? {
        return try {
            val doc = db.collection(COLLECTION_SO).document(soId).get().await()
            doc.toObject(SalesOrder::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun listenSalesOrders(): Flow<List<SalesOrder>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_SO)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(SalesOrder::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun getAllSalesOrders(): List<SalesOrder> {
        return try {
            val snap = db.collection(COLLECTION_SO)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(SalesOrder::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
