package com.example.data.repositories

import android.util.Log
import com.example.data.models.ShippingService
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ShippingServiceRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "ShippingServiceRepo"
        const val COLLECTION_SHIPPING = "shipping_services"
        val DEFAULT_EXPEDITIONS = listOf("Wahana", "SPX", "Lion Parcel", "JNE", "J&T", "Baraka")
    }

    suspend fun bootstrapDefaultsIfNeeded() {
        try {
            val snap = db.collection(COLLECTION_SHIPPING).limit(1).get().await()
            if (snap.isEmpty) {
                for (name in DEFAULT_EXPEDITIONS) {
                    val docRef = db.collection(COLLECTION_SHIPPING).document()
                    val service = ShippingService(
                        shippingServiceId = docRef.id,
                        name = name,
                        isActive = true,
                        createdAt = Timestamp.now(),
                        updatedAt = Timestamp.now()
                    )
                    docRef.set(service).await()
                }
                Log.d(TAG, "Bootstrapped default shipping services")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error bootstrapping shipping services: ${e.message}")
        }
    }

    suspend fun addShippingService(name: String): Result<ShippingService> {
        return try {
            val cleanName = name.trim()
            if (cleanName.isBlank()) return Result.failure(Exception("Nama ekspedisi tidak boleh kosong"))

            val docRef = db.collection(COLLECTION_SHIPPING).document()
            val service = ShippingService(
                shippingServiceId = docRef.id,
                name = cleanName,
                isActive = true,
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            docRef.set(service).await()
            Result.success(service)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleStatus(id: String, isActive: Boolean): Result<Unit> {
        return try {
            db.collection(COLLECTION_SHIPPING).document(id).update(
                mapOf(
                    "isActive" to isActive,
                    "updatedAt" to Timestamp.now()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateShippingService(id: String, name: String, userRole: String = ""): Result<Unit> {
        return try {
            val cleanName = name.trim()
            if (cleanName.isBlank()) return Result.failure(Exception("Nama ekspedisi tidak boleh kosong"))
            if (userRole.isNotBlank() && userRole != com.example.data.models.UserRole.ROOT_ADMIN.label) {
                return Result.failure(SecurityException("Hanya Root Admin yang berhak mengedit data ekspedisi"))
            }

            db.collection(COLLECTION_SHIPPING).document(id).update(
                mapOf(
                    "name" to cleanName,
                    "updatedAt" to Timestamp.now()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteShippingService(id: String, userRole: String = ""): Result<Unit> {
        return try {
            if (userRole.isNotBlank() && userRole != com.example.data.models.UserRole.ROOT_ADMIN.label) {
                return Result.failure(SecurityException("Hanya Root Admin yang berhak menghapus data ekspedisi"))
            }
            db.collection(COLLECTION_SHIPPING).document(id).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listenShippingServices(): Flow<List<ShippingService>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_SHIPPING)
            .orderBy("name", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(ShippingService::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }
}
