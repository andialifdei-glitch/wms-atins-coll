package com.example.data.repositories

import android.util.Log
import com.example.data.models.*
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StockOpnameRepository(
    private val db: FirebaseFirestore,
    private val productRepo: ProductRepository? = null
) {
    companion object {
        private const val TAG = "StockOpnameRepo"
        const val COLLECTION_SOP = "stock_opnames"
        const val COLLECTION_POSTINGS = "sop_postings"
        const val COLLECTION_AUDIT_TRAILS = "audit_trails"
        const val COLLECTION_COUNTERS = "counters"
        const val COLLECTION_PRODUCTS = "products"
        const val COLLECTION_MOVEMENTS = "stock_movements"

        fun isRootAdmin(role: String): Boolean {
            val clean = role.trim().lowercase()
            return clean == "root admin" || clean == "root_admin" || clean == "rootadmin" || clean == "admin"
        }

        /**
         * Robust parser for StockOpname DocumentSnapshot that guarantees reliable mapping
         * of nested item maps, numerical values (e.g. 0), and counting status flags.
         */
        fun parseStockOpname(doc: com.google.firebase.firestore.DocumentSnapshot): StockOpname? {
            if (!doc.exists()) return null
            val sopObj = try {
                doc.toObject(StockOpname::class.java)
            } catch (e: Exception) {
                Log.w(TAG, "doc.toObject(StockOpname) exception: ${e.message}")
                null
            }

            val rawItems = doc.get("items") as? List<*>
            val items: List<StockOpnameItem> = if (rawItems != null && rawItems.isNotEmpty()) {
                rawItems.mapNotNull { raw ->
                    when (raw) {
                        is Map<*, *> -> {
                            val skuId = (raw["skuId"] ?: raw["skuCode"] ?: raw["sku"] ?: "").toString().trim()
                            val skuCode = (raw["skuCode"] ?: skuId).toString().trim()
                            val itemName = (raw["itemName"] ?: raw["name"] ?: skuCode).toString().trim()
                            val systemQtySnapshot = when (val s = raw["systemQtySnapshot"] ?: raw["snapshotQty"] ?: raw["systemQty"]) {
                                is Number -> s.toInt()
                                is String -> s.toIntOrNull() ?: 0
                                else -> 0
                            }
                            // Physical Qty: 0 is completely valid!
                            val physicalQty = when (val p = raw["physicalQty"] ?: raw["countedQty"] ?: raw["actualQty"] ?: raw["physical_qty"] ?: raw["qtyFisik"]) {
                                is Number -> p.toInt()
                                is String -> p.toIntOrNull()
                                else -> null
                            }
                            val isCountedFlag = when (val c = raw["isCounted"] ?: raw["counted"] ?: raw["hasBeenCounted"]) {
                                is Boolean -> c
                                is String -> c.equals("true", ignoreCase = true)
                                is Number -> c.toInt() == 1
                                else -> false
                            }
                            // Definitive rule: physicalQty != null (even 0) or explicit flag means it has been counted!
                            val isCounted = physicalQty != null || isCountedFlag

                            val countedBy = (raw["countedBy"] ?: "").toString()
                            val countedAt = when (val ca = raw["countedAt"]) {
                                is Timestamp -> ca
                                else -> null
                            }
                            val adjustmentQty = when (val a = raw["adjustmentQty"] ?: raw["adjQty"]) {
                                is Number -> a.toInt()
                                is String -> a.toIntOrNull() ?: 0
                                else -> (physicalQty ?: systemQtySnapshot) - systemQtySnapshot
                            }
                            val adjustmentReason = (raw["adjustmentReason"] ?: raw["reason"] ?: "").toString()
                            val adjustedBy = (raw["adjustedBy"] ?: "").toString()
                            val adjustedAt = when (val aa = raw["adjustedAt"]) {
                                is Timestamp -> aa
                                else -> null
                            }

                            StockOpnameItem(
                                skuId = skuId,
                                skuCode = skuCode,
                                itemName = itemName,
                                systemQtySnapshot = systemQtySnapshot,
                                physicalQty = physicalQty,
                                isCounted = isCounted,
                                countedBy = countedBy,
                                countedAt = countedAt,
                                adjustmentQty = adjustmentQty,
                                adjustmentReason = adjustmentReason,
                                adjustedBy = adjustedBy,
                                adjustedAt = adjustedAt
                            )
                        }
                        else -> null
                    }
                }
            } else if (sopObj != null) {
                sopObj.items.map { item ->
                    item.copy(isCounted = item.hasBeenCounted)
                }
            } else {
                emptyList()
            }

            val sopId = (sopObj?.sopId?.takeIf { it.isNotBlank() }
                ?: doc.getString("sopId")
                ?: doc.getString("documentNo")
                ?: doc.id).trim()

            val documentNo = (sopObj?.documentNo?.takeIf { it.isNotBlank() }
                ?: doc.getString("documentNo")
                ?: sopId).trim()

            val status = (sopObj?.status?.takeIf { it.isNotBlank() }
                ?: doc.getString("status")
                ?: "OPEN").trim()

            val opnameDate = (sopObj?.opnameDate?.takeIf { it.isNotBlank() }
                ?: doc.getString("opnameDate")
                ?: "").trim()

            val initializedBy = (sopObj?.initializedBy?.takeIf { it.isNotBlank() }
                ?: doc.getString("initializedBy")
                ?: "").trim()

            val initializedAt = sopObj?.initializedAt ?: doc.getTimestamp("initializedAt")

            val countingCompletedBy = (sopObj?.countingCompletedBy?.takeIf { it.isNotBlank() }
                ?: doc.getString("countingCompletedBy")
                ?: "").trim()

            val countingCompletedAt = sopObj?.countingCompletedAt ?: doc.getTimestamp("countingCompletedAt")

            val totalSku = if (sopObj != null && sopObj.totalSku > 0) {
                sopObj.totalSku
            } else {
                (doc.get("totalSku") as? Number)?.toInt() ?: items.size
            }

            val postingId = (sopObj?.postingId?.takeIf { it.isNotBlank() } ?: doc.getString("postingId") ?: "").trim()
            val postedBy = (sopObj?.postedBy?.takeIf { it.isNotBlank() } ?: doc.getString("postedBy") ?: "").trim()
            val postedAt = sopObj?.postedAt ?: doc.getTimestamp("postedAt")
            val notes = (sopObj?.notes?.takeIf { it.isNotBlank() } ?: doc.getString("notes") ?: "").trim()

            val cancelReason = (sopObj?.cancelReason?.takeIf { it.isNotBlank() }
                ?: doc.getString("cancelReason")
                ?: doc.getString("cancel_reason")
                ?: doc.getString("cancellationReason")
                ?: "").trim()
            val cancelledBy = (sopObj?.cancelledBy?.takeIf { it.isNotBlank() }
                ?: doc.getString("cancelledBy")
                ?: doc.getString("canceledBy")
                ?: "").trim()
            val cancelledAt = sopObj?.cancelledAt
                ?: doc.getTimestamp("cancelledAt")
                ?: doc.getTimestamp("canceledAt")

            // Normalize status if saved as CANCELLED or CANCELED
            val normalizedStatus = if (status.equals("CANCELED", ignoreCase = true) || status.equals("CANCELLED", ignoreCase = true)) {
                "CANCELLED"
            } else {
                status
            }

            return StockOpname(
                sopId = sopId,
                documentNo = documentNo,
                opnameDate = opnameDate,
                status = normalizedStatus,
                cancelReason = cancelReason,
                cancelledBy = cancelledBy,
                cancelledAt = cancelledAt,
                initializedBy = initializedBy,
                initializedAt = initializedAt,
                countingCompletedBy = countingCompletedBy,
                countingCompletedAt = countingCompletedAt,
                totalSku = totalSku,
                items = items,
                postingId = postingId,
                postedBy = postedBy,
                postedAt = postedAt,
                notes = notes
            )
        }
    }

    /**
     * Listens to real-time updates for all Stock Opname documents.
     */
    fun listenStockOpnames(): Flow<List<StockOpname>> = callbackFlow {
        val subscription = db.collection(COLLECTION_SOP)
            .orderBy("initializedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to Stock Opnames: ${error.message}", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val sops = snapshot.documents.mapNotNull { parseStockOpname(it) }
                    trySend(sops)
                }
            }
        awaitClose { subscription.remove() }
    }

    /**
     * Listens to real-time updates for all Stock Opname Postings.
     */
    fun listenPostings(): Flow<List<SopPosting>> = callbackFlow {
        val subscription = db.collection(COLLECTION_POSTINGS)
            .orderBy("postedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Error listening to SOP Postings: ${error.message}", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val postings = snapshot.documents.mapNotNull { it.toObject(SopPosting::class.java) }
                    trySend(postings)
                }
            }
        awaitClose { subscription.remove() }
    }

    /**
     * Listens to real-time audit trail logs, optionally filtered by documentNo.
     */
    fun listenAuditTrails(documentNo: String? = null): Flow<List<AuditTrail>> = callbackFlow {
        var query: Query = db.collection(COLLECTION_AUDIT_TRAILS)
            .orderBy("timestamp", Query.Direction.DESCENDING)
        if (!documentNo.isNullOrBlank()) {
            query = query.whereEqualTo("documentNo", documentNo)
        }

        val subscription = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e(TAG, "Error listening to Audit Trails: ${error.message}", error)
                trySend(emptyList())
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val audits = snapshot.documents.mapNotNull { it.toObject(AuditTrail::class.java) }
                trySend(audits)
            }
        }
        awaitClose { subscription.remove() }
    }

    /**
     * Initializes a new Stock Opname (ROOT ADMIN ONLY).
     * Creates document SOP-YYYYMMDD-XXX and captures a snapshot of current active SKUs and stocks.
     * DOES NOT modify stock balances.
     */
    suspend fun initializeStockOpname(
        user: String,
        role: String,
        notes: String = "",
        fallbackProducts: List<Product> = emptyList()
    ): Result<StockOpname> {
        return try {
            if (!isRootAdmin(role)) {
                return Result.failure(SecurityException("Hanya Root Admin yang berhak melakukan Initialize Stock Opname (Role: '$role')"))
            }

            // Check if there is already an active Stock Opname
            val activeSnap = try {
                db.collection(COLLECTION_SOP)
                    .whereIn("status", listOf("OPEN", "COUNTING", "COUNTING_COMPLETED", "ADJUSTMENT"))
                    .get().await()
            } catch (e: Exception) {
                Log.e(TAG, "Gagal memeriksa status Stock Opname aktif: ${e.message}", e)
                return Result.failure(Exception("Gagal memeriksa status Stock Opname aktif: ${e.localizedMessage ?: "Koneksi atau permission Firestore bermasalah"}"))
            }

            if (!activeSnap.isEmpty) {
                val existingActive = activeSnap.documents.first().id
                return Result.failure(
                    IllegalStateException("Masih terdapat Stock Opname aktif ($existingActive). Selesaikan atau posting terlebih dahulu sebelum memulai yang baru.")
                )
            }

            val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
            val displayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val counterDocId = "sop_counter_$dateStr"
            val counterRef = db.collection(COLLECTION_COUNTERS).document(counterDocId)

            // READ MASTER PRODUCTS
            // Uses robust multi-attribute parser to handle any schema variations and type differences
            var totalDocsFound = 0
            val parsedProducts = mutableListOf<Product>()
            val parseErrors = mutableListOf<String>()

            try {
                val productsSnap = db.collection(COLLECTION_PRODUCTS).get().await()
                totalDocsFound = productsSnap.size()
                Log.d(TAG, "Stock Opname Initialize: Queried '$COLLECTION_PRODUCTS', found $totalDocsFound documents")

                for (doc in productsSnap.documents) {
                    try {
                        val p = try { doc.toObject(Product::class.java) } catch (_: Exception) { null }

                        val rawSku = (doc.getString("sku")
                            ?: doc.getString("skuCode")
                            ?: doc.getString("itemCode")
                            ?: doc.getString("code")
                            ?: doc.getString("productId")
                            ?: p?.sku
                            ?: doc.id).trim()

                        if (rawSku.isBlank()) continue

                        val rawName = (doc.getString("itemName")
                            ?: doc.getString("name")
                            ?: doc.getString("productName")
                            ?: doc.getString("title")
                            ?: p?.itemName
                            ?: rawSku).trim()

                        val rawFamily = (doc.getString("familyCode")
                            ?: doc.getString("family")
                            ?: doc.getString("category")
                            ?: p?.familyCode
                            ?: "").trim()

                        // Stock = 0 is explicitly valid in Stock Opname
                        val rawStock = when (val s = doc.get("stock") ?: doc.get("qty") ?: doc.get("currentStock")) {
                            is Number -> s.toInt()
                            is String -> s.toIntOrNull() ?: 0
                            else -> p?.stock ?: 0
                        }

                        // Determine active status:
                        // 1. isDeleted
                        val isDeleted = doc.getBoolean("isDeleted") ?: false
                        if (isDeleted) continue

                        // 2. Status string: "ACTIVE", "AKTIF", "Active", "enabled", "1"
                        val statusStr = (doc.getString("status")
                            ?: doc.getString("productStatus")
                            ?: doc.getString("state")
                            ?: p?.status)?.trim()?.uppercase()

                        // 3. Boolean flags
                        val boolActive = doc.getBoolean("isActive")
                            ?: doc.getBoolean("active")
                            ?: doc.getBoolean("is_active")

                        val isActive = when {
                            !statusStr.isNullOrBlank() -> {
                                statusStr == "ACTIVE" || statusStr == "AKTIF" || statusStr == "TRUE" || statusStr == "1" || statusStr == "ENABLED"
                            }
                            boolActive != null -> boolActive
                            p != null -> p.isProductActive
                            else -> true
                        }

                        val prod = Product(
                            productId = if (p?.productId?.isNotBlank() == true) p.productId else doc.id,
                            sku = rawSku,
                            familyCode = rawFamily,
                            itemName = if (rawName.isNotBlank()) rawName else rawSku,
                            stock = rawStock,
                            purchasingPrice = when (val h = doc.get("purchasingPrice") ?: doc.get("hpp")) {
                                is Number -> h.toLong()
                                is String -> h.toLongOrNull() ?: 0L
                                else -> p?.purchasingPrice ?: 0L
                            },
                            netPrice = when (val n = doc.get("netPrice") ?: doc.get("price")) {
                                is Number -> n.toLong()
                                is String -> n.toLongOrNull() ?: 0L
                                else -> p?.netPrice ?: 0L
                            },
                            active = isActive,
                            status = statusStr ?: (if (isActive) "ACTIVE" else "INACTIVE"),
                            createdAt = p?.createdAt ?: doc.getTimestamp("createdAt"),
                            updatedAt = p?.updatedAt ?: doc.getTimestamp("updatedAt")
                        )
                        parsedProducts.add(prod)
                    } catch (e: Exception) {
                        Log.w(TAG, "Error parsing document ${doc.id}: ${e.message}")
                        parseErrors.add("${doc.id}: ${e.message}")
                    }
                }
            } catch (fe: com.google.firebase.firestore.FirebaseFirestoreException) {
                Log.e(TAG, "Firestore error fetching master products: ${fe.message}", fe)
                val msg = when (fe.code) {
                    com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                        "Akses ke master data produk ditolak (Firestore Permission Denied). Periksa izin akun Anda."
                    com.google.firebase.firestore.FirebaseFirestoreException.Code.UNAVAILABLE ->
                        "Koneksi database Firestore terputus (Offline / Network Error). Periksa koneksi internet Anda."
                    else ->
                        "Gagal membaca master produk dari Firestore: ${fe.localizedMessage ?: fe.message}"
                }
                return Result.failure(Exception(msg))
            } catch (e: Exception) {
                Log.e(TAG, "General error fetching master products: ${e.message}", e)
                return Result.failure(Exception("Gagal mengambil data produk master: ${e.localizedMessage ?: "Terjadi kesalahan sistem"}"))
            }

            // Fallback to active inventory products or productRepo if Firestore direct query returned 0 products
            if (parsedProducts.isEmpty()) {
                if (fallbackProducts.isNotEmpty()) {
                    Log.d(TAG, "Using fallbackProducts (${fallbackProducts.size} items) from active Inventory state")
                    parsedProducts.addAll(fallbackProducts)
                    totalDocsFound = fallbackProducts.size
                } else if (productRepo != null) {
                    try {
                        val repoProducts = productRepo.getAllProducts()
                        if (repoProducts.isNotEmpty()) {
                            Log.d(TAG, "Using products from ProductRepository.getAllProducts(): ${repoProducts.size} items")
                            parsedProducts.addAll(repoProducts)
                            totalDocsFound = repoProducts.size
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed fallback to productRepo: ${e.message}")
                    }
                }
            }

            // Deduplicate by SKU
            val uniqueProducts = parsedProducts.distinctBy { it.sku }

            // Filter active SKUs (preserving products with stock == 0 as valid inventory items)
            val eligibleProducts = uniqueProducts.filter { prod ->
                prod.isProductActive && prod.sku.isNotBlank()
            }

            Log.d(TAG, "Stock Opname Initialize: Total unique parsed: ${uniqueProducts.size}, Eligible active SKUs: ${eligibleProducts.size}")

            if (eligibleProducts.isEmpty()) {
                val errorMsg = if (totalDocsFound == 0) {
                    "Tidak ada produk dalam master data (0 item ditemukan). Silakan tambahkan produk terlebih dahulu di menu Inventory."
                } else {
                    "Tidak ada produk aktif dalam master data untuk Stock Opname ($totalDocsFound produk ditemukan di database, namun tidak ada yang berstatus aktif). Periksa status keaktifan produk di menu Inventory."
                }
                return Result.failure(IllegalStateException(errorMsg))
            }

            // Generate atomic daily sequence document number
            val createdSop = db.runTransaction { transaction ->
                // READ PHASE
                val counterSnap = transaction.get(counterRef)
                val currentSeq = if (counterSnap.exists()) counterSnap.getLong("current") ?: 0L else 0L
                val nextSeq = currentSeq + 1L
                val docNo = String.format("SOP-%s-%03d", dateStr, nextSeq)

                // WRITE PHASE
                transaction.set(
                    counterRef,
                    mapOf("current" to nextSeq, "date" to dateStr, "updatedAt" to Timestamp.now())
                )

                val snapshotItems = eligibleProducts.sortedBy { it.sku }.map { prod ->
                    StockOpnameItem(
                        skuId = prod.sku,
                        skuCode = prod.sku,
                        itemName = prod.itemName,
                        systemQtySnapshot = prod.stock,
                        physicalQty = null,
                        isCounted = false,
                        countedBy = "",
                        countedAt = null,
                        adjustmentQty = 0,
                        adjustmentReason = "",
                        adjustedBy = "",
                        adjustedAt = null
                    )
                }

                val sopDocRef = db.collection(COLLECTION_SOP).document(docNo)
                val newSop = StockOpname(
                    sopId = docNo,
                    documentNo = docNo,
                    opnameDate = displayDate,
                    status = "OPEN",
                    initializedBy = user,
                    initializedAt = Timestamp.now(),
                    totalSku = snapshotItems.size,
                    items = snapshotItems,
                    notes = notes.trim()
                )
                transaction.set(
                    sopDocRef,
                    mapOf(
                        "sopId" to docNo,
                        "documentNo" to docNo,
                        "opnameDate" to displayDate,
                        "status" to "OPEN",
                        "initializedBy" to user,
                        "initializedAt" to Timestamp.now(),
                        "totalSku" to snapshotItems.size,
                        "items" to snapshotItems.map { it.toFirestoreMap() },
                        "notes" to notes.trim(),
                        "postingId" to "",
                        "postedBy" to "",
                        "postedAt" to null
                    )
                )

                // Create Audit Trail
                val auditRef = db.collection(COLLECTION_AUDIT_TRAILS).document()
                val audit = AuditTrail(
                    auditId = auditRef.id,
                    userId = user,
                    role = role,
                    action = "INITIALIZE_STOCK_OPNAME",
                    documentId = docNo,
                    documentNo = docNo,
                    reason = "Inisialisasi Stock Opname dengan snapshot ${snapshotItems.size} SKU",
                    timestamp = Timestamp.now()
                )
                transaction.set(auditRef, audit)

                newSop
            }.await()

            Log.d(TAG, "Stock Opname initialized: ${createdSop.documentNo}")
            Result.success(createdSop)
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Stock Opname: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Cancels an OPEN Stock Opname document.
     * Transitions status to CANCELLED.
     */
    suspend fun cancelStockOpname(
        sopId: String,
        reason: String,
        user: String,
        role: String
    ): Result<Unit> {
        return try {
            val sopRef = db.collection(COLLECTION_SOP).document(sopId)
            val cleanReason = reason.ifBlank { "Dibatalkan oleh $user" }
            db.runTransaction { transaction ->
                val snap = transaction.get(sopRef)
                if (!snap.exists()) {
                    throw IllegalStateException("Dokumen Stock Opname $sopId tidak ditemukan")
                }
                val sop = parseStockOpname(snap)
                    ?: throw IllegalStateException("Format data Stock Opname tidak valid")

                if (sop.status != "OPEN") {
                    throw IllegalStateException("Hanya Stock Opname berstatus OPEN yang dapat dibatalkan (Status saat ini: ${sop.status})")
                }

                transaction.update(
                    sopRef,
                    mapOf(
                        "status" to "CANCELLED",
                        "cancelReason" to cleanReason,
                        "cancelledBy" to user,
                        "cancelledAt" to Timestamp.now(),
                        "updatedBy" to user,
                        "updatedAt" to Timestamp.now()
                    )
                )

                val auditRef = db.collection(COLLECTION_AUDIT_TRAILS).document()
                val audit = AuditTrail(
                    auditId = auditRef.id,
                    userId = user,
                    role = role,
                    action = "CANCEL_STOCK_OPNAME",
                    documentId = sopId,
                    documentNo = sop.documentNo,
                    reason = "Stock Opname dibatalkan: $cleanReason",
                    timestamp = Timestamp.now()
                )
                transaction.set(auditRef, audit)
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error canceling Stock Opname: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Records counting for an individual SKU in a multi-user safe transaction.
     * Accessible by Root Admin, Admin Gudang, and Staff Gudang while status is OPEN or COUNTING.
     * DOES NOT modify stock balance.
     */
    suspend fun saveItemCount(
        sopId: String,
        sku: String,
        physicalQty: Int,
        user: String,
        role: String
    ): Result<Unit> {
        return try {
            if (physicalQty < 0) {
                return Result.failure(IllegalArgumentException("Qty fisik tidak boleh negatif"))
            }

            val sopRef = db.collection(COLLECTION_SOP).document(sopId)

            db.runTransaction { transaction ->
                // READ PHASE
                val snap = transaction.get(sopRef)
                if (!snap.exists()) {
                    throw IllegalStateException("Dokumen Stock Opname $sopId tidak ditemukan")
                }
                val sop = parseStockOpname(snap)
                    ?: throw IllegalStateException("Format data Stock Opname tidak valid")

                if (sop.status != "OPEN" && sop.status != "COUNTING") {
                    throw IllegalStateException("Penghitungan fisik dikunci karena status dokumen sudah ${sop.status}")
                }

                val currentItems = sop.items.toMutableList()
                val itemIndex = currentItems.indexOfFirst { it.skuId == sku || it.skuCode == sku }
                if (itemIndex == -1) {
                    throw IllegalStateException("SKU $sku tidak ditemukan pada snapshot Stock Opname ini")
                }

                val existingItem = currentItems[itemIndex]
                val oldPhysical = existingItem.physicalQty
                val difference = physicalQty - existingItem.systemQtySnapshot

                val updatedItem = existingItem.copy(
                    physicalQty = physicalQty,
                    isCounted = true,
                    countedBy = user,
                    countedAt = Timestamp.now(),
                    adjustmentQty = difference
                )
                currentItems[itemIndex] = updatedItem

                // WRITE PHASE
                transaction.update(
                    sopRef,
                    mapOf(
                        "items" to currentItems.map { it.toFirestoreMap() },
                        "status" to "COUNTING"
                    )
                )

                val auditRef = db.collection(COLLECTION_AUDIT_TRAILS).document()
                val audit = AuditTrail(
                    auditId = auditRef.id,
                    userId = user,
                    role = role,
                    action = "COUNT_STOCK_OPNAME",
                    documentId = sopId,
                    documentNo = sop.documentNo,
                    oldPhysicalQty = oldPhysical,
                    newPhysicalQty = physicalQty,
                    reason = "Counting SKU: $sku, Qty: $physicalQty pcs",
                    timestamp = Timestamp.now()
                )
                transaction.set(auditRef, audit)
            }.await()

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving item count: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Finishes Stock Opname counting phase.
     * Validates that all snapshot SKUs have been counted.
     * Transitions status to COUNTING_COMPLETED.
     * DOES NOT modify stock balance.
     */
    suspend fun completeCounting(
        sopId: String,
        user: String,
        role: String
    ): Result<StockOpname> {
        return try {
            val sopRef = db.collection(COLLECTION_SOP).document(sopId)

            val updatedSop = db.runTransaction { transaction ->
                // READ PHASE
                val snap = transaction.get(sopRef)
                if (!snap.exists()) {
                    throw IllegalStateException("Dokumen Stock Opname $sopId tidak ditemukan")
                }
                val sop = parseStockOpname(snap)
                    ?: throw IllegalStateException("Format data Stock Opname tidak valid")

                if (sop.status != "OPEN" && sop.status != "COUNTING") {
                    throw IllegalStateException("Stock Opname sudah berstatus ${sop.status}")
                }

                val uncountedItems = sop.items.filter { !it.hasBeenCounted }
                if (uncountedItems.isNotEmpty()) {
                    throw IllegalStateException(
                        "Stock Opname belum dapat diselesaikan.\n${uncountedItems.size} SKU belum dihitung."
                    )
                }

                // WRITE PHASE
                transaction.update(
                    sopRef,
                    mapOf(
                        "status" to "COUNTING_COMPLETED",
                        "countingCompletedBy" to user,
                        "countingCompletedAt" to Timestamp.now()
                    )
                )

                val auditRef = db.collection(COLLECTION_AUDIT_TRAILS).document()
                val audit = AuditTrail(
                    auditId = auditRef.id,
                    userId = user,
                    role = role,
                    action = "COMPLETE_STOCK_OPNAME",
                    documentId = sopId,
                    documentNo = sop.documentNo,
                    reason = "Counting selesai untuk seluruh ${sop.items.size} SKU",
                    timestamp = Timestamp.now()
                )
                transaction.set(auditRef, audit)

                sop.copy(
                    status = "COUNTING_COMPLETED",
                    countingCompletedBy = user,
                    countingCompletedAt = Timestamp.now()
                )
            }.await()

            Result.success(updatedSop)
        } catch (e: Exception) {
            Log.e(TAG, "Error completing counting: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Records an adjustment per SKU (ROOT ADMIN ONLY).
     * Difference can be negative, positive, or zero - all are valid!
     * DOES NOT modify stock balance.
     */
    suspend fun saveAdjustment(
        sopId: String,
        sku: String,
        newPhysicalQty: Int,
        reason: String,
        user: String,
        role: String
    ): Result<StockOpname> {
        return try {
            if (!isRootAdmin(role)) {
                return Result.failure(SecurityException("Hanya Root Admin yang berhak melakukan Adjustment Stock Opname (Role: '$role')"))
            }
            if (newPhysicalQty < 0) {
                return Result.failure(IllegalArgumentException("Real physical stock tidak boleh negatif"))
            }

            val sopRef = db.collection(COLLECTION_SOP).document(sopId)

            val updatedSop = db.runTransaction { transaction ->
                // READ PHASE
                val snap = transaction.get(sopRef)
                if (!snap.exists()) {
                    throw IllegalStateException("Dokumen Stock Opname $sopId tidak ditemukan")
                }
                val sop = parseStockOpname(snap)
                    ?: throw IllegalStateException("Format data Stock Opname tidak valid")

                if (sop.status != "COUNTING_COMPLETED" && sop.status != "ADJUSTMENT") {
                    throw IllegalStateException("Adjustment hanya dapat dilakukan pada dokumen berstatus COUNTING_COMPLETED atau ADJUSTMENT (Status: ${sop.status})")
                }

                val currentItems = sop.items.toMutableList()
                val itemIndex = currentItems.indexOfFirst { it.skuId == sku || it.skuCode == sku }
                if (itemIndex == -1) {
                    throw IllegalStateException("SKU $sku tidak ditemukan pada dokumen Stock Opname ini")
                }

                val existing = currentItems[itemIndex]
                val oldPhysical = existing.physicalQty ?: existing.systemQtySnapshot
                val oldAdj = existing.adjustmentQty
                val newAdj = newPhysicalQty - existing.systemQtySnapshot // negative, positive, or zero

                val updatedItem = existing.copy(
                    physicalQty = newPhysicalQty,
                    isCounted = true,
                    adjustmentQty = newAdj,
                    adjustmentReason = reason.trim(),
                    adjustedBy = user,
                    adjustedAt = Timestamp.now()
                )
                currentItems[itemIndex] = updatedItem

                // WRITE PHASE
                transaction.update(
                    sopRef,
                    mapOf(
                        "items" to currentItems.map { it.toFirestoreMap() },
                        "status" to "ADJUSTMENT"
                    )
                )

                val auditRef = db.collection(COLLECTION_AUDIT_TRAILS).document()
                val audit = AuditTrail(
                    auditId = auditRef.id,
                    userId = user,
                    role = role,
                    action = "ADJUST_STOCK_OPNAME",
                    documentId = sopId,
                    documentNo = sop.documentNo,
                    oldPhysicalQty = oldPhysical,
                    newPhysicalQty = newPhysicalQty,
                    oldAdjustment = oldAdj,
                    newAdjustment = newAdj,
                    reason = reason.trim().ifBlank { "Penyesuaian hasil opname SKU $sku" },
                    timestamp = Timestamp.now()
                )
                transaction.set(auditRef, audit)

                sop.copy(items = currentItems, status = "ADJUSTMENT")
            }.await()

            Result.success(updatedSop)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving adjustment: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Atomically posts the Stock Opname (ROOT ADMIN ONLY).
     * STRICT IDEMPOTENT TWO-PHASE FIRESTORE TRANSACTION:
     * 1. READ PHASE:
     *    - Read and validate SOP (must be COUNTING_COMPLETED or ADJUSTMENT; not already POSTED)
     *    - Read POST daily sequence counter
     *    - Read ALL product documents to check live stock and intermediate movements
     * 2. WRITE PHASE:
     *    - Generate atomic POST-YYYYMMDD-XXX document number
     *    - Update live product stock to final physical count
     *    - Create StockMovement ledger entries
     *    - Create SopPosting document
     *    - Update SOP status to POSTED (read-only immutable)
     *    - Create AuditTrail
     */
    suspend fun postStockOpname(
        sopId: String,
        user: String,
        role: String
    ): Result<SopPosting> {
        return try {
            if (!isRootAdmin(role)) {
                return Result.failure(SecurityException("Hanya Root Admin yang berhak melakukan Posting Stock Opname (Role: '$role')"))
            }

            val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
            val displayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val postCounterDocId = "post_counter_$dateStr"
            val postCounterRef = db.collection(COLLECTION_COUNTERS).document(postCounterDocId)
            val sopRef = db.collection(COLLECTION_SOP).document(sopId)

            val createdPosting = db.runTransaction { transaction ->
                // ==========================================
                // 1. READ PHASE: All reads executed first
                // ==========================================

                // Read 1: SOP Document
                val sopSnap = transaction.get(sopRef)
                if (!sopSnap.exists()) {
                    throw IllegalStateException("Dokumen Stock Opname $sopId tidak ditemukan")
                }
                val sop = parseStockOpname(sopSnap)
                    ?: throw IllegalStateException("Format data Stock Opname tidak valid")

                // Idempotency validation
                if (sop.status == "POSTED" || sop.postingId.isNotBlank()) {
                    throw IllegalStateException("Posting sudah dilakukan untuk dokumen ${sop.documentNo}")
                }
                if (sop.status != "COUNTING_COMPLETED" && sop.status != "ADJUSTMENT") {
                    throw IllegalStateException("Posting hanya dapat dilakukan jika status COUNTING_COMPLETED atau ADJUSTMENT (Status saat ini: ${sop.status})")
                }

                // Verify all items are counted
                val uncounted = sop.items.filter { !it.hasBeenCounted }
                if (uncounted.isNotEmpty()) {
                    throw IllegalStateException("Terdapat ${uncounted.size} SKU yang belum selesai dihitung")
                }

                // Read 2: POST Counter Document
                val counterSnap = transaction.get(postCounterRef)

                // Read 3: Read ALL product documents to fetch current live stocks
                val productMap = mutableMapOf<String, Product>()
                for (item in sop.items) {
                    val prodRef = db.collection(COLLECTION_PRODUCTS).document(item.skuId)
                    val prodSnap = transaction.get(prodRef)
                    if (prodSnap.exists()) {
                        val p = try { prodSnap.toObject(Product::class.java) } catch (_: Exception) { null }
                        val stockVal = when (val s = prodSnap.get("stock")) {
                            is Number -> s.toInt()
                            is String -> s.toIntOrNull() ?: 0
                            else -> p?.stock ?: item.systemQtySnapshot
                        }
                        val prod = (p ?: Product(productId = item.skuId, sku = item.skuId, itemName = item.itemName)).copy(stock = stockVal)
                        productMap[item.skuId] = prod
                    }
                }

                // ==========================================
                // 2. WRITE PHASE: All writes executed after reads
                // ==========================================

                val currentPostSeq = if (counterSnap.exists()) counterSnap.getLong("current") ?: 0L else 0L
                val nextPostSeq = currentPostSeq + 1L
                val postDocNo = String.format("POST-%s-%03d", dateStr, nextPostSeq)

                // Write 1: Update POST daily counter
                transaction.set(
                    postCounterRef,
                    mapOf("current" to nextPostSeq, "date" to dateStr, "updatedAt" to Timestamp.now())
                )

                // Write 2: Process Stock updates and ledger
                val postingItems = mutableListOf<PostingItem>()
                var totalSurplus = 0
                var totalShortage = 0

                for (item in sop.items) {
                    val liveProd = productMap[item.skuId]
                    val stockBefore = liveProd?.stock ?: item.systemQtySnapshot
                    val physicalCount = item.physicalQty ?: item.systemQtySnapshot

                    // Discrepancy based on opname: physical - snapshot
                    val opnameDifference = physicalCount - item.systemQtySnapshot

                    // Safe cut-off calculation:
                    // If intermediate warehouse transactions (e.g. DO / Receiving) occurred after snapshot,
                    // apply the opname discrepancy to current stock: stockAfter = stockBefore + opnameDifference.
                    // If no intermediate transactions occurred, stockBefore == systemQtySnapshot, so stockAfter == physicalCount!
                    val calculatedAfter = if (stockBefore == item.systemQtySnapshot) {
                        physicalCount
                    } else {
                        // Intermediate movement detected: preserve warehouse transactions
                        (stockBefore + opnameDifference).coerceAtLeast(0)
                    }

                    if (opnameDifference > 0) totalSurplus += opnameDifference
                    if (opnameDifference < 0) totalShortage += (-opnameDifference)

                    val prodRef = db.collection(COLLECTION_PRODUCTS).document(item.skuId)
                    transaction.update(
                        prodRef,
                        mapOf(
                            "stock" to calculatedAfter,
                            "updatedAt" to Timestamp.now(),
                            "updatedBy" to user
                        )
                    )

                    // Stock Movement / Ledger record
                    val movementRef = db.collection(COLLECTION_MOVEMENTS).document()
                    val movement = StockMovement(
                        movementId = movementRef.id,
                        date = displayDate,
                        itemCode = item.skuId,
                        itemNameSnapshot = item.itemName,
                        type = MovementType.STOCK_OPNAME.name,
                        referenceId = postDocNo,
                        qtyIn = if (opnameDifference > 0) opnameDifference else 0,
                        qtyOut = if (opnameDifference < 0) -opnameDifference else 0,
                        previousStock = stockBefore,
                        newStock = calculatedAfter,
                        reason = "STOCK_OPNAME (Ref: ${sop.documentNo}, Post: $postDocNo, Diff: $opnameDifference)",
                        user = user,
                        timestamp = Timestamp.now()
                    )
                    transaction.set(movementRef, movement)

                    postingItems.add(
                        PostingItem(
                            sku = item.skuId,
                            itemName = item.itemName,
                            stockBefore = stockBefore,
                            physicalCount = physicalCount,
                            adjustment = opnameDifference,
                            stockAfter = calculatedAfter
                        )
                    )
                }

                val netDiff = sop.items.sumOf { (it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot }

                // Write 3: Create SopPosting document
                val postingDocRef = db.collection(COLLECTION_POSTINGS).document(postDocNo)
                val newPosting = SopPosting(
                    postingId = postDocNo,
                    documentNo = postDocNo,
                    sopId = sop.sopId,
                    sopDocumentNo = sop.documentNo,
                    date = displayDate,
                    postedBy = user,
                    postedAt = Timestamp.now(),
                    totalSku = postingItems.size,
                    totalSurplus = totalSurplus,
                    totalShortage = totalShortage,
                    netDifference = netDiff,
                    items = postingItems
                )
                transaction.set(postingDocRef, newPosting)

                // Write 4: Update SOP document to POSTED
                transaction.update(
                    sopRef,
                    mapOf(
                        "status" to "POSTED",
                        "postingId" to postDocNo,
                        "postedBy" to user,
                        "postedAt" to Timestamp.now()
                    )
                )

                // Write 5: Audit Trail
                val auditRef = db.collection(COLLECTION_AUDIT_TRAILS).document()
                val audit = AuditTrail(
                    auditId = auditRef.id,
                    userId = user,
                    role = role,
                    action = "POST_STOCK_OPNAME",
                    documentId = postDocNo,
                    documentNo = postDocNo,
                    reason = "Posting Stock Opname ${sop.documentNo} dengan nomor posting $postDocNo (Net Difference: $netDiff)",
                    timestamp = Timestamp.now()
                )
                transaction.set(auditRef, audit)

                newPosting
            }.await()

            Log.d(TAG, "Stock Opname posted successfully: ${createdPosting.documentNo}")
            Result.success(createdPosting)
        } catch (e: Exception) {
            Log.e(TAG, "Error posting Stock Opname: ${e.message}", e)
            Result.failure(e)
        }
    }
}
