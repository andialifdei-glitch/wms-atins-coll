package com.example.data.models

import com.google.firebase.Timestamp
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
data class RajaOngkirConfigMetadata(
    val configured: Boolean = false,
    val provider: String = "RajaOngkir",
    val updatedAt: Timestamp? = null,
    val updatedBy: String = "",
    val activeKeyMasked: String = "••••••••••••••••"
)

sealed class TestApiKeyResult {
    data object Success : TestApiKeyResult()
    data class InvalidKey(val message: String = "RajaOngkir menolak API Key yang diberikan.") : TestApiKeyResult()
    data class QuotaExceeded(val message: String = "Batas penggunaan / kuota harian RajaOngkir telah tercapai.") : TestApiKeyResult()
    data class Forbidden(val message: String = "Akses ditolak (Forbidden) oleh server RajaOngkir.") : TestApiKeyResult()
    data class ServerError(val message: String = "Terjadi gangguan pada server RajaOngkir.") : TestApiKeyResult()
    data class NetworkError(val message: String = "Tidak dapat terhubung ke server RajaOngkir.") : TestApiKeyResult()
}
