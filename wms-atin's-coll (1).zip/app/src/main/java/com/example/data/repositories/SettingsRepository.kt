package com.example.data.repositories

import android.util.Log
import com.example.data.models.StoreSettings
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class SettingsRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "SettingsRepository"
        const val COLLECTION_SETTINGS = "settings"
        const val DOC_STORE_INFO = "store_info"
    }

    private val _settings = MutableStateFlow(StoreSettings())
    val settings: StateFlow<StoreSettings> = _settings.asStateFlow()

    suspend fun loadSettings(): StoreSettings {
        return try {
            val doc = db.collection(COLLECTION_SETTINGS).document(DOC_STORE_INFO).get().await()
            if (doc.exists()) {
                val s = doc.toObject(StoreSettings::class.java) ?: StoreSettings()
                _settings.value = s
                s
            } else {
                val defaultSettings = StoreSettings()
                db.collection(COLLECTION_SETTINGS).document(DOC_STORE_INFO).set(defaultSettings).await()
                _settings.value = defaultSettings
                defaultSettings
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading settings: ${e.message}")
            _settings.value
        }
    }

    suspend fun updateSettings(
        newSettings: StoreSettings,
        userRole: String = "",
        user: String = ""
    ): Result<Unit> {
        if (userRole.isNotBlank() && userRole != com.example.data.models.UserRole.ROOT_ADMIN.label) {
            return Result.failure(SecurityException("Hanya Root Admin yang berhak mengubah informasi dan alamat toko"))
        }
        val settingsToSave = newSettings.copy(
            updatedAt = com.google.firebase.Timestamp.now(),
            updatedBy = user.ifBlank { newSettings.updatedBy }
        )
        return try {
            db.collection(COLLECTION_SETTINGS).document(DOC_STORE_INFO).set(settingsToSave).await()
            _settings.value = settingsToSave
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating settings: ${e.message}")
            Result.failure(e)
        }
    }
}
