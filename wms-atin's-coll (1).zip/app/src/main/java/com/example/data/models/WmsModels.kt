package com.example.data.models

import com.google.firebase.Timestamp
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName

enum class UserRole(val label: String) {
    ROOT_ADMIN("Root Admin"),
    ADMIN_GUDANG("Admin Gudang"),
    STAFF_GUDANG("Staff Gudang")
}

@IgnoreExtraProperties
data class UserAccount(
    val userId: String = "",
    val name: String = "",
    val role: String = UserRole.STAFF_GUDANG.label,
    val firebaseUid: String = "",
    val email: String = "",
    val passwordHash: String = "", // Deprecated: Kept only for legacy migration, never written
    val salt: String = "",         // Deprecated: Kept only for legacy migration, never written
    val isActive: Boolean = true,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Family(
    val familyId: String = "",
    val familyCode: String = "", // e.g., FAM-001
    val familyName: String = "",
    val isActive: Boolean = true,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null,
    val createdBy: String = "",
    val updatedBy: String = ""
)

@IgnoreExtraProperties
data class Product(
    val productId: String = "",
    val sku: String = "", // e.g., SKU-001001
    val familyCode: String = "", // e.g., FAM-001
    val itemName: String = "",
    val lastReceiving: String = "-",
    val stock: Int = 0,
    val purchasingPrice: Long = 0L,
    val netPrice: Long = 0L,
    val weightInGrams: Int = 0, // Product weight in grams
    @get:PropertyName("active")
    val active: Boolean? = null,
    val status: String = "", // e.g. "ACTIVE", "INACTIVE", "AKTIF"
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null,
    val createdBy: String = "",
    val updatedBy: String = ""
) {
    /**
     * Master status label strictly following field `active` from the database:
     * - active = true -> "Aktif"
     * - active = false -> "Nonaktif"
     * - active = null / missing -> "Status Tidak Valid" (never assumed active)
     */
    @get:Exclude
    val masterStatusLabel: String
        get() = when (active) {
            true -> "Aktif"
            false -> "Nonaktif"
            null -> "Status Tidak Valid"
        }

    @get:Exclude
    val isProductActive: Boolean
        get() = active == true
}

@IgnoreExtraProperties
data class Region(
    val code: String = "",
    val name: String = "",
    val level: String = "", // PROVINCE, REGENCY, DISTRICT
    val parentCode: String? = null
)

@IgnoreExtraProperties
data class Customer(
    val customerId: String = "",
    val customerCode: String = "", // e.g., CS-001
    val customerName: String = "",
    val phone: String = "",
    val fullAddress: String = "",
    val addressDetail: String = "",
    val provinceCode: String = "",
    val provinceName: String = "",
    val regencyCode: String = "",
    val regencyName: String = "",
    val districtCode: String = "",
    val districtName: String = "",
    val status: String = "ACTIVE",
    val rajaOngkirDestinationId: Int? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    val displayAddress: String
        get() = when {
            addressDetail.isNotBlank() && districtName.isNotBlank() ->
                "$addressDetail, Kec. $districtName, $regencyName, Prov. $provinceName"
            fullAddress.isNotBlank() -> fullAddress
            else -> "-"
        }
}

@IgnoreExtraProperties
data class ShippingService(
    val shippingServiceId: String = "",
    val name: String = "",
    val isActive: Boolean = true,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class PoItem(
    val sku: String = "",
    val itemName: String = "",
    val qty: Int = 0,
    val purchasingPrice: Long = 0L,
    val subtotal: Long = 0L,
    val receivedQty: Int = 0,
    val weightInGrams: Int = 0
)

data class PurchaseOrder(
    val poId: String = "", // PO-20261003-00001
    val poDate: String = "",
    val supplier: String = "",
    val supplierAddress: String = "",
    val supplierPhone: String = "",
    val notes: String = "",
    val status: String = "CONFIRMED", // DRAFT, CONFIRMED, PARTIAL, COMPLETED, CANCELLED
    val items: List<PoItem> = emptyList(),
    val total: Long = 0L,
    val createdBy: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class ReceivingItem(
    val sku: String = "",
    val itemName: String = "",
    val qtyReceived: Int = 0,
    val purchasingPrice: Long = 0L,
    val weightInGrams: Int = 0
)

data class Receiving(
    val receivingId: String = "",
    val poId: String = "",
    val date: String = "",
    val items: List<ReceivingItem> = emptyList(),
    val notes: String = "",
    val createdBy: String = "",
    val createdAt: Timestamp? = null
)

data class SoItem(
    val sku: String = "",
    val itemName: String = "",
    val qty: Int = 1,
    val price: Long = 0L,
    val purchasingPriceSnapshot: Long = 0L,
    val subtotal: Long = 0L,
    val weightInGrams: Int = 0
)

data class SalesOrder(
    val soId: String = "", // SO-20261003-00001
    val date: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val phone: String = "",
    val address: String = "",
    val expedition: String = "",
    val items: List<SoItem> = emptyList(),
    val total: Long = 0L,
    val totalWeightInGrams: Int = 0,
    val shippingCost: Long = 0L,
    val shippingCourier: String = "",
    val shippingServiceName: String = "",
    val status: String = "CONFIRMED", // CONFIRMED, READY TO DELIVER, DELIVERY ORDER, CANCELLED
    val cancelReason: String = "",
    val createdBy: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class DeliveryOrder(
    val doId: String = "", // DO-20261003-00001
    val soId: String = "",
    val date: String = "",
    val expedition: String = "",
    val senderName: String = "Atin's Collection",
    val senderPhone: String = "0899-7884-435",
    val senderAddress: String = "",
    val recipientName: String = "",
    val recipientPhone: String = "",
    val recipientAddress: String = "",
    val totalItems: Int = 0,
    val totalPcs: Int = 0,
    val totalWeightInGrams: Int = 0,
    val shippingCost: Long = 0L,
    val shippingCourier: String = "",
    val shippingServiceName: String = "",
    val items: List<SoItem> = emptyList(),
    val isStockDeducted: Boolean = false,
    val createdBy: String = "",
    val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ShippingRate(
    val courier: String = "", // wahana, lion, spx
    val serviceCode: String = "",
    val serviceName: String = "", // Wahana Economy, Lion Parcel JagoPack, SPX Hemat
    val cost: Long = 0L,
    val etd: String = "",
    val isAvailable: Boolean = true,
    val message: String = ""
)

enum class MovementType {
    RECEIVING,
    ADJUSTMENT,
    DELIVERY,
    RETURN,
    BREAKAGE,
    STOCK_OPNAME
}

data class StockMovement(
    val movementId: String = "",
    val date: String = "",
    val itemCode: String = "",
    val itemNameSnapshot: String = "",
    val type: String = MovementType.RECEIVING.name,
    val referenceId: String = "",
    val qtyIn: Int = 0,
    val qtyOut: Int = 0,
    val previousStock: Int = 0,
    val newStock: Int = 0,
    val reason: String = "",
    val user: String = "",
    val timestamp: Timestamp? = null
)

@IgnoreExtraProperties
data class StockAdjustment(
    val adjustmentId: String = "",
    val date: String = "",
    val sku: String = "",
    val itemName: String = "",
    val currentStock: Int = 0,
    val adjustmentType: String = "INCREASE", // INCREASE, DECREASE
    val adjustmentQty: Int = 0,
    val newStock: Int = 0,
    val reason: String = "",
    val notes: String = "",
    val user: String = "",
    val status: String = "COMPLETED", // INITIALIZED, COMPLETED, CANCELLED
    val executedBy: String = "",
    val executedAt: Timestamp? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class ReturnRecord(
    val returnId: String = "",
    val reference: String = "",
    val customer: String = "",
    val sku: String = "",
    val itemName: String = "",
    val qty: Int = 0,
    val reason: String = "",
    val condition: String = "",
    val notes: String = "",
    val user: String = "",
    val createdAt: Timestamp? = null
)

data class BreakageRecord(
    val breakageId: String = "",
    val date: String = "",
    val sku: String = "",
    val itemName: String = "",
    val currentStock: Int = 0,
    val qty: Int = 0,
    val newStock: Int = 0,
    val reason: String = "",
    val notes: String = "",
    val user: String = "",
    val createdAt: Timestamp? = null
)

data class PromoPrice(
    val promoId: String = "",
    val sku: String = "",
    val itemName: String = "",
    val promoPrice: Long = 0L,
    val startDate: String = "",
    val endDate: String = "",
    val isActive: Boolean = true,
    val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StoreSettings(
    val storeName: String = "Atin's Collection",
    val storePhone: String = "0899-7884-435",
    val storeEmail: String = "cs@atinscoll.com",
    val storeAddress: String = "Bandung, Jawa Barat", // Legacy fallback address
    val detailAddress: String = "",
    val provinceCode: String = "",
    val provinceName: String = "",
    val regencyCode: String = "",
    val regencyName: String = "",
    val districtCode: String = "",
    val districtName: String = "",
    val villageCode: String = "",
    val villageName: String = "",
    val postalCode: String = "",
    val labelSize: String = "58mm", // 58mm, 80mm, 100mm
    val defaultPrinterAddress: String = "",
    val defaultPrinterName: String = "",
    val updatedAt: Timestamp? = null,
    val updatedBy: String = ""
) {
    /**
     * Checks if store has valid master-region based address (Section 8)
     */
    fun isRegionAddressComplete(): Boolean {
        return provinceCode.isNotBlank() &&
               provinceName.isNotBlank() &&
               regencyCode.isNotBlank() &&
               regencyName.isNotBlank() &&
               districtCode.isNotBlank() &&
               districtName.isNotBlank() &&
               villageCode.isNotBlank() &&
               villageName.isNotBlank() &&
               detailAddress.isNotBlank()
    }

    /**
     * Returns full formatted address.
     * Uses new region-based address as source of truth if available, otherwise falls back to legacy string.
     */
    fun getFullAddress(): String {
        return if (isRegionAddressComplete() || (districtName.isNotBlank() && regencyName.isNotBlank())) {
            buildString {
                if (detailAddress.isNotBlank()) append(detailAddress)
                if (villageName.isNotBlank()) {
                    if (isNotEmpty()) append(", ")
                    append("Desa/Kel. ").append(villageName)
                }
                if (districtName.isNotBlank()) {
                    if (isNotEmpty()) append(", ")
                    append("Kec. ").append(districtName)
                }
                if (regencyName.isNotBlank()) {
                    if (isNotEmpty()) append(", ")
                    append(regencyName)
                }
                if (provinceName.isNotBlank()) {
                    if (isNotEmpty()) append(", ")
                    append(provinceName)
                }
                if (postalCode.isNotBlank()) {
                    if (isNotEmpty()) append(" ").append(postalCode)
                }
            }.ifBlank { storeAddress }
        } else {
            storeAddress.ifBlank { "Atin's Collection, Banjaran, Kab. Bandung, Jawa Barat" }
        }
    }

    /**
     * Destination/Origin string suitable for shipping calculation (e.g. "Banjaran, Kabupaten Bandung")
     */
    fun getShippingOriginName(): String {
        return when {
            districtName.isNotBlank() && regencyName.isNotBlank() -> "$districtName, $regencyName"
            districtName.isNotBlank() -> districtName
            regencyName.isNotBlank() -> regencyName
            else -> "Banjaran"
        }
    }
}

@IgnoreExtraProperties
data class StockOpnameItem(
    val skuId: String = "",
    val skuCode: String = "",
    val itemName: String = "",
    val systemQtySnapshot: Int = 0,
    val physicalQty: Int? = null,
    @get:PropertyName("isCounted")
    @set:PropertyName("isCounted")
    @PropertyName("isCounted")
    var isCounted: Boolean = false,
    val countedBy: String = "",
    val countedAt: Timestamp? = null,
    val adjustmentQty: Int = 0,
    val adjustmentReason: String = "",
    val adjustedBy: String = "",
    val adjustedAt: Timestamp? = null
) {
    /**
     * Definitive condition: item has been counted if physicalQty is not null (including 0, 1, 10, etc.)
     * or isCounted is true.
     */
    val hasBeenCounted: Boolean
        get() = physicalQty != null || isCounted

    fun toFirestoreMap(): Map<String, Any?> = mapOf(
        "skuId" to skuId,
        "skuCode" to (if (skuCode.isNotBlank()) skuCode else skuId),
        "itemName" to itemName,
        "systemQtySnapshot" to systemQtySnapshot,
        "physicalQty" to physicalQty,
        "isCounted" to hasBeenCounted,
        "counted" to hasBeenCounted,
        "countedBy" to countedBy,
        "countedAt" to countedAt,
        "adjustmentQty" to adjustmentQty,
        "adjustmentReason" to adjustmentReason,
        "adjustedBy" to adjustedBy,
        "adjustedAt" to adjustedAt
    )
}

@IgnoreExtraProperties
data class StockOpname(
    val sopId: String = "", // SOP-YYYYMMDD-XXX
    val documentNo: String = "",
    val opnameDate: String = "",
    val status: String = "OPEN", // OPEN, COUNTING, COUNTING_COMPLETED, ADJUSTMENT, POSTED, CANCELLED
    val cancelReason: String = "",
    val cancelledBy: String = "",
    val cancelledAt: Timestamp? = null,
    val initializedBy: String = "",
    val initializedAt: Timestamp? = null,
    val countingCompletedBy: String = "",
    val countingCompletedAt: Timestamp? = null,
    val totalSku: Int = 0,
    val items: List<StockOpnameItem> = emptyList(),
    val postingId: String = "",
    val postedBy: String = "",
    val postedAt: Timestamp? = null,
    val notes: String = ""
)

@IgnoreExtraProperties
data class PostingItem(
    val sku: String = "",
    val itemName: String = "",
    val stockBefore: Int = 0,
    val physicalCount: Int = 0,
    val adjustment: Int = 0,
    val stockAfter: Int = 0
)

@IgnoreExtraProperties
data class SopPosting(
    val postingId: String = "", // POST-YYYYMMDD-XXX
    val documentNo: String = "",
    val sopId: String = "",
    val sopDocumentNo: String = "",
    val date: String = "",
    val postedBy: String = "",
    val postedAt: Timestamp? = null,
    val totalSku: Int = 0,
    val totalSurplus: Int = 0,
    val totalShortage: Int = 0,
    val netDifference: Int = 0,
    val items: List<PostingItem> = emptyList()
)

@IgnoreExtraProperties
data class AuditTrail(
    val auditId: String = "",
    val userId: String = "",
    val role: String = "",
    val action: String = "", // INITIALIZE_STOCK_OPNAME, COUNT_STOCK_OPNAME, COMPLETE_STOCK_OPNAME, ADJUST_STOCK_OPNAME, POST_STOCK_OPNAME
    val documentId: String = "",
    val documentNo: String = "",
    val oldPhysicalQty: Int? = null,
    val newPhysicalQty: Int? = null,
    val oldAdjustment: Int? = null,
    val newAdjustment: Int? = null,
    val reason: String = "",
    val timestamp: Timestamp? = null
)
