package com.example.data.repositories

import android.util.Log
import com.example.data.models.Customer
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class CustomerRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "CustomerRepository"
        const val COLLECTION_CUSTOMERS = "customers"
        const val COLLECTION_COUNTERS = "counters"
        const val DOC_CUSTOMER_COUNTER = "customer_code"
    }

    suspend fun addCustomer(
        name: String,
        phone: String,
        addressDetail: String,
        provinceCode: String,
        provinceName: String,
        regencyCode: String,
        regencyName: String,
        districtCode: String,
        districtName: String
    ): Result<Customer> {
        return try {
            val cleanName = name.trim()
            if (cleanName.isBlank()) return Result.failure(Exception("Nama customer tidak boleh kosong"))
            if (provinceCode.isBlank() || provinceName.isBlank()) return Result.failure(Exception("Provinsi wajib dipilih"))
            if (regencyCode.isBlank() || regencyName.isBlank()) return Result.failure(Exception("Kabupaten/Kota wajib dipilih"))
            if (districtCode.isBlank() || districtName.isBlank()) return Result.failure(Exception("Kecamatan wajib dipilih"))

            val counterRef = db.collection(COLLECTION_COUNTERS).document(DOC_CUSTOMER_COUNTER)
            val customer = db.runTransaction { transaction ->
                val counterSnap = transaction.get(counterRef)
                val currentNumber = if (counterSnap.exists()) {
                    counterSnap.getLong("currentNumber") ?: 0L
                } else {
                    0L
                }
                val nextNumber = currentNumber + 1L
                val customerCode = String.format("CS-%03d", nextNumber)

                transaction.set(counterRef, mapOf("currentNumber" to nextNumber))

                val docRef = db.collection(COLLECTION_CUSTOMERS).document()
                val fullAddress = if (addressDetail.isNotBlank()) {
                    "${addressDetail.trim()}, Kec. ${districtName.trim()}, ${regencyName.trim()}, Prov. ${provinceName.trim()}"
                } else {
                    "Kec. ${districtName.trim()}, ${regencyName.trim()}, Prov. ${provinceName.trim()}"
                }

                val newCustomer = Customer(
                    customerId = docRef.id,
                    customerCode = customerCode,
                    customerName = cleanName,
                    phone = phone.trim(),
                    fullAddress = fullAddress,
                    addressDetail = addressDetail.trim(),
                    provinceCode = provinceCode.trim(),
                    provinceName = provinceName.trim(),
                    regencyCode = regencyCode.trim(),
                    regencyName = regencyName.trim(),
                    districtCode = districtCode.trim(),
                    districtName = districtName.trim(),
                    status = "ACTIVE",
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )
                transaction.set(docRef, newCustomer)
                newCustomer
            }.await()

            Log.d(TAG, "Customer added successfully with code: ${customer.customerCode}")
            Result.success(customer)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding customer: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun addCustomer(name: String, phone: String, address: String): Result<Customer> {
        return try {
            val cleanName = name.trim()
            if (cleanName.isBlank()) return Result.failure(Exception("Nama customer tidak boleh kosong"))

            val counterRef = db.collection(COLLECTION_COUNTERS).document(DOC_CUSTOMER_COUNTER)
            val customer = db.runTransaction { transaction ->
                val counterSnap = transaction.get(counterRef)
                val currentNumber = if (counterSnap.exists()) {
                    counterSnap.getLong("currentNumber") ?: 0L
                } else {
                    0L
                }
                val nextNumber = currentNumber + 1L
                val customerCode = String.format("CS-%03d", nextNumber)
                transaction.set(counterRef, mapOf("currentNumber" to nextNumber))

                val docRef = db.collection(COLLECTION_CUSTOMERS).document()
                val newCustomer = Customer(
                    customerId = docRef.id,
                    customerCode = customerCode,
                    customerName = cleanName,
                    phone = phone.trim(),
                    fullAddress = address.trim(),
                    addressDetail = address.trim(),
                    status = "ACTIVE",
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )
                transaction.set(docRef, newCustomer)
                newCustomer
            }.await()

            Result.success(customer)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding customer: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun updateCustomer(customerId: String, name: String, phone: String, address: String): Result<Unit> {
        return try {
            db.collection(COLLECTION_CUSTOMERS).document(customerId).update(
                mapOf(
                    "customerName" to name.trim(),
                    "phone" to phone.trim(),
                    "fullAddress" to address.trim(),
                    "updatedAt" to Timestamp.now()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteCustomer(customerId: String): Result<Unit> {
        return try {
            db.collection(COLLECTION_CUSTOMERS).document(customerId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listenCustomers(): Flow<List<Customer>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_CUSTOMERS)
            .orderBy("customerName", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(Customer::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun getAllCustomers(): List<Customer> {
        return try {
            val snap = db.collection(COLLECTION_CUSTOMERS).get().await()
            snap.documents.mapNotNull { it.toObject(Customer::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
