package com.example.data.repositories

import android.util.Log
import com.example.data.firebase.AuthManager
import com.example.data.models.UserAccount
import com.example.data.models.UserRole
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class UserRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    companion object {
        private const val TAG = "UserRepository"
        const val COLLECTION_USERS = "users"
    }

    suspend fun createUser(
        userId: String,
        name: String,
        role: String,
        passwordPlain: String
    ): Result<UserAccount> {
        return try {
            val cleanId = userId.trim().lowercase()
            if (cleanId.isBlank()) return Result.failure(Exception("User ID tidak boleh kosong"))
            if (passwordPlain.trim().isBlank()) return Result.failure(Exception("Password tidak boleh kosong"))
            if (passwordPlain.trim().length < 6) return Result.failure(Exception("Password minimal 6 karakter"))

            val docRef = db.collection(COLLECTION_USERS).document(cleanId)
            val docSnap = docRef.get().await()
            if (docSnap.exists()) {
                return Result.failure(Exception("User ID '$cleanId' sudah digunakan"))
            }

            val email = AuthManager.userIdToEmail(cleanId)

            // Provision user in Firebase Authentication
            val authResult = auth.createUserWithEmailAndPassword(email, passwordPlain.trim()).await()
            val firebaseUid = authResult.user?.uid.orEmpty()

            val user = UserAccount(
                userId = cleanId,
                name = name.trim(),
                role = role,
                firebaseUid = firebaseUid,
                email = email,
                isActive = true,
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )

            // Save profile to Firestore without password or hash
            docRef.set(user).await()
            Log.d(TAG, "User $cleanId created with Firebase Authentication UID $firebaseUid")
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating user: ${e.message}", e)
            Result.failure(Exception("Gagal membuat user: ${e.localizedMessage ?: "Periksa koneksi"}"))
        }
    }

    suspend fun updateUser(
        userId: String,
        name: String,
        role: String,
        newPasswordPlain: String?
    ): Result<Unit> {
        return try {
            val docRef = db.collection(COLLECTION_USERS).document(userId)
            val updates = mutableMapOf<String, Any>(
                "name" to name.trim(),
                "role" to role,
                "updatedAt" to Timestamp.now(),
                "passwordHash" to FieldValue.delete(),
                "salt" to FieldValue.delete()
            )

            if (!newPasswordPlain.isNullOrBlank()) {
                if (auth.currentUser != null && auth.currentUser?.email == AuthManager.userIdToEmail(userId)) {
                    auth.currentUser?.updatePassword(newPasswordPlain.trim())?.await()
                }
            }

            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleUserStatus(userId: String, isActive: Boolean): Result<Unit> {
        return try {
            db.collection(COLLECTION_USERS).document(userId).update(
                mapOf(
                    "isActive" to isActive,
                    "updatedAt" to Timestamp.now()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteUser(userId: String): Result<Unit> {
        return try {
            db.collection(COLLECTION_USERS).document(userId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listenUsers(): Flow<List<UserAccount>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_USERS)
            .orderBy("userId", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "listenUsers error: ${error.message}", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(UserAccount::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }
}
