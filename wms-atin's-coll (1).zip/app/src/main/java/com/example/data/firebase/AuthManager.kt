package com.example.data.firebase

import android.util.Log
import com.example.data.models.UserAccount
import com.example.data.models.UserRole
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class AuthManager(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    companion object {
        private const val TAG = "AuthManager"
        private const val USERS_COLLECTION = "users"
        const val ROOT_ADMIN_ID = "admin"
        const val ROOT_ADMIN_DEFAULT_PASS = "rootadmin"
        private const val AUTH_DOMAIN = "wms.atinscoll.com"

        /**
         * Maps a local application User ID (e.g. 'admin', 'staff1') to a valid Firebase Authentication email.
         */
        fun userIdToEmail(userId: String): String {
            val clean = userId.trim().lowercase()
            return if (clean.contains("@")) clean else "$clean@$AUTH_DOMAIN"
        }
    }

    private val _currentUser = MutableStateFlow<UserAccount?>(null)
    val currentUser: StateFlow<UserAccount?> = _currentUser.asStateFlow()

    /**
     * Bootstraps the default Root Admin in Firebase Authentication and Firestore if not already present.
     * Ensures passwords are never stored in Firestore documents.
     */
    suspend fun bootstrapRootAdminIfNeeded(): Boolean {
        return try {
            val adminEmail = userIdToEmail(ROOT_ADMIN_ID)
            val docRef = db.collection(USERS_COLLECTION).document(ROOT_ADMIN_ID)
            val doc = docRef.get().await()

            var firebaseUid = ""

            // Step 1: Check existing profile in Firestore
            if (doc.exists()) {
                val existingUid = doc.getString("firebaseUid").orEmpty()
                if (existingUid.isNotBlank()) {
                    firebaseUid = existingUid
                }
            }

            // Step 2: Ensure Root Admin account exists in Firebase Authentication
            if (firebaseUid.isBlank()) {
                try {
                    val signInResult = auth.signInWithEmailAndPassword(adminEmail, ROOT_ADMIN_DEFAULT_PASS).await()
                    firebaseUid = signInResult.user?.uid.orEmpty()
                    Log.d(TAG, "Root Admin authenticated in Firebase: $firebaseUid")
                } catch (e: FirebaseAuthInvalidUserException) {
                    // Account does NOT exist in Firebase Auth yet, provision it now
                    try {
                        val createResult = auth.createUserWithEmailAndPassword(adminEmail, ROOT_ADMIN_DEFAULT_PASS).await()
                        firebaseUid = createResult.user?.uid.orEmpty()
                        Log.d(TAG, "Root Admin provisioned in Firebase Authentication: $firebaseUid")
                    } catch (ce: Exception) {
                        Log.w(TAG, "Provisioning root admin auth returned: ${ce.message}")
                    }
                } catch (e: FirebaseAuthUserCollisionException) {
                    firebaseUid = auth.currentUser?.uid.orEmpty()
                } catch (e: Exception) {
                    firebaseUid = auth.currentUser?.uid.orEmpty()
                }
            }

            // Step 3: Ensure Root Admin profile exists in Firestore with role 'Root Admin'
            if (!doc.exists()) {
                val admin = mapOf(
                    "userId" to ROOT_ADMIN_ID,
                    "name" to "Root Administrator",
                    "role" to UserRole.ROOT_ADMIN.label,
                    "firebaseUid" to firebaseUid,
                    "email" to adminEmail,
                    "isActive" to true,
                    "createdAt" to Timestamp.now(),
                    "updatedAt" to Timestamp.now()
                )
                docRef.set(admin).await()
                Log.d(TAG, "Root admin profile bootstrapped in Firestore without password fields")
            } else {
                val updates = mutableMapOf<String, Any>(
                    "role" to UserRole.ROOT_ADMIN.label,
                    "email" to adminEmail,
                    "isActive" to true,
                    "updatedAt" to Timestamp.now(),
                    "passwordHash" to FieldValue.delete(),
                    "salt" to FieldValue.delete()
                )
                if (firebaseUid.isNotBlank()) {
                    updates["firebaseUid"] = firebaseUid
                }
                docRef.update(updates).await()
                Log.d(TAG, "Verified and updated Root Admin Firestore profile")
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error bootstrapping root admin: ${e.message}", e)
            false
        }
    }

    /**
     * Authenticates a user via Firebase Authentication.
     * Passwords are strictly handled and hashed by Google Firebase Auth backend.
     * No plaintext passwords or hashes are ever saved or logged.
     */
    suspend fun login(userId: String, password: String): Result<UserAccount> {
        val cleanId = userId.trim().lowercase()
        if (cleanId.isBlank()) {
            return Result.failure(IllegalArgumentException("User ID tidak boleh kosong"))
        }
        if (password.isBlank()) {
            return Result.failure(IllegalArgumentException("Password tidak boleh kosong"))
        }

        return try {
            val email = userIdToEmail(cleanId)
            var firebaseUid: String = ""
            var signInSuccess = false

            // 1. Try Firebase Authentication sign-in
            try {
                val authResult = auth.signInWithEmailAndPassword(email, password.trim()).await()
                firebaseUid = authResult.user?.uid.orEmpty()
                signInSuccess = true
            } catch (authEx: Exception) {
                Log.d(TAG, "Direct sign-in attempt failed for User ID '$cleanId' (${authEx.javaClass.simpleName})")

                // Check if user document exists in Firestore
                val userDoc = db.collection(USERS_COLLECTION).document(cleanId).get().await()

                if (!userDoc.exists()) {
                    // Check if User ID is root admin
                    if (cleanId == ROOT_ADMIN_ID && password.trim() == ROOT_ADMIN_DEFAULT_PASS) {
                        try {
                            val createResult = auth.createUserWithEmailAndPassword(email, ROOT_ADMIN_DEFAULT_PASS).await()
                            firebaseUid = createResult.user?.uid.orEmpty()
                            val admin = mapOf(
                                "userId" to ROOT_ADMIN_ID,
                                "name" to "Root Administrator",
                                "role" to UserRole.ROOT_ADMIN.label,
                                "firebaseUid" to firebaseUid,
                                "email" to email,
                                "isActive" to true,
                                "createdAt" to Timestamp.now(),
                                "updatedAt" to Timestamp.now()
                            )
                            db.collection(USERS_COLLECTION).document(ROOT_ADMIN_ID).set(admin).await()
                            signInSuccess = true
                        } catch (ue: FirebaseAuthUserCollisionException) {
                            return Result.failure(Exception("Password salah. Silakan coba lagi."))
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed bootstrapping admin during login: ${e.message}", e)
                            return Result.failure(Exception("Gagal menginisialisasi akun Root Admin: ${e.localizedMessage ?: "Periksa koneksi"}"))
                        }
                    } else {
                        return Result.failure(Exception("User ID '$userId' tidak ditemukan."))
                    }
                } else {
                    // User exists in Firestore!
                    val existingUid = userDoc.getString("firebaseUid").orEmpty()
                    if (existingUid.isNotBlank() || authEx is FirebaseAuthInvalidCredentialsException) {
                        // User is already registered in Firebase Auth or password is wrong
                        return Result.failure(Exception("Password salah. Silakan coba lagi."))
                    }

                    // Only if user was never provisioned in Firebase Auth (e.g. legacy seed):
                    if (authEx is FirebaseAuthInvalidUserException) {
                        try {
                            val newAuth = auth.createUserWithEmailAndPassword(email, password.trim()).await()
                            firebaseUid = newAuth.user?.uid.orEmpty()
                            signInSuccess = true
                            userDoc.reference.update(
                                mapOf(
                                    "firebaseUid" to firebaseUid,
                                    "email" to email,
                                    "passwordHash" to FieldValue.delete(),
                                    "salt" to FieldValue.delete(),
                                    "updatedAt" to Timestamp.now()
                                )
                            ).await()
                            Log.d(TAG, "User $cleanId provisioned in Firebase Auth during first login")
                        } catch (collEx: FirebaseAuthUserCollisionException) {
                            return Result.failure(Exception("Password salah. Silakan coba lagi."))
                        } catch (e: Exception) {
                            Log.e(TAG, "Auth provisioning error: ${e.message}", e)
                            return Result.failure(Exception("Password salah. Silakan coba lagi."))
                        }
                    } else {
                        return Result.failure(Exception("Password salah. Silakan coba lagi."))
                    }
                }
            }

            if (!signInSuccess && firebaseUid.isBlank()) {
                return Result.failure(Exception("Gagal masuk. Periksa kembali User ID dan Password."))
            }

            // 2. Fetch and verify user profile from Firestore
            val doc = db.collection(USERS_COLLECTION).document(cleanId).get().await()
            if (!doc.exists()) {
                auth.signOut()
                return Result.failure(Exception("Profil pengguna '$userId' tidak ditemukan di database"))
            }

            var user = doc.toObject(UserAccount::class.java)
                ?: return Result.failure(Exception("Format profil pengguna tidak valid"))

            // Guarantee Root Admin role invariant
            if (cleanId == ROOT_ADMIN_ID && user.role != UserRole.ROOT_ADMIN.label) {
                user = user.copy(role = UserRole.ROOT_ADMIN.label)
                doc.reference.update("role", UserRole.ROOT_ADMIN.label).await()
            }

            if (!user.isActive) {
                auth.signOut()
                return Result.failure(Exception("Akun ini telah dinonaktifkan"))
            }

            // Clean up legacy password fields if present
            if (doc.contains("passwordHash") || doc.contains("salt")) {
                doc.reference.update(
                    mapOf(
                        "passwordHash" to FieldValue.delete(),
                        "salt" to FieldValue.delete()
                    )
                ).await()
            }

            val finalUser = user.copy(
                firebaseUid = if (firebaseUid.isNotBlank()) firebaseUid else user.firebaseUid,
                email = email
            )
            _currentUser.value = finalUser
            Result.success(finalUser)
        } catch (e: Exception) {
            Log.e(TAG, "Login error for $cleanId: ${e.message}", e)
            Result.failure(Exception(e.localizedMessage ?: "Gagal masuk: Periksa koneksi"))
        }
    }

    fun logout() {
        try {
            auth.signOut()
        } catch (ignored: Exception) {}
        _currentUser.value = null
    }
}
