package com.example.data.repositories

import android.util.Log
import com.example.data.models.MovementType
import com.example.data.models.PoItem
import com.example.data.models.Product
import com.example.data.models.PurchaseOrder
import com.example.data.models.Receiving
import com.example.data.models.ReceivingItem
import com.example.data.models.StockMovement
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReceivingRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "ReceivingRepository"
        const val COLLECTION_RECEIVINGS = "receivings"
        const val COLLECTION_PO = "purchase_orders"
        const val COLLECTION_PRODUCTS = "products"
        const val COLLECTION_MOVEMENTS = "stock_movements"
    }

    /**
     * Confirms receiving strictly based on an existing PO.
     * Increases stock, updates lastReceiving, creates stock movement records,
     * updates PO item received quantities, and marks PO status as COMPLETED or PARTIAL.
     */
    suspend fun processReceiving(
        poId: String,
        receivedItems: List<ReceivingItem>,
        notes: String,
        user: String
    ): Result<Receiving> {
        return try {
            if (receivedItems.isEmpty()) {
                return Result.failure(Exception("Item yang diterima tidak boleh kosong"))
            }

            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val receivingDocRef = db.collection(COLLECTION_RECEIVINGS).document()
            val receivingId = receivingDocRef.id
            val poDocRef = db.collection(COLLECTION_PO).document(poId)

            val receiving = db.runTransaction { transaction ->
                // ==========================================
                // 1. READ PHASE: All reads executed first
                // ==========================================

                // Read 1: Purchase Order Document
                val poSnap = transaction.get(poDocRef)
                if (!poSnap.exists()) {
                    throw IllegalStateException("Purchase Order $poId tidak ditemukan")
                }
                val po = poSnap.toObject(PurchaseOrder::class.java)
                    ?: throw IllegalStateException("Format data PO tidak valid")

                if (po.status == "CANCELLED") {
                    throw IllegalStateException("Purchase Order yang sudah dibatalkan tidak dapat diproses receiving")
                }

                // Rule check: All items MUST exist in PO
                val poItemMap = po.items.associateBy { it.sku }
                for (item in receivedItems) {
                    if (!poItemMap.containsKey(item.sku)) {
                        throw IllegalArgumentException("Item ${item.sku} (${item.itemName}) tidak terdapat pada Purchase Order $poId!")
                    }
                }

                // Read 2: Read ALL product documents for received items
                val productMap = mutableMapOf<String, Product>()
                for (recvItem in receivedItems) {
                    if (recvItem.qtyReceived > 0) {
                        val productRef = db.collection(COLLECTION_PRODUCTS).document(recvItem.sku)
                        val productSnap = transaction.get(productRef)
                        if (productSnap.exists()) {
                            val prod = productSnap.toObject(Product::class.java)
                            if (prod != null) {
                                productMap[recvItem.sku] = prod
                            }
                        }
                    }
                }

                // ==========================================
                // 2. WRITE PHASE: All writes executed after reads
                // ==========================================

                // Process stock increases and movements
                val updatedPoItems = po.items.map { poItem ->
                    val recvItem = receivedItems.find { it.sku == poItem.sku }
                    if (recvItem != null && recvItem.qtyReceived > 0) {
                        val productRef = db.collection(COLLECTION_PRODUCTS).document(poItem.sku)
                        val product = productMap[poItem.sku]

                        val currentStock = product?.stock ?: 0
                        val newStock = currentStock + recvItem.qtyReceived

                        // Update product stock and last receiving
                        transaction.update(
                            productRef,
                            mapOf(
                                "stock" to newStock,
                                "lastReceiving" to todayStr,
                                "updatedAt" to Timestamp.now(),
                                "updatedBy" to user
                            )
                        )

                        // Create stock movement record
                        val movementRef = db.collection(COLLECTION_MOVEMENTS).document()
                        val movement = StockMovement(
                            movementId = movementRef.id,
                            date = todayStr,
                            itemCode = poItem.sku,
                            itemNameSnapshot = poItem.itemName,
                            type = MovementType.RECEIVING.name,
                            referenceId = poId,
                            qtyIn = recvItem.qtyReceived,
                            qtyOut = 0,
                            previousStock = currentStock,
                            newStock = newStock,
                            reason = "Receiving PO $poId",
                            user = user,
                            timestamp = Timestamp.now()
                        )
                        transaction.set(movementRef, movement)

                        poItem.copy(receivedQty = poItem.receivedQty + recvItem.qtyReceived)
                    } else {
                        poItem
                    }
                }

                // Determine if PO is fully completed or partial
                val isAllCompleted = updatedPoItems.all { it.receivedQty >= it.qty }
                val newStatus = if (isAllCompleted) "COMPLETED" else "PARTIAL"

                transaction.update(
                    poDocRef,
                    mapOf(
                        "items" to updatedPoItems,
                        "status" to newStatus,
                        "updatedAt" to Timestamp.now()
                    )
                )

                val newReceiving = Receiving(
                    receivingId = receivingId,
                    poId = poId,
                    date = todayStr,
                    items = receivedItems,
                    notes = notes.trim(),
                    createdBy = user,
                    createdAt = Timestamp.now()
                )
                transaction.set(receivingDocRef, newReceiving)

                newReceiving
            }.await()

            Log.d(TAG, "Receiving processed: ${receiving.receivingId} for PO: $poId")
            Result.success(receiving)
        } catch (e: Exception) {
            Log.e(TAG, "Error processing receiving: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun listenReceivings(): Flow<List<Receiving>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_RECEIVINGS)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(Receiving::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun getAllReceivings(): List<Receiving> {
        return try {
            val snap = db.collection(COLLECTION_RECEIVINGS)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(Receiving::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
