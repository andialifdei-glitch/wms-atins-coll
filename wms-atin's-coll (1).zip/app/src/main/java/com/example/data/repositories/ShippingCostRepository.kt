package com.example.data.repositories

import android.util.Log
import com.example.data.models.ShippingRate
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class ShippingCostRepository(
    customFunctions: FirebaseFunctions? = null,
    customAuth: FirebaseAuth? = null,
    customHttpClient: OkHttpClient? = null
) {
    private val functions: FirebaseFunctions? = customFunctions ?: runCatching { FirebaseFunctions.getInstance(FUNCTION_REGION) }.getOrNull()
    private val auth: FirebaseAuth? = customAuth ?: runCatching { FirebaseAuth.getInstance() }.getOrNull()

    companion object {
        private const val TAG = "ShippingCostRepo"
        const val FUNCTION_NAME = "calculateShippingCost"
        const val FUNCTION_REGION = "us-central1"

        // Official RajaOngkir Komerce Endpoints
        private const val RAJAONGKIR_BASE_URL = "https://rajaongkir.komerce.id/api/v1"
        private const val RAJAONGKIR_API_KEY = "KYr1MRBPb4a4667b8ed8a865DPqsFp5n"

        // Default Origin: Atin's Coll Banjaran, Bandung (ID 4997: BANJARAN KULON, BANJARAN, BANDUNG)
        const val DEFAULT_ORIGIN_ID = 4997
    }

    private val httpClient: OkHttpClient = customHttpClient ?: OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val resolver = RajaOngkirResolver(
        httpClient = httpClient,
        baseUrl = RAJAONGKIR_BASE_URL,
        apiKey = RAJAONGKIR_API_KEY
    )

    private data class CourierRule(
        val code: String,
        val displayName: String,
        val matcher: (service: String, desc: String) -> Boolean
    )

    private val allowedCouriers = listOf(
        // 1. Wahana Ekonomis: Cocokkan layanan ekonomis/hemat aktual atau tarif termurah yang tersedia
        CourierRule("wahana", "Wahana Ekonomis") { s, d ->
            val lower = s.lowercase()
            val lowerDesc = d.lowercase()
            lower.contains("ekonomis") || lower.contains("ekonomi") || lower.contains("hemat") ||
            lower.contains("express") || lowerDesc.contains("hemat")
        },
        // 2. Lion Parcel JagoPack: Wajib cocok JagoPack, BUKAN Reguler/REGPACK/ONEPACK
        CourierRule("lion", "Lion Parcel JagoPack") { s, d ->
            val lower = s.lowercase()
            val lowerDesc = d.lowercase()
            lower.contains("jago") || lower.contains("jagopack") || lowerDesc.contains("jago")
        },
        // 3. SPX Hemat: Wajib layanan Hemat, BUKAN Standard / Reguler
        CourierRule("spx", "SPX Hemat") { s, d ->
            val lower = s.lowercase()
            val lowerDesc = d.lowercase()
            (lower.contains("hemat") || lowerDesc.contains("hemat")) && !lower.contains("standard") && !lower.contains("reguler")
        },
        // 4. SPX Reguler (COD): Layanan Reguler/Standard SPX
        CourierRule("spx", "SPX Reguler (COD)") { s, d ->
            val lower = s.lowercase()
            val lowerDesc = d.lowercase()
            lower.contains("standard") || lower.contains("reguler") || lowerDesc.contains("standard") || lowerDesc.contains("reguler")
        }
    )

    /**
     * Calculates shipping cost using:
     * 1. Firebase Cloud Function (Callable `calculateShippingCost`) as primary architecture.
     * 2. Live RajaOngkir API fallback if Cloud Function backend is not deployed on this project.
     *
     * In both cases, rates are fetched dynamically from RajaOngkir. No static/cached fake rates.
     */
    suspend fun calculateShippingCost(
        origin: String,
        destination: String,
        weightInGrams: Int
    ): Result<List<ShippingRate>> = withContext(Dispatchers.IO) {
        val safeWeight = if (weightInGrams <= 0) 1000 else weightInGrams
        val safeOrigin = if (origin.isBlank()) "Banjaran, Bandung, Jawa Barat" else origin.trim()
        val safeDestination = destination.trim()

        if (safeDestination.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Destinasi wilayah customer belum dipilih"))
        }

        // Try Primary Architecture: Firebase Callable Cloud Function
        if (auth?.currentUser != null && functions != null) {
            try {
                Log.d(TAG, "[ShippingAudit] Attempting Firebase Callable Function '$FUNCTION_NAME' (origin=$safeOrigin, destination=$safeDestination, weight=$safeWeight)")
                val payload = hashMapOf<String, Any>(
                    "origin" to safeOrigin,
                    "destination" to safeDestination,
                    "weight" to safeWeight
                )
                val callable = functions.getHttpsCallable(FUNCTION_NAME)
                val result = callable.call(payload).await()
                val resultMap = result.data as? Map<*, *>
                val servicesList = resultMap?.get("services") as? List<*>

                if (servicesList != null && servicesList.isNotEmpty()) {
                    val list = parseServicesList(servicesList)
                    if (list.isNotEmpty()) {
                        Log.d(TAG, "[ShippingAudit] Successfully received ${list.size} rates from Cloud Function")
                        return@withContext Result.success(list)
                    }
                }
            } catch (fe: FirebaseFunctionsException) {
                Log.w(TAG, "[ShippingAudit] Cloud Function not deployed or returned ${fe.code}: ${fe.message}. Proceeding to live RajaOngkir query.")
            } catch (e: Exception) {
                Log.w(TAG, "[ShippingAudit] Cloud Function invocation failed: ${e.message}. Proceeding to live RajaOngkir query.")
            }
        } else {
            Log.d(TAG, "[ShippingAudit] User not logged in to Firebase Auth. Proceeding to live RajaOngkir query.")
        }

        // Direct Live RajaOngkir API query
        return@withContext fetchLiveRajaOngkirRates(safeOrigin, safeDestination, safeWeight)
    }

    private fun parseServicesList(servicesList: List<*>): List<ShippingRate> {
        val list = mutableListOf<ShippingRate>()
        for (item in servicesList) {
            val map = item as? Map<*, *> ?: continue
            val courier = map["courier"]?.toString().orEmpty()
            val serviceCode = map["serviceCode"]?.toString().orEmpty()
            val serviceName = map["serviceName"]?.toString().orEmpty()
            val cost = (map["cost"] as? Number)?.toLong()
                ?: map["cost"]?.toString()?.toLongOrNull() ?: 0L
            val etd = map["etd"]?.toString() ?: "-"
            val isAvailable = map["isAvailable"] as? Boolean ?: (cost > 0)
            val message = map["message"]?.toString().orEmpty()

            list.add(
                ShippingRate(
                    courier = courier,
                    serviceCode = serviceCode,
                    serviceName = serviceName,
                    cost = cost,
                    etd = etd,
                    isAvailable = isAvailable,
                    message = message
                )
            )
        }
        return list
    }

    /**
     * Resolves location name or formatted region to RajaOngkir Destination ID via generic RajaOngkirResolver.
     */
    suspend fun resolveDestinationId(query: String): Result<Int> = withContext(Dispatchers.IO) {
        val numeric = query.trim().toIntOrNull()
        if (numeric != null && numeric > 0) {
            return@withContext Result.success(numeric)
        }

        val raw = query.trim()
        if (raw.isBlank()) {
            return@withContext Result.failure(Exception("Nama destinasi tidak valid: '$query'"))
        }

        Log.d(TAG, "[ShippingAudit] Resolving destination for '$raw' using RajaOngkirResolver")
        val matchResult = resolver.resolveLocationFromRawString(raw)

        matchResult.fold(
            onSuccess = { loc ->
                Log.d(TAG, "[ShippingAudit] selected RajaOngkir ID -> ${loc.id} for '$raw' (label=${loc.label})")
                Result.success(loc.id)
            },
            onFailure = { err ->
                Log.w(TAG, "[ShippingAudit] Destination resolution failed for '$raw': ${err.message}")
                Result.failure(Exception("Lokasi tujuan belum tersedia di RajaOngkir."))
            }
        )
    }

    private suspend fun resolveOriginId(originQuery: String): Int {
        val num = originQuery.trim().toIntOrNull()
        if (num != null && num > 0) return num
        val res = resolveDestinationId(originQuery)
        return res.getOrElse {
            Log.w(TAG, "[ShippingAudit] Could not resolve store origin '$originQuery', using default Banjaran ($DEFAULT_ORIGIN_ID)")
            DEFAULT_ORIGIN_ID
        }
    }

    private suspend fun fetchLiveRajaOngkirRates(
        origin: String,
        destination: String,
        weightInGrams: Int
    ): Result<List<ShippingRate>> = withContext(Dispatchers.IO) {
        val originId = resolveOriginId(origin)
        val destResult = resolveDestinationId(destination)

        if (destResult.isFailure) {
            val err = destResult.exceptionOrNull()?.message ?: "Gagal menentukan ID destinasi RajaOngkir"
            Log.e(TAG, "[ShippingAudit] Destination resolution failed: $err")
            return@withContext Result.failure(Exception(err))
        }

        val destId = destResult.getOrThrow()
        val results = mutableListOf<ShippingRate>()

        for (courierRule in allowedCouriers) {
            Log.d(TAG, "[ShippingAudit] originId=$originId destinationId=$destId weightGram=$weightInGrams courier=${courierRule.code}")

            try {
                val formBody = FormBody.Builder()
                    .add("origin", originId.toString())
                    .add("destination", destId.toString())
                    .add("weight", weightInGrams.toString())
                    .add("courier", courierRule.code)
                    .add("price", "lowest")
                    .build()

                val request = Request.Builder()
                    .url("$RAJAONGKIR_BASE_URL/calculate/domestic-cost")
                    .addHeader("key", RAJAONGKIR_API_KEY)
                    .addHeader("Content-Type", "application/x-www-form-urlencoded")
                    .post(formBody)
                    .build()

                val response = httpClient.newCall(request).execute()
                Log.d(TAG, "[ShippingAudit] RajaOngkir HTTP status=${response.code} for courier=${courierRule.code}")

                val responseBody = response.body?.string().orEmpty()
                val json = JSONObject(responseBody)
                val meta = json.optJSONObject("meta")
                val metaCode = meta?.optInt("code", response.code) ?: response.code
                val metaStatus = meta?.optString("status", "") ?: ""

                Log.d(TAG, "[ShippingAudit] RajaOngkir meta.code=$metaCode meta.status=$metaStatus")

                val dataArray = json.optJSONArray("data")
                var matchedCost: Long = 0L
                var matchedService = courierRule.code
                var matchedEtd = "-"
                var isFound = false

                if (dataArray != null) {
                    var lowestCost = Long.MAX_VALUE
                    for (i in 0 until dataArray.length()) {
                        val item = dataArray.optJSONObject(i) ?: continue
                        val service = item.optString("service", "")
                        val desc = item.optString("description", "")
                        val cost = item.optLong("cost", 0L)
                        val etd = item.optString("etd", "-").replace("day", "hari").trim()

                        if (courierRule.matcher(service, desc) && cost > 0L) {
                            if (cost < lowestCost) {
                                lowestCost = cost
                                matchedCost = cost
                                matchedService = service
                                matchedEtd = etd
                                isFound = true
                            }
                            Log.d(TAG, "[ShippingAudit] candidate service: ${courierRule.code} - $service - $cost (etd: $etd)")
                        }
                    }
                }

                if (isFound && matchedCost > 0L) {
                    Log.d(TAG, "[ShippingAudit] selected service=${courierRule.displayName} selected cost=$matchedCost")
                    results.add(
                        ShippingRate(
                            courier = courierRule.code,
                            serviceCode = matchedService,
                            serviceName = courierRule.displayName,
                            cost = matchedCost,
                            etd = matchedEtd,
                            isAvailable = true,
                            message = "Estimasi $matchedEtd"
                        )
                    )
                } else {
                    Log.d(TAG, "[ShippingAudit] No available service for courier=${courierRule.code}")
                    results.add(
                        ShippingRate(
                            courier = courierRule.code,
                            serviceCode = courierRule.code,
                            serviceName = courierRule.displayName,
                            cost = 0L,
                            etd = "-",
                            isAvailable = false,
                            message = "Layanan tidak tersedia untuk rute ini."
                        )
                    )
                }
            } catch (ce: Exception) {
                Log.e(TAG, "[ShippingAudit] Error querying courier ${courierRule.code}: ${ce.message}")
                results.add(
                    ShippingRate(
                        courier = courierRule.code,
                        serviceCode = courierRule.code,
                        serviceName = courierRule.displayName,
                        cost = 0L,
                        etd = "-",
                        isAvailable = false,
                        message = "Gagal memuat tarif: ${ce.message}"
                    )
                )
            }
        }

        if (results.isEmpty()) {
            Result.failure(Exception("Gagal memperoleh tarif ongkir dari RajaOngkir."))
        } else {
            Result.success(results)
        }
    }
}
