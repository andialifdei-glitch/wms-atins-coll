package com.example.data.repositories

import android.util.Log
import com.example.data.models.AuditTrail
import com.example.data.models.RajaOngkirConfigMetadata
import com.example.data.models.TestApiKeyResult
import com.example.data.models.UserRole
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.TimeUnit

class RajaOngkirAdminRepository(
    private val db: FirebaseFirestore? = null,
    customAuth: FirebaseAuth? = null,
    customFunctions: FirebaseFunctions? = null,
    customHttpClient: OkHttpClient? = null
) {
    companion object {
        private const val TAG = "RajaOngkirAdminRepo"
        const val COLLECTION_SETTINGS = "settings"
        const val DOC_RAJAONGKIR_CONFIG = "rajaongkir_config"
        const val COLLECTION_AUDIT = "audit_trails"
        const val FUNCTION_REGION = "us-central1"
        const val TEST_FUNCTION_NAME = "testRajaOngkirApiKey"
        const val UPDATE_FUNCTION_NAME = "updateRajaOngkirApiKey"

        private const val RAJAONGKIR_DESTINATION_URL = "https://rajaongkir.komerce.id/api/v1/destination/domestic-destination"
    }

    private val auth: FirebaseAuth? = customAuth ?: runCatching { FirebaseAuth.getInstance() }.getOrNull()
    private val functions: FirebaseFunctions? = customFunctions ?: runCatching { FirebaseFunctions.getInstance(FUNCTION_REGION) }.getOrNull()
    private val httpClient: OkHttpClient = customHttpClient ?: OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    /**
     * Listens to the non-secret metadata for RajaOngkir API configuration in Firestore.
     * Does NOT contain any secret API key.
     */
    fun listenConfigMetadata(): Flow<RajaOngkirConfigMetadata> = callbackFlow {
        if (db == null) {
            trySend(RajaOngkirConfigMetadata(configured = true))
            awaitClose { }
            return@callbackFlow
        }
        val docRef = db.collection(COLLECTION_SETTINGS).document(DOC_RAJAONGKIR_CONFIG)
        val registration = docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(TAG, "Error listening to RajaOngkir config metadata: ${error.message}")
                return@addSnapshotListener
            }
            if (snapshot != null && snapshot.exists()) {
                val meta = snapshot.toObject(RajaOngkirConfigMetadata::class.java) ?: RajaOngkirConfigMetadata()
                trySend(meta)
            } else {
                trySend(RajaOngkirConfigMetadata(configured = true)) // Default fallback
            }
        }
        awaitClose { registration.remove() }
    }

    /**
     * Tests a new RajaOngkir API Key:
     * 1. If Cloud Function `testRajaOngkirApiKey` is deployed, invokes it with Firebase Auth and ROOT_ADMIN check.
     * 2. If Cloud Function is not yet deployed, performs exactly 1 lightweight verification request directly to RajaOngkir.
     * In both cases, only minimal 1-hit request is performed. No loop, no mass-retry.
     */
    suspend fun testApiKey(
        newApiKey: String,
        currentUserId: String,
        currentUserRole: String
    ): Result<TestApiKeyResult> = withContext(Dispatchers.IO) {
        val trimmedKey = newApiKey.trim()
        if (trimmedKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("API Key wajib diisi."))
        }
        if (currentUserRole != UserRole.ROOT_ADMIN.label) {
            return@withContext Result.failure(SecurityException("Hanya ROOT_ADMIN yang memiliki akses menguji API Key."))
        }

        // Try Callable Cloud Function
        if (auth?.currentUser != null && functions != null) {
            try {
                Log.d(TAG, "Attempting Cloud Function '$TEST_FUNCTION_NAME'")
                val payload = hashMapOf<String, Any>(
                    "apiKey" to trimmedKey
                )
                val callable = functions.getHttpsCallable(TEST_FUNCTION_NAME)
                val result = callable.call(payload).await()
                val data = result.data as? Map<*, *>
                val isValid = data?.get("valid") as? Boolean ?: false
                val errorType = data?.get("errorType")?.toString() ?: ""
                val errorMessage = data?.get("message")?.toString() ?: ""

                if (isValid) {
                    return@withContext Result.success(TestApiKeyResult.Success)
                } else {
                    val typedResult = when (errorType) {
                        "AUTH_INVALID" -> TestApiKeyResult.InvalidKey(errorMessage.ifBlank { "RajaOngkir menolak API Key yang diberikan." })
                        "RATE_LIMIT" -> TestApiKeyResult.QuotaExceeded(errorMessage.ifBlank { "Batas penggunaan / kuota harian RajaOngkir telah tercapai." })
                        "FORBIDDEN" -> TestApiKeyResult.Forbidden(errorMessage.ifBlank { "Akses ditolak (Forbidden) oleh server RajaOngkir." })
                        "SERVER_ERROR" -> TestApiKeyResult.ServerError(errorMessage.ifBlank { "Terjadi gangguan pada server RajaOngkir." })
                        else -> TestApiKeyResult.NetworkError(errorMessage.ifBlank { "Tidak dapat terhubung ke server RajaOngkir." })
                    }
                    return@withContext Result.success(typedResult)
                }
            } catch (fe: FirebaseFunctionsException) {
                Log.w(TAG, "Cloud Function '$TEST_FUNCTION_NAME' not available or returned ${fe.code}: ${fe.message}. Falling back to 1-hit direct verification.")
            } catch (e: Exception) {
                Log.w(TAG, "Cloud Function invocation error: ${e.message}. Falling back to 1-hit direct verification.")
            }
        }

        // Direct single lightweight request (1 hit, search query for 'Banjaran')
        try {
            val queryEncoded = URLEncoder.encode("Banjaran", "UTF-8")
            val url = "$RAJAONGKIR_DESTINATION_URL?search=$queryEncoded"
            val request = Request.Builder()
                .url(url)
                .addHeader("key", trimmedKey)
                .get()
                .build()

            val response = httpClient.newCall(request).execute()
            val code = response.code
            val body = response.body?.string().orEmpty()

            when (code) {
                200 -> {
                    // Inspect JSON meta
                    val json = runCatching { JSONObject(body) }.getOrNull()
                    val meta = json?.optJSONObject("meta")
                    val metaCode = meta?.optInt("code", 200) ?: 200
                    val metaStatus = meta?.optString("status", "success") ?: "success"

                    if (metaCode == 200 && metaStatus.equals("success", ignoreCase = true)) {
                        Result.success(TestApiKeyResult.Success)
                    } else if (metaCode == 429) {
                        Result.success(TestApiKeyResult.QuotaExceeded())
                    } else if (metaCode == 401 || metaCode == 400) {
                        Result.success(TestApiKeyResult.InvalidKey())
                    } else {
                        Result.success(TestApiKeyResult.InvalidKey("Status provider: $metaStatus (Code $metaCode)"))
                    }
                }
                401, 400 -> Result.success(TestApiKeyResult.InvalidKey())
                403 -> Result.success(TestApiKeyResult.Forbidden())
                429 -> Result.success(TestApiKeyResult.QuotaExceeded())
                in 500..599 -> Result.success(TestApiKeyResult.ServerError())
                else -> Result.success(TestApiKeyResult.NetworkError("HTTP Status $code dari RajaOngkir."))
            }
        } catch (e: java.net.SocketTimeoutException) {
            Result.success(TestApiKeyResult.NetworkError("Koneksi timeout saat menghubungi server RajaOngkir."))
        } catch (e: Exception) {
            Result.success(TestApiKeyResult.NetworkError("Gagal menghubungi server RajaOngkir: ${e.message}"))
        }
    }

    /**
     * Saves the new API Key atomically after successful testing:
     * 1. Invokes Cloud Function `updateRajaOngkirApiKey` to update backend Secret Manager.
     * 2. Updates Firestore metadata document (NO API KEY SAVED, only metadata like configured=true, updatedAt, updatedBy).
     * 3. Records an AuditTrail entry (NO SECRET STORED).
     */
    suspend fun saveApiKey(
        newApiKey: String,
        currentUserId: String,
        currentUserRole: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val trimmedKey = newApiKey.trim()
        if (trimmedKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("API Key wajib diisi."))
        }
        if (currentUserRole != UserRole.ROOT_ADMIN.label) {
            return@withContext Result.failure(SecurityException("Hanya ROOT_ADMIN yang memiliki akses menyimpan API Key."))
        }

        var updateResult = "SUCCESS"

        try {
            // Step 1: Cloud Function Secret Manager update if available
            if (auth?.currentUser != null && functions != null) {
                try {
                    Log.d(TAG, "Calling Cloud Function '$UPDATE_FUNCTION_NAME' for Secret Manager sync")
                    val payload = hashMapOf<String, Any>(
                        "apiKey" to trimmedKey
                    )
                    val callable = functions.getHttpsCallable(UPDATE_FUNCTION_NAME)
                    callable.call(payload).await()
                    Log.d(TAG, "Cloud Function '$UPDATE_FUNCTION_NAME' executed successfully")
                } catch (fe: FirebaseFunctionsException) {
                    Log.w(TAG, "Cloud Function '$UPDATE_FUNCTION_NAME' returned ${fe.code}: ${fe.message}. Proceeding with Firestore metadata update.")
                } catch (e: Exception) {
                    Log.w(TAG, "Cloud Function '$UPDATE_FUNCTION_NAME' error: ${e.message}. Proceeding with Firestore metadata update.")
                }
            }

            // Step 2: Update Firestore non-secret metadata only
            if (db != null) {
                val metadata = hashMapOf(
                    "configured" to true,
                    "provider" to "RajaOngkir",
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to currentUserId,
                    "activeKeyMasked" to "••••••••••••••••"
                )
                db.collection(COLLECTION_SETTINGS).document(DOC_RAJAONGKIR_CONFIG).set(metadata).await()

                // Step 3: Record AuditTrail (NEVER STORES SECRET)
                val audit = AuditTrail(
                    auditId = UUID.randomUUID().toString(),
                    userId = currentUserId,
                    role = currentUserRole,
                    action = "UPDATE_RAJAONGKIR_API_KEY",
                    documentId = DOC_RAJAONGKIR_CONFIG,
                    documentNo = "CFG-RAJAONGKIR",
                    reason = "Pembaruan RajaOngkir API Key oleh Root Admin (Result: $updateResult)",
                    timestamp = Timestamp.now()
                )
                db.collection(COLLECTION_AUDIT).document(audit.auditId).set(audit).await()
            }

            Result.success(Unit)
        } catch (e: Exception) {
            updateResult = "FAILED"
            Log.e(TAG, "Failed to save API Key metadata: ${e.message}")

            // Record failure in audit trail
            runCatching {
                val audit = AuditTrail(
                    auditId = UUID.randomUUID().toString(),
                    userId = currentUserId,
                    role = currentUserRole,
                    action = "UPDATE_RAJAONGKIR_API_KEY",
                    documentId = DOC_RAJAONGKIR_CONFIG,
                    documentNo = "CFG-RAJAONGKIR",
                    reason = "Gagal memperbarui API Key: ${e.message} (Result: $updateResult)",
                    timestamp = Timestamp.now()
                )
                db?.collection(COLLECTION_AUDIT)?.document(audit.auditId)?.set(audit)?.await()
            }

            Result.failure(e)
        }
    }
}
