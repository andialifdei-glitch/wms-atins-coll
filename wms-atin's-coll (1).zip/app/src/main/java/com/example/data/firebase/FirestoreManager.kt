package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.R
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

object FirestoreManager {
    private const val TAG = "FirestoreManager"

    @Volatile
    private var firestoreInstance: FirebaseFirestore? = null

    fun getFirestore(context: Context): FirebaseFirestore {
        return firestoreInstance ?: synchronized(this) {
            firestoreInstance ?: run {
                val databaseId = try {
                    context.getString(R.string.firestore_database_id)
                } catch (e: Exception) {
                    ""
                }
                val db = try {
                    if (databaseId.isNotBlank() && databaseId != "(default)") {
                        Log.d(TAG, "Initializing Firestore with databaseId: $databaseId")
                        FirebaseFirestore.getInstance(FirebaseApp.getInstance(), databaseId)
                    } else {
                        Log.d(TAG, "Initializing Firestore with default database")
                        FirebaseFirestore.getInstance()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Fallback to default Firestore: ${e.message}")
                    FirebaseFirestore.getInstance()
                }
                firestoreInstance = db
                db
            }
        }
    }
}
