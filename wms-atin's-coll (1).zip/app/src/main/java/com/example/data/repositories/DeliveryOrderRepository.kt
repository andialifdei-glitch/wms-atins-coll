package com.example.data.repositories

import android.util.Log
import com.example.data.models.DeliveryOrder
import com.example.data.models.MovementType
import com.example.data.models.Product
import com.example.data.models.SalesOrder
import com.example.data.models.StockMovement
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeliveryOrderRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "DeliveryOrderRepo"
        const val COLLECTION_DO = "delivery_orders"
        const val COLLECTION_SO = "sales_orders"
        const val COLLECTION_PRODUCTS = "products"
        const val COLLECTION_MOVEMENTS = "stock_movements"
        const val COLLECTION_COUNTERS = "counters"
        const val DOC_DO_COUNTER = "delivery_order"
    }

    /**
     * Creates a Delivery Order and executes IDEMPOTENT stock deduction in a single Firestore Transaction.
     * STRICT TWO-PHASE ARCHITECTURE:
     * Phase 1 (READ PHASE): Reads SO, counter, and ALL product documents for validation.
     * Phase 2 (WRITE PHASE): Executes all counter, stock deduction, stock movement, SO status, and DO document writes.
     */
    suspend fun createDeliveryOrder(
        soId: String,
        senderName: String,
        senderPhone: String,
        senderAddress: String = "",
        user: String
    ): Result<DeliveryOrder> {
        return try {
            val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
            val displayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            val counterRef = db.collection(COLLECTION_COUNTERS).document(DOC_DO_COUNTER)
            val soDocRef = db.collection(COLLECTION_SO).document(soId)

            val deliveryOrder = db.runTransaction { transaction ->
                // ==========================================
                // 1. READ PHASE: Execute ALL reads first
                // ==========================================

                // Read 1: Sales Order Document
                val soSnap = transaction.get(soDocRef)
                if (!soSnap.exists()) {
                    throw IllegalStateException("Sales Order $soId tidak ditemukan")
                }
                val so = soSnap.toObject(SalesOrder::class.java)
                    ?: throw IllegalStateException("Format data Sales Order tidak valid")

                // Idempotency & Lifecycle validation
                if (so.status == "DELIVERY ORDER") {
                    throw IllegalStateException("DO sudah pernah dibuat dan stok telah dipotong untuk Sales Order $soId")
                }
                if (so.status != "READY TO DELIVER") {
                    throw IllegalStateException("DO hanya dapat dibuat dari Sales Order berstatus READY TO DELIVER (Status saat ini: ${so.status})")
                }

                // Read 2: Delivery Order Counter Document
                val counterSnap = transaction.get(counterRef)

                // Read 3: Read ALL product documents for every item in SO
                val productMap = mutableMapOf<String, Product>()
                for (item in so.items) {
                    val productRef = db.collection(COLLECTION_PRODUCTS).document(item.sku)
                    val productSnap = transaction.get(productRef)
                    if (!productSnap.exists()) {
                        throw IllegalStateException("Produk ${item.sku} tidak ditemukan di master produk")
                    }
                    val product = productSnap.toObject(Product::class.java)
                        ?: throw IllegalStateException("Format data produk ${item.sku} tidak valid")
                    productMap[item.sku] = product
                }

                // Read-phase validation: verify stock sufficiency for all items
                for (item in so.items) {
                    val product = productMap[item.sku]!!
                    if (product.stock < item.qty) {
                        throw IllegalStateException(
                            "Stock tidak mencukupi untuk ${item.itemName} (${item.sku}). Stock tersedia: ${product.stock} pcs, Qty yang diminta: ${item.qty} pcs"
                        )
                    }
                }

                // ==========================================
                // 2. WRITE PHASE: Execute ALL writes after reads
                // ==========================================

                // Generate atomic DO ID
                val currentNumber = if (counterSnap.exists()) {
                    counterSnap.getLong("currentNumber") ?: 0L
                } else {
                    0L
                }
                val nextNumber = currentNumber + 1L
                val doId = String.format("DO-%s-%05d", dateStr, nextNumber)

                // Write 1: Update DO counter
                transaction.set(
                    counterRef,
                    mapOf("currentNumber" to nextNumber, "updatedAt" to Timestamp.now())
                )

                // Write 2: Deduct stock and record stock movements
                for (item in so.items) {
                    val productRef = db.collection(COLLECTION_PRODUCTS).document(item.sku)
                    val product = productMap[item.sku]!!
                    val newStock = product.stock - item.qty

                    transaction.update(
                        productRef,
                        mapOf(
                            "stock" to newStock,
                            "updatedAt" to Timestamp.now(),
                            "updatedBy" to user
                        )
                    )

                    val movementRef = db.collection(COLLECTION_MOVEMENTS).document()
                    val movement = StockMovement(
                        movementId = movementRef.id,
                        date = displayDate,
                        itemCode = item.sku,
                        itemNameSnapshot = item.itemName,
                        type = MovementType.DELIVERY.name,
                        referenceId = doId,
                        qtyIn = 0,
                        qtyOut = item.qty,
                        previousStock = product.stock,
                        newStock = newStock,
                        reason = "Pengiriman DO $doId (SO: $soId)",
                        user = user,
                        timestamp = Timestamp.now()
                    )
                    transaction.set(movementRef, movement)
                }

                // Write 3: Update SO status to DELIVERY ORDER
                transaction.update(
                    soDocRef,
                    mapOf(
                        "status" to "DELIVERY ORDER",
                        "updatedAt" to Timestamp.now(),
                        "updatedBy" to user
                    )
                )

                // Write 4: Save Delivery Order document
                val doDocRef = db.collection(COLLECTION_DO).document(doId)
                val totalItems = so.items.size
                val totalPcs = so.items.sumOf { it.qty }

                val createdDo = DeliveryOrder(
                    doId = doId,
                    soId = soId,
                    date = displayDate,
                    expedition = so.expedition,
                    senderName = senderName.ifBlank { "Atin's Collection" },
                    senderPhone = senderPhone.ifBlank { "0899-7884-435" },
                    senderAddress = senderAddress.ifBlank { "Banjaran, Kab. Bandung, Jawa Barat" },
                    recipientName = so.customerName,
                    recipientPhone = so.phone,
                    recipientAddress = so.address,
                    totalItems = totalItems,
                    totalPcs = totalPcs,
                    totalWeightInGrams = so.totalWeightInGrams,
                    shippingCost = so.shippingCost,
                    shippingCourier = so.shippingCourier,
                    shippingServiceName = so.shippingServiceName,
                    items = so.items,
                    isStockDeducted = true,
                    createdBy = user,
                    createdAt = Timestamp.now()
                )

                transaction.set(doDocRef, createdDo)
                createdDo
            }.await()

            Log.d(TAG, "Delivery Order created: ${deliveryOrder.doId}")
            Result.success(deliveryOrder)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating DO: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun listenDeliveryOrders(): Flow<List<DeliveryOrder>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_DO)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(DeliveryOrder::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun getDeliveryOrder(doId: String): DeliveryOrder? {
        return try {
            val doc = db.collection(COLLECTION_DO).document(doId).get().await()
            doc.toObject(DeliveryOrder::class.java)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getAllDeliveryOrders(): List<DeliveryOrder> {
        return try {
            val snap = db.collection(COLLECTION_DO)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(DeliveryOrder::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
