package com.example.data.repositories

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Data representation of a destination item returned by RajaOngkir domestic destination search API.
 */
data class RajaOngkirLocation(
    val id: Int,
    val label: String,
    val provinceName: String,
    val cityName: String,
    val districtName: String,
    val subdistrictName: String,
    val zipCode: String
)

/**
 * Parsed administrative location components used for multi-tier resolution and hierarchy validation.
 */
data class AdminRegionQuery(
    val district: String = "",
    val regency: String = "",
    val province: String = "",
    val subdistrictOrVillage: String = ""
)

/**
 * Dedicated generic resolver for mapping Indonesian administrative regions (Customer Address / Store Address)
 * to valid RajaOngkir domestic destination IDs using a multi-tiered search strategy and hierarchy validation.
 *
 * CRITICAL REQUIREMENTS:
 * - Does NOT use Kemendagri / BPS internal codes as RajaOngkir IDs.
 * - Does NOT hardcode any specific locations (e.g. Jayakerta).
 * - Normalizes strings by stripping administrative prefixes (Kabupaten, Kota, Kec., etc.).
 * - Uses multi-tier search strategy:
 *     Tier 1: district + regency/city
 *     Tier 2: district alone
 *     Tier 3: regency/city alone (fallback)
 *     Tier 4: cleaned raw query tokens
 * - Validates hierarchy (province, regency, district) against candidate metadata before selecting.
 * - Does NOT blindly take the first candidate without validation.
 */
class RajaOngkirResolver(
    private val httpClient: OkHttpClient,
    private val baseUrl: String = "https://rajaongkir.komerce.id/api/v1",
    private val apiKey: String = "KYr1MRBPb4a4667b8ed8a865DPqsFp5n"
) {
    companion object {
        private const val TAG = "RajaOngkirResolver"

        /**
         * Normalizes administrative region names:
         * - Converts to lowercase and trims
         * - Strips administrative prefixes ("kabupaten", "kab.", "kota", "adm.", "kecamatan", "kec.", "kelurahan", "kel.", "desa", "provinsi", "prov.")
         * - Removes punctuation and collapses whitespace
         */
        fun normalizeName(raw: String): String {
            if (raw.isBlank()) return ""
            return raw.lowercase()
                .replace(Regex("(?i)(kabupaten|kab\\.|kota|adm\\.|administrasi|kecamatan|kec\\.|kelurahan|kel\\.|desa|provinsi|prov\\.)"), " ")
                .replace(Regex("[,/\\-_()]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        /**
         * Parses a raw query string (e.g. "Jayakerta, Kabupaten Karawang, Jawa Barat")
         * into structured AdminRegionQuery components.
         */
        fun parseRawQuery(raw: String): AdminRegionQuery {
            val parts = raw.split(",").map { it.trim() }.filter { it.isNotBlank() }
            return when {
                parts.size >= 3 -> AdminRegionQuery(
                    district = parts[0],
                    regency = parts[1],
                    province = parts.subList(2, parts.size).joinToString(" ")
                )
                parts.size == 2 -> AdminRegionQuery(
                    district = parts[0],
                    regency = parts[1]
                )
                parts.size == 1 -> AdminRegionQuery(
                    district = parts[0]
                )
                else -> AdminRegionQuery()
            }
        }
    }

    /**
     * Searches RajaOngkir domestic destination API for a given query string.
     */
    fun searchDestinations(query: String): List<RajaOngkirLocation> {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return emptyList()

        val list = mutableListOf<RajaOngkirLocation>()
        try {
            val encoded = URLEncoder.encode(trimmed, "UTF-8")
            val url = "$baseUrl/destination/domestic-destination?search=$encoded"
            val request = Request.Builder()
                .url(url)
                .addHeader("key", apiKey)
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.w(TAG, "[RajaOngkirResolver] searchDestinations HTTP error ${response.code} for query='$trimmed'")
                return emptyList()
            }

            val body = response.body?.string().orEmpty()
            val json = JSONObject(body)
            val dataArray = json.optJSONArray("data") ?: return emptyList()

            for (i in 0 until dataArray.length()) {
                val obj = dataArray.optJSONObject(i) ?: continue
                val id = obj.optInt("id", 0)
                if (id <= 0) continue

                val label = obj.optString("label", "")
                val labelParts = label.split(",").map { it.trim() }
                val provFallback = if (labelParts.size >= 4) labelParts[3] else if (labelParts.size >= 3) labelParts[2] else ""
                val cityFallback = if (labelParts.size >= 3) labelParts[2] else if (labelParts.size >= 2) labelParts[1] else ""
                val distFallback = if (labelParts.size >= 2) labelParts[1] else if (labelParts.isNotEmpty()) labelParts[0] else ""

                list.add(
                    RajaOngkirLocation(
                        id = id,
                        label = label,
                        provinceName = obj.optString("province_name", "").ifBlank { provFallback },
                        cityName = obj.optString("city_name", "").ifBlank { cityFallback },
                        districtName = obj.optString("district_name", "").ifBlank { distFallback },
                        subdistrictName = obj.optString("subdistrict_name", ""),
                        zipCode = obj.optString("zip_code", "")
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "[RajaOngkirResolver] Error searching destinations for '$trimmed': ${e.message}")
        }
        return list
    }

    /**
     * Resolves a location from structured administrative region data:
     * provinceName, regencyName, districtName, and optional villageName.
     */
    fun resolveLocation(
        district: String,
        regency: String,
        province: String,
        village: String = ""
    ): Result<RajaOngkirLocation> {
        val normDistrict = normalizeName(district)
        val normRegency = normalizeName(regency)
        val normProvince = normalizeName(province)
        val normVillage = normalizeName(village)

        Log.d(TAG, "[ShippingAudit] WMS region -> district='$district', regency='$regency', province='$province'")

        // Tiered Search Strategy
        val searchTiers = mutableListOf<String>()

        // Tier A: District + Regency normalized
        if (normDistrict.isNotBlank() && normRegency.isNotBlank()) {
            searchTiers.add("$normDistrict $normRegency")
        }

        // Tier B: District alone
        if (normDistrict.isNotBlank() && !searchTiers.contains(normDistrict)) {
            searchTiers.add(normDistrict)
        }

        // Tier C: Village + Regency (if village provided)
        if (normVillage.isNotBlank() && normRegency.isNotBlank()) {
            val combo = "$normVillage $normRegency"
            if (!searchTiers.contains(combo)) searchTiers.add(combo)
        }

        // Tier D: Regency alone (fallback)
        if (normRegency.isNotBlank() && !searchTiers.contains(normRegency)) {
            searchTiers.add(normRegency)
        }

        val allCandidates = mutableListOf<RajaOngkirLocation>()

        for (searchQuery in searchTiers) {
            Log.d(TAG, "[ShippingAudit] search query -> '$searchQuery'")
            val results = searchDestinations(searchQuery)
            if (results.isNotEmpty()) {
                Log.d(TAG, "[ShippingAudit] candidate -> retrieved ${results.size} items from query '$searchQuery'")
                allCandidates.addAll(results)

                // Validate hierarchy immediately on this tier's results
                val match = selectBestMatch(results, normDistrict, normRegency, normProvince, normVillage)
                if (match != null) {
                    Log.d(TAG, "[ShippingAudit] selected RajaOngkir ID -> ${match.id} (label: '${match.label}')")
                    return Result.success(match)
                }
            }
        }

        // Final attempt on all pooled candidates
        if (allCandidates.isNotEmpty()) {
            val bestCandidate = selectBestMatch(allCandidates, normDistrict, normRegency, normProvince, normVillage)
            if (bestCandidate != null) {
                Log.d(TAG, "[ShippingAudit] selected RajaOngkir ID -> ${bestCandidate.id} (label: '${bestCandidate.label}')")
                return Result.success(bestCandidate)
            }
        }

        Log.w(TAG, "[ShippingAudit] Lokasi tujuan belum tersedia di RajaOngkir: district='$district', regency='$regency', province='$province'")
        return Result.failure(Exception("Lokasi tujuan belum tersedia di RajaOngkir."))
    }

    /**
     * Resolves a location from a raw string query.
     * Can accept numeric RajaOngkir ID string, or formatted string like "Jayakerta, Kabupaten Karawang, Jawa Barat".
     */
    fun resolveLocationFromRawString(rawString: String): Result<RajaOngkirLocation> {
        val trimmed = rawString.trim()
        val numeric = trimmed.toIntOrNull()
        if (numeric != null && numeric > 0) {
            return Result.success(
                RajaOngkirLocation(
                    id = numeric,
                    label = "ID:$numeric",
                    provinceName = "",
                    cityName = "",
                    districtName = "",
                    subdistrictName = "",
                    zipCode = ""
                )
            )
        }

        val parsed = parseRawQuery(trimmed)
        if (parsed.district.isNotBlank() || parsed.regency.isNotBlank()) {
            return resolveLocation(
                district = parsed.district,
                regency = parsed.regency,
                province = parsed.province
            )
        }

        // Generic token-based fallback
        val clean = normalizeName(trimmed)
        if (clean.isBlank()) {
            return Result.failure(Exception("Lokasi tujuan belum tersedia di RajaOngkir."))
        }

        val candidates = searchDestinations(clean)
        if (candidates.isNotEmpty()) {
            val selected = candidates.firstOrNull { it.subdistrictName.isNotBlank() && it.subdistrictName != "-" } ?: candidates.first()
            Log.d(TAG, "[ShippingAudit] selected RajaOngkir ID -> ${selected.id} from token clean='$clean'")
            return Result.success(selected)
        }

        return Result.failure(Exception("Lokasi tujuan belum tersedia di RajaOngkir."))
    }

    /**
     * Validates candidate hierarchy against normalized target names and selects best match.
     * Hierarchy scoring:
     * - District match: 100 points
     * - Regency/City match: 50 points
     * - Province match: 25 points
     * - Village/Subdistrict match: 15 points
     * - Has real subdistrict (not "-"): 5 points
     */
    private fun selectBestMatch(
        candidates: List<RajaOngkirLocation>,
        normDistrict: String,
        normRegency: String,
        normProvince: String,
        normVillage: String
    ): RajaOngkirLocation? {
        var highestScore = -1
        var bestCandidate: RajaOngkirLocation? = null

        for (cand in candidates) {
            val candDistrict = normalizeName(cand.districtName)
            val candCity = normalizeName(cand.cityName)
            val candProvince = normalizeName(cand.provinceName)
            val candSubdistrict = normalizeName(cand.subdistrictName)

            var score = 0
            var districtMatched = false
            var regencyMatched = false

            // District matching
            if (normDistrict.isNotBlank() && candDistrict.isNotBlank()) {
                if (candDistrict == normDistrict) {
                    score += 100
                    districtMatched = true
                } else if (candDistrict.contains(normDistrict) || normDistrict.contains(candDistrict)) {
                    score += 70
                    districtMatched = true
                }
            }

            // Regency / City matching
            if (normRegency.isNotBlank() && candCity.isNotBlank()) {
                if (candCity == normRegency) {
                    score += 50
                    regencyMatched = true
                } else if (candCity.contains(normRegency) || normRegency.contains(candCity)) {
                    score += 35
                    regencyMatched = true
                }
            }

            // Province matching
            if (normProvince.isNotBlank() && candProvince.isNotBlank()) {
                if (candProvince == normProvince || candProvince.contains(normProvince) || normProvince.contains(candProvince)) {
                    score += 25
                }
            }

            // Village / Subdistrict matching
            if (normVillage.isNotBlank() && candSubdistrict.isNotBlank()) {
                if (candSubdistrict == normVillage || candSubdistrict.contains(normVillage)) {
                    score += 15
                }
            }

            // Non-empty subdistrict bonus (avoids 404 in domestic-cost API)
            if (cand.subdistrictName.isNotBlank() && cand.subdistrictName != "-") {
                score += 5
            }

            // Requirement: Must match at least District or Regency to prevent false positives across unrelated regions
            val minMatchSatisfied = (normDistrict.isNotBlank() && districtMatched) ||
                                    (normRegency.isNotBlank() && regencyMatched)

            if (minMatchSatisfied && score > highestScore) {
                highestScore = score
                bestCandidate = cand
            }
        }

        return bestCandidate
    }
}
