package com.example.data.repositories

import android.util.Log
import com.example.data.models.AuditTrail
import com.example.data.models.Product
import com.example.data.models.UserRole
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ProductRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "ProductRepository"
        const val COLLECTION_PRODUCTS = "products"
        const val COLLECTION_FAMILY_COUNTERS = "family_counters"
    }

    /**
     * Extracts numeric 3-digit portion from familyCode.
     * e.g., "FAM-001" -> 1. Defaults to 1 if parsing fails.
     */
    private fun extractFamilyNumber(familyCode: String): Int {
        val numPart = familyCode.replace(Regex("[^0-9]"), "")
        return numPart.toIntOrNull() ?: 1
    }

    /**
     * Creates a new product with atomic, family-scoped SKU generation.
     * Format: SKU-[FFF][PPP] -> e.g. SKU-001001, SKU-001002, etc.
     */
    suspend fun createProduct(
        familyCode: String,
        itemName: String,
        purchasingPrice: Long,
        netPrice: Long,
        initialStock: Int = 0,
        weightInGrams: Int = 0,
        user: String
    ): Result<Product> {
        return try {
            val cleanItemName = itemName.trim()
            if (cleanItemName.isBlank()) {
                return Result.failure(Exception("Nama Produk tidak boleh kosong"))
            }
            if (familyCode.isBlank()) {
                return Result.failure(Exception("Family harus dipilih"))
            }

            val famNum = extractFamilyNumber(familyCode)
            val familyCounterRef = db.collection(COLLECTION_FAMILY_COUNTERS).document(familyCode)

            val createdProduct = db.runTransaction { transaction ->
                val counterSnap = transaction.get(familyCounterRef)
                var currentProdNum = if (counterSnap.exists()) {
                    counterSnap.getLong("currentProductNumber") ?: 0L
                } else {
                    0L
                }

                var candidateSku: String
                var productDocRef: com.google.firebase.firestore.DocumentReference
                var exists: Boolean

                // Atomic generation loop with duplicate collision safety
                do {
                    currentProdNum += 1L
                    candidateSku = String.format("SKU-%03d%03d", famNum, currentProdNum)
                    productDocRef = db.collection(COLLECTION_PRODUCTS).document(candidateSku)
                    val existingSnap = transaction.get(productDocRef)
                    exists = existingSnap.exists()
                } while (exists)

                // Update family-scoped counter
                transaction.set(
                    familyCounterRef,
                    mapOf(
                        "familyCode" to familyCode,
                        "currentProductNumber" to currentProdNum,
                        "updatedAt" to Timestamp.now()
                    )
                )

                val product = Product(
                    productId = candidateSku,
                    sku = candidateSku,
                    familyCode = familyCode,
                    itemName = cleanItemName,
                    lastReceiving = "-",
                    stock = initialStock,
                    purchasingPrice = purchasingPrice,
                    netPrice = netPrice,
                    weightInGrams = weightInGrams,
                    active = true,
                    status = "ACTIVE",
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now(),
                    createdBy = user,
                    updatedBy = user
                )

                transaction.set(productDocRef, product)
                product
            }.await()

            Log.d(TAG, "Product created successfully with SKU: ${createdProduct.sku}")
            Result.success(createdProduct)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating product: ${e.message}", e)
            Result.failure(Exception("Gagal membuat Produk: ${e.localizedMessage ?: "Error database"}"))
        }
    }

    /**
     * Updates an existing product.
     * PERMANENT IDENTIFIER INVARIANT: Family and SKU are NEVER changed!
     * HPP (purchasingPrice) update is strictly restricted to Root Admin only!
     * Records HPP_UPDATE audit trail when HPP changes.
     */
    suspend fun updateProduct(
        sku: String,
        itemName: String,
        purchasingPrice: Long,
        netPrice: Long,
        weightInGrams: Int = 0,
        user: String,
        userRole: String = ""
    ): Result<Unit> {
        return try {
            val cleanName = itemName.trim()
            if (cleanName.isBlank()) {
                return Result.failure(IllegalArgumentException("Nama barang tidak boleh kosong"))
            }
            if (purchasingPrice < 0) {
                return Result.failure(IllegalArgumentException("HPP tidak boleh bernilai negatif"))
            }
            if (netPrice < 0) {
                return Result.failure(IllegalArgumentException("Harga jual net tidak boleh bernilai negatif"))
            }
            if (weightInGrams < 0) {
                return Result.failure(IllegalArgumentException("Berat produk tidak boleh bernilai negatif"))
            }

            val docRef = db.collection(COLLECTION_PRODUCTS).document(sku)
            val currentSnap = docRef.get().await()
            if (!currentSnap.exists()) {
                return Result.failure(IllegalStateException("Produk dengan SKU $sku tidak ditemukan"))
            }
            val currentProduct = currentSnap.toObject(Product::class.java)
                ?: return Result.failure(IllegalStateException("Format data produk tidak valid"))

            val oldHpp = currentProduct.purchasingPrice
            val isHppChanged = oldHpp != purchasingPrice

            // Security check: Only Root Admin can edit product data and change HPP / weight
            if (userRole != UserRole.ROOT_ADMIN.label) {
                return Result.failure(
                    SecurityException("Akses Ditolak: Hanya Root Admin yang berhak mengedit data produk, berat, dan HPP.")
                )
            }

            docRef.update(
                mapOf(
                    "itemName" to cleanName,
                    "purchasingPrice" to purchasingPrice,
                    "netPrice" to netPrice,
                    "weightInGrams" to weightInGrams,
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()

            // If HPP was updated by Root Admin, record Audit Trail
            if (isHppChanged) {
                val auditRef = db.collection("audit_trails").document()
                val audit = AuditTrail(
                    auditId = auditRef.id,
                    userId = user,
                    role = userRole,
                    action = "HPP_UPDATE",
                    documentId = sku,
                    documentNo = sku,
                    reason = "Perubahan HPP dari Rp $oldHpp menjadi Rp $purchasingPrice",
                    timestamp = Timestamp.now()
                )
                auditRef.set(audit).await()
                Log.d(TAG, "Audit Trail HPP_UPDATE recorded for SKU $sku: Rp $oldHpp -> Rp $purchasingPrice by $user ($userRole)")
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating product $sku: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Audited parser for Product document.
     * Strictly follows field `active` from the database:
     * - `active = true` -> active = true ("Aktif")
     * - `active = false` -> active = false ("Nonaktif")
     * - If field `active` is not available/null -> active = null ("Status Tidak Valid")
     * In accordance with requirements:
     * - Does NOT assume product is automatically active if field is missing/null
     * - Does NOT determine status based on stock, name, weight, or other assumptions
     */
    fun documentToProduct(doc: com.google.firebase.firestore.DocumentSnapshot): Product? {
        val p = doc.toObject(Product::class.java) ?: return null

        val rawActive: Boolean? = if (doc.contains("active")) {
            when (val v = doc.get("active")) {
                is Boolean -> v
                is String -> when (v.trim().lowercase()) {
                    "true", "aktif", "active", "1" -> true
                    "false", "nonaktif", "inactive", "0" -> false
                    else -> null
                }
                is Number -> v.toInt() == 1
                else -> null
            }
        } else {
            // Field 'active' is not available in the database document
            null
        }

        return p.copy(
            active = rawActive
        )
    }

    suspend fun toggleProductStatus(sku: String, isActive: Boolean, user: String): Result<Unit> {
        return try {
            db.collection(COLLECTION_PRODUCTS).document(sku).update(
                mapOf(
                    "active" to isActive,
                    "isActive" to isActive,
                    "status" to if (isActive) "ACTIVE" else "INACTIVE",
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteProduct(sku: String): Result<Unit> {
        return try {
            db.collection(COLLECTION_PRODUCTS).document(sku).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listenProducts(): Flow<List<Product>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_PRODUCTS)
            .orderBy("sku", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "listenProducts error: ${error.message}", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { documentToProduct(it) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun getProduct(sku: String): Product? {
        return try {
            val doc = db.collection(COLLECTION_PRODUCTS).document(sku).get().await()
            documentToProduct(doc)
        } catch (e: Exception) {
            Log.e(TAG, "getProduct error: ${e.message}", e)
            null
        }
    }

    suspend fun getAllProducts(): List<Product> {
        return try {
            val snap = db.collection(COLLECTION_PRODUCTS).get().await()
            snap.documents.mapNotNull { documentToProduct(it) }
        } catch (e: Exception) {
            Log.e(TAG, "getAllProducts error: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Audit duplicate SKU in database.
     */
    suspend fun auditSkuDuplicates(): Map<String, Any> {
        return try {
            val snap = db.collection(COLLECTION_PRODUCTS).get().await()
            val products = snap.documents.mapNotNull { it.toObject(Product::class.java) }
            val grouped = products.groupBy { it.sku }
            val duplicates = grouped.filter { it.value.size > 1 }

            mapOf(
                "totalProducts" to products.size,
                "uniqueSkus" to grouped.size,
                "duplicateCount" to duplicates.size,
                "duplicates" to duplicates.keys.toList()
            )
        } catch (e: Exception) {
            mapOf("error" to (e.localizedMessage ?: "Audit error"))
        }
    }
}
