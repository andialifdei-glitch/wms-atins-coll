package com.example.data.repositories

import android.util.Log
import com.example.data.models.PoItem
import com.example.data.models.PurchaseOrder
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PurchaseOrderRepository(private val db: FirebaseFirestore) {
    companion object {
        private const val TAG = "PORepository"
        const val COLLECTION_PO = "purchase_orders"
        const val COLLECTION_COUNTERS = "counters"
        const val DOC_PO_COUNTER = "purchase_order"
    }

    suspend fun createPurchaseOrder(
        supplier: String,
        supplierAddress: String,
        supplierPhone: String,
        notes: String,
        items: List<PoItem>,
        user: String
    ): Result<PurchaseOrder> {
        return try {
            if (supplier.isBlank()) return Result.failure(Exception("Nama supplier wajib diisi"))
            if (items.isEmpty()) return Result.failure(Exception("Minimal harus ada satu item PO"))

            val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
            val displayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val counterRef = db.collection(COLLECTION_COUNTERS).document(DOC_PO_COUNTER)

            val createdPo = db.runTransaction { transaction ->
                val counterSnap = transaction.get(counterRef)
                val currentNumber = if (counterSnap.exists()) {
                    counterSnap.getLong("currentNumber") ?: 0L
                } else {
                    0L
                }
                val nextNumber = currentNumber + 1L
                val poId = String.format("PO-%s-%05d", dateStr, nextNumber)

                transaction.set(counterRef, mapOf("currentNumber" to nextNumber, "updatedAt" to Timestamp.now()))

                val total = items.sumOf { it.subtotal }
                val po = PurchaseOrder(
                    poId = poId,
                    poDate = displayDate,
                    supplier = supplier.trim(),
                    supplierAddress = supplierAddress.trim(),
                    supplierPhone = supplierPhone.trim(),
                    notes = notes.trim(),
                    status = "CONFIRMED",
                    items = items,
                    total = total,
                    createdBy = user,
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )

                val docRef = db.collection(COLLECTION_PO).document(poId)
                transaction.set(docRef, po)
                po
            }.await()

            Log.d(TAG, "PO created: ${createdPo.poId}")
            Result.success(createdPo)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating PO: ${e.message}", e)
            Result.failure(Exception("Gagal membuat PO: ${e.localizedMessage ?: "Error database"}"))
        }
    }

    suspend fun cancelPurchaseOrder(poId: String, user: String): Result<Unit> {
        return try {
            db.collection(COLLECTION_PO).document(poId).update(
                mapOf(
                    "status" to "CANCELLED",
                    "updatedAt" to Timestamp.now(),
                    "updatedBy" to user
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getPo(poId: String): PurchaseOrder? {
        return try {
            val doc = db.collection(COLLECTION_PO).document(poId).get().await()
            doc.toObject(PurchaseOrder::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun listenPurchaseOrders(): Flow<List<PurchaseOrder>> = callbackFlow {
        val listener: ListenerRegistration = db.collection(COLLECTION_PO)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.toObject(PurchaseOrder::class.java) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun getAllPurchaseOrders(): List<PurchaseOrder> {
        return try {
            val snap = db.collection(COLLECTION_PO)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            snap.documents.mapNotNull { it.toObject(PurchaseOrder::class.java) }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
