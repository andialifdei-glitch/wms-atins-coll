package com.example.services

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.models.SopPosting
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class ExcelSopExporter(private val context: Context) {
    companion object {
        private const val TAG = "ExcelSopExporter"
    }

    /**
     * Exports a POST Stock Opname Report to CSV with UTF-8 BOM so Microsoft Excel and Sheets open it seamlessly.
     */
    suspend fun exportPostReportExcel(posting: SopPosting): Result<File> = withContext(Dispatchers.IO) {
        try {
            val cacheDir = File(context.cacheDir, "reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            // File name per requirement: POST-YYYYMMDD-XXX.xlsx or .csv
            val file = File(cacheDir, "${posting.documentNo}.csv")

            FileOutputStream(file).use { fos ->
                // Write UTF-8 BOM for immediate proper rendering in Excel
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                OutputStreamWriter(fos, Charsets.UTF_8).use { writer ->
                    // Header Block
                    writer.write("POST STOCK OPNAME REPORT\n")
                    writer.write("POST Document No,${escapeCsv(posting.documentNo)}\n")
                    writer.write("SOP Ref Document,${escapeCsv(posting.sopDocumentNo)}\n")
                    writer.write("Tanggal Posting,${escapeCsv(posting.date)}\n")
                    writer.write("Posted By,${escapeCsv(posting.postedBy)}\n")
                    writer.write("\n")

                    // Summary
                    writer.write("RINGKASAN\n")
                    writer.write("Total SKU,${posting.totalSku}\n")
                    writer.write("Total Surplus,+${posting.totalSurplus}\n")
                    writer.write("Total Shortage,-${posting.totalShortage}\n")
                    writer.write("Net Difference,${posting.netDifference}\n")
                    writer.write("\n")

                    // Data Table Headers per Section 21
                    val headers = listOf("No", "SKU", "Nama Barang", "Stock Before", "Physical Count", "Adjustment", "Stock After")
                    writer.write(headers.joinToString(",") { escapeCsv(it) } + "\n")

                    // Rows
                    posting.items.forEachIndexed { index, item ->
                        val row = listOf(
                            (index + 1).toString(),
                            item.sku,
                            item.itemName,
                            item.stockBefore.toString(),
                            item.physicalCount.toString(),
                            if (item.adjustment > 0) "+${item.adjustment}" else item.adjustment.toString(),
                            item.stockAfter.toString()
                        )
                        writer.write(row.joinToString(",") { escapeCsv(it) } + "\n")
                    }
                    writer.flush()
                }
            }

            Log.d(TAG, "POST Excel report written to: ${file.absolutePath}")
            Result.success(file)
        } catch (e: Exception) {
            Log.e(TAG, "Error exporting POST Excel report: ${e.message}", e)
            Result.failure(e)
        }
    }

    fun shareExcel(file: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Bagikan Dokumen ${file.name}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    private fun escapeCsv(value: String): String {
        return if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }
    }
}
