package com.example.services

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.models.PurchaseOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Locale

class PdfPoGenerator(private val context: Context) {
    companion object {
        private const val TAG = "PdfPoGenerator"
        // Standard A4 dimensions at 72 DPI: 595 x 842 points
        private const val PAGE_WIDTH = 595
        private const val PAGE_HEIGHT = 842
    }

    private val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    /**
     * Generates an A4 PDF document for the Purchase Order and returns the saved File.
     */
    suspend fun generatePurchaseOrderPdf(po: PurchaseOrder): Result<File> = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val subTitlePaint = Paint().apply {
            color = Color.rgb(180, 75, 105) // Dusty pink brand accent
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val regularPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 10f
        }

        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }

        val tableHeaderPaint = Paint().apply {
            color = Color.rgb(245, 235, 238)
            style = Paint.Style.FILL
        }

        try {
            val itemsPerPage = 18
            val totalPages = (po.items.size + itemsPerPage - 1) / itemsPerPage.coerceAtLeast(1)
            val pagesToCreate = totalPages.coerceAtLeast(1)

            for (pageIndex in 0 until pagesToCreate) {
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex + 1).create()
                val page = document.startPage(pageInfo)
                val canvas = page.canvas

                var y = 45f

                // Header
                canvas.drawText("PURCHASE ORDER", 40f, y, titlePaint)
                canvas.drawText("Atin's Collection", 40f, y + 18f, subTitlePaint)

                // PO Info (Right aligned)
                boldPaint.textAlign = Paint.Align.RIGHT
                regularPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("PO ID: ${po.poId}", PAGE_WIDTH - 40f, y, boldPaint)
                canvas.drawText("Tanggal: ${po.poDate}", PAGE_WIDTH - 40f, y + 14f, regularPaint)
                canvas.drawText("Status: ${po.status}", PAGE_WIDTH - 40f, y + 28f, regularPaint)
                boldPaint.textAlign = Paint.Align.LEFT
                regularPaint.textAlign = Paint.Align.LEFT

                y += 50f
                canvas.drawLine(40f, y, PAGE_WIDTH - 40f, y, linePaint)
                y += 20f

                // Supplier Details
                canvas.drawText("KEPADA SUPPLIER:", 40f, y, boldPaint)
                y += 14f
                canvas.drawText("Nama: ${po.supplier}", 40f, y, regularPaint)
                if (po.supplierAddress.isNotBlank()) {
                    y += 13f
                    canvas.drawText("Alamat: ${po.supplierAddress}", 40f, y, regularPaint)
                }
                if (po.supplierPhone.isNotBlank()) {
                    y += 13f
                    canvas.drawText("Telepon: ${po.supplierPhone}", 40f, y, regularPaint)
                }

                y += 25f

                // Table Header
                canvas.drawRect(40f, y - 12f, PAGE_WIDTH - 40f, y + 8f, tableHeaderPaint)
                canvas.drawText("NO", 45f, y, boldPaint)
                canvas.drawText("SKU", 75f, y, boldPaint)
                canvas.drawText("NAMA BARANG", 175f, y, boldPaint)
                canvas.drawText("QTY", 345f, y, boldPaint)
                canvas.drawText("HARGA BELI", 400f, y, boldPaint)
                canvas.drawText("SUBTOTAL", 485f, y, boldPaint)

                y += 14f
                canvas.drawLine(40f, y - 4f, PAGE_WIDTH - 40f, y - 4f, linePaint)

                // Items for this page
                val startIndex = pageIndex * itemsPerPage
                val endIndex = (startIndex + itemsPerPage).coerceAtMost(po.items.size)

                for (i in startIndex until endIndex) {
                    val item = po.items[i]
                    canvas.drawText("${i + 1}", 45f, y + 8f, regularPaint)
                    canvas.drawText(item.sku, 75f, y + 8f, regularPaint)

                    val maxNameLen = 26
                    val truncatedName = if (item.itemName.length > maxNameLen) {
                        item.itemName.take(maxNameLen - 2) + ".."
                    } else {
                        item.itemName
                    }
                    canvas.drawText(truncatedName, 175f, y + 8f, regularPaint)
                    canvas.drawText("${item.qty}", 345f, y + 8f, regularPaint)
                    canvas.drawText(rupiahFormat.format(item.purchasingPrice), 400f, y + 8f, regularPaint)
                    canvas.drawText(rupiahFormat.format(item.subtotal), 485f, y + 8f, boldPaint)

                    y += 20f
                    canvas.drawLine(40f, y - 4f, PAGE_WIDTH - 40f, y - 4f, linePaint)
                }

                // If last page, draw Total & Signature lines
                if (pageIndex == pagesToCreate - 1) {
                    y += 20f
                    boldPaint.textAlign = Paint.Align.RIGHT
                    canvas.drawText("TOTAL PURCHASE ORDER: ${rupiahFormat.format(po.total)}", PAGE_WIDTH - 40f, y, boldPaint)
                    boldPaint.textAlign = Paint.Align.LEFT

                    if (po.notes.isNotBlank()) {
                        y += 18f
                        canvas.drawText("Catatan: ${po.notes}", 40f, y, regularPaint)
                    }

                    // Signatures
                    y = PAGE_HEIGHT - 120f
                    canvas.drawText("Dibuat oleh,", 60f, y, regularPaint)
                    canvas.drawText("Supplier,", PAGE_WIDTH - 140f, y, regularPaint)

                    canvas.drawLine(50f, y + 60f, 150f, y + 60f, linePaint)
                    canvas.drawLine(PAGE_WIDTH - 160f, y + 60f, PAGE_WIDTH - 60f, y + 60f, linePaint)

                    canvas.drawText("(${po.createdBy.ifBlank { "Staff" }})", 65f, y + 74f, regularPaint)
                    canvas.drawText("(${po.supplier})", PAGE_WIDTH - 150f, y + 74f, regularPaint)
                }

                // Page numbering footer
                regularPaint.textAlign = Paint.Align.CENTER
                canvas.drawText("Halaman ${pageIndex + 1} dari $pagesToCreate", PAGE_WIDTH / 2f, PAGE_HEIGHT - 25f, regularPaint)
                regularPaint.textAlign = Paint.Align.LEFT

                document.finishPage(page)
            }

            // Save to internal cache directory
            val cacheDir = File(context.cacheDir, "pdf_reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val pdfFile = File(cacheDir, "${po.poId}.pdf")

            FileOutputStream(pdfFile).use { out ->
                document.writeTo(out)
            }
            document.close()

            Log.d(TAG, "PO PDF generated at: ${pdfFile.absolutePath}")
            Result.success(pdfFile)
        } catch (e: Exception) {
            document.close()
            Log.e(TAG, "Error generating PO PDF: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Shares the generated PO PDF via Android Intent.
     */
    fun sharePdf(file: File, poId: String) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Purchase Order - $poId")
                putExtra(Intent.EXTRA_TEXT, "Berikut terlampir dokumen Purchase Order: $poId dari Atin's Collection.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(shareIntent, "Bagikan Purchase Order via...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e(TAG, "Error sharing PDF: ${e.message}", e)
        }
    }
}
