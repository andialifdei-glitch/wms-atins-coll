package com.example.services

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.models.DeliveryOrder
import com.example.data.models.Receiving
import com.example.data.models.SalesOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Locale

class PdfDocumentGenerator(private val context: Context) {
    companion object {
        private const val TAG = "PdfDocumentGenerator"
        private const val PAGE_WIDTH = 595
        private const val PAGE_HEIGHT = 842
    }

    private val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    /**
     * Generates an A4 PDF document for a Sales Order.
     */
    suspend fun generateSalesOrderPdf(so: SalesOrder): Result<File> = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val subTitlePaint = Paint().apply {
            color = Color.rgb(180, 75, 105)
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val regularPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 10f
        }

        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }

        val tableHeaderPaint = Paint().apply {
            color = Color.rgb(245, 235, 238)
            style = Paint.Style.FILL
        }

        try {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            var y = 45f

            // Header
            canvas.drawText("SALES ORDER", 40f, y, titlePaint)
            canvas.drawText("Atin's Collection", 40f, y + 18f, subTitlePaint)

            boldPaint.textAlign = Paint.Align.RIGHT
            regularPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("NO SO: ${so.soId}", PAGE_WIDTH - 40f, y, boldPaint)
            canvas.drawText("Tanggal: ${so.date}", PAGE_WIDTH - 40f, y + 14f, regularPaint)
            canvas.drawText("Status: ${so.status}", PAGE_WIDTH - 40f, y + 28f, regularPaint)
            boldPaint.textAlign = Paint.Align.LEFT
            regularPaint.textAlign = Paint.Align.LEFT

            y += 50f
            canvas.drawLine(40f, y, PAGE_WIDTH - 40f, y, linePaint)
            y += 20f

            // Customer details
            canvas.drawText("PEMESAN / CUSTOMER:", 40f, y, boldPaint)
            canvas.drawText(so.customerName, 40f, y + 14f, regularPaint)
            canvas.drawText("Telp: ${so.phone}", 40f, y + 26f, regularPaint)
            canvas.drawText("Alamat: ${so.address}", 40f, y + 38f, regularPaint)

            boldPaint.textAlign = Paint.Align.RIGHT
            regularPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("EKSPEDISI PENGIRIMAN:", PAGE_WIDTH - 40f, y, boldPaint)
            canvas.drawText(so.expedition.ifBlank { "-" }, PAGE_WIDTH - 40f, y + 14f, regularPaint)
            boldPaint.textAlign = Paint.Align.LEFT
            regularPaint.textAlign = Paint.Align.LEFT

            y += 60f

            // Table Header
            canvas.drawRect(40f, y, PAGE_WIDTH - 40f, y + 22f, tableHeaderPaint)
            canvas.drawText("SKU", 50f, y + 15f, boldPaint)
            canvas.drawText("Nama Barang", 140f, y + 15f, boldPaint)
            canvas.drawText("Qty", 320f, y + 15f, boldPaint)
            canvas.drawText("Harga Satuan", 380f, y + 15f, boldPaint)
            boldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("Subtotal", PAGE_WIDTH - 50f, y + 15f, boldPaint)
            boldPaint.textAlign = Paint.Align.LEFT

            y += 30f

            for (item in so.items) {
                canvas.drawText(item.sku, 50f, y, regularPaint)
                val displayName = if (item.itemName.length > 25) item.itemName.take(24) + "..." else item.itemName
                canvas.drawText(displayName, 140f, y, regularPaint)
                canvas.drawText("${item.qty} pcs", 320f, y, regularPaint)
                canvas.drawText(rupiahFormat.format(item.price), 380f, y, regularPaint)

                regularPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText(rupiahFormat.format(item.subtotal), PAGE_WIDTH - 50f, y, regularPaint)
                regularPaint.textAlign = Paint.Align.LEFT

                y += 20f
                canvas.drawLine(40f, y - 5f, PAGE_WIDTH - 40f, y - 5f, linePaint)
            }

            y += 15f
            boldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("TOTAL: ${rupiahFormat.format(so.total)}", PAGE_WIDTH - 50f, y, boldPaint)
            boldPaint.textAlign = Paint.Align.LEFT

            document.finishPage(page)

            val cacheDir = File(context.cacheDir, "pdf_reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val pdfFile = File(cacheDir, "${so.soId}.pdf")
            FileOutputStream(pdfFile).use { fos ->
                document.writeTo(fos)
            }
            document.close()
            Result.success(pdfFile)
        } catch (e: Exception) {
            document.close()
            Log.e(TAG, "Error generating SO PDF: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Generates an A4 PDF document for a Delivery Order Shipping Label.
     * Matches exact format with thermal print and preview.
     */
    suspend fun generateDeliveryOrderPdf(
        doOrder: DeliveryOrder,
        storeSettings: com.example.data.models.StoreSettings? = null,
        printedBy: String = ""
    ): Result<File> = withContext(Dispatchers.IO) {
        val labelData = com.example.data.models.DoShippingLabelData.fromDeliveryOrder(
            doOrder = doOrder,
            storeSettings = storeSettings,
            fallbackUser = printedBy
        )
        val document = PdfDocument()

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 22f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val sectionHeaderPaint = Paint().apply {
            color = Color.BLACK
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val regularPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 12f
        }

        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1.5f
        }

        try {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            var y = 60f

            // DELIVERY ORDER Header (Centered, bold, uppercase)
            canvas.drawText("DELIVERY ORDER", PAGE_WIDTH / 2f, y, titlePaint)
            y += 32f

            // DO & Ekspedisi
            canvas.drawText("DO : ${labelData.doNumber}", 40f, y, boldPaint)
            y += 18f
            canvas.drawText("Ekspedisi : ${labelData.shippingService}", 40f, y, boldPaint)
            y += 22f
            canvas.drawLine(40f, y, PAGE_WIDTH - 40f, y, linePaint)
            y += 24f

            // PENGIRIM
            canvas.drawText("PENGIRIM", 40f, y, sectionHeaderPaint)
            y += 18f
            val senderLines = wrapText(labelData.senderName, 65)
            for (line in senderLines) {
                canvas.drawText(line, 40f, y, regularPaint)
                y += 18f
            }
            y += 8f

            // NO HANDPHONE
            canvas.drawText("NO HANDPHONE", 40f, y, sectionHeaderPaint)
            y += 18f
            canvas.drawText(labelData.senderPhone, 40f, y, regularPaint)
            y += 22f
            canvas.drawLine(40f, y, PAGE_WIDTH - 40f, y, linePaint)
            y += 24f

            // PENERIMA
            canvas.drawText("PENERIMA", 40f, y, sectionHeaderPaint)
            y += 18f
            val recipientLines = wrapText(labelData.recipientName, 65)
            for (line in recipientLines) {
                canvas.drawText(line, 40f, y, regularPaint)
                y += 18f
            }
            y += 8f

            // ALAMAT
            canvas.drawText("ALAMAT", 40f, y, sectionHeaderPaint)
            y += 18f
            val addressLines = wrapText(labelData.recipientAddress, 65)
            for (line in addressLines) {
                canvas.drawText(line, 40f, y, regularPaint)
                y += 18f
            }
            y += 8f

            // NO HANDPHONE
            canvas.drawText("NO HANDPHONE", 40f, y, sectionHeaderPaint)
            y += 18f
            canvas.drawText(labelData.recipientPhone, 40f, y, regularPaint)
            y += 22f
            canvas.drawLine(40f, y, PAGE_WIDTH - 40f, y, linePaint)
            y += 24f

            // SO, Tanggal Cetak, By
            canvas.drawText("SO : ${labelData.soNumber}", 40f, y, boldPaint)
            y += 18f
            canvas.drawText("Tanggal Cetak : ${labelData.printDate}", 40f, y, boldPaint)
            y += 18f
            canvas.drawText("By : ${labelData.printedBy}", 40f, y, boldPaint)

            document.finishPage(page)

            val cacheDir = File(context.cacheDir, "pdf_reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val pdfFile = File(cacheDir, "${labelData.doNumber}.pdf")
            FileOutputStream(pdfFile).use { fos ->
                document.writeTo(fos)
            }
            document.close()
            Result.success(pdfFile)
        } catch (e: Exception) {
            document.close()
            Log.e(TAG, "Error generating DO PDF: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun wrapText(text: String, maxCharsPerLine: Int): List<String> {
        val rawLines = text.split(Regex("\r?\n"))
        val result = mutableListOf<String>()

        for (rawLine in rawLines) {
            if (rawLine.length <= maxCharsPerLine) {
                result.add(rawLine)
                continue
            }
            val words = rawLine.split(Regex("\\s+")).filter { it.isNotEmpty() }
            val currentLine = StringBuilder()

            for (word in words) {
                if (currentLine.isEmpty()) {
                    if (word.length <= maxCharsPerLine) {
                        currentLine.append(word)
                    } else {
                        var rem = word
                        while (rem.length > maxCharsPerLine) {
                            result.add(rem.substring(0, maxCharsPerLine))
                            rem = rem.substring(maxCharsPerLine)
                        }
                        currentLine.append(rem)
                    }
                } else if (currentLine.length + 1 + word.length <= maxCharsPerLine) {
                    currentLine.append(' ').append(word)
                } else {
                    result.add(currentLine.toString())
                    currentLine.setLength(0)
                    currentLine.append(word)
                }
            }
            if (currentLine.isNotEmpty()) {
                result.add(currentLine.toString())
            }
        }
        return result
    }

    /**
     * Generates an A4 PDF document for a Receiving record.
     */
    suspend fun generateReceivingPdf(recv: Receiving): Result<File> = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val subTitlePaint = Paint().apply {
            color = Color.rgb(180, 75, 105)
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val regularPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 10f
        }

        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }

        val tableHeaderPaint = Paint().apply {
            color = Color.rgb(245, 235, 238)
            style = Paint.Style.FILL
        }

        try {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            var y = 45f

            // Header
            canvas.drawText("BUKTI PENERIMAAN BARANG (RECEIVING)", 40f, y, titlePaint)
            canvas.drawText("Atin's Collection", 40f, y + 18f, subTitlePaint)

            boldPaint.textAlign = Paint.Align.RIGHT
            regularPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("NO RECEIVING: ${recv.receivingId}", PAGE_WIDTH - 40f, y, boldPaint)
            canvas.drawText("Ref PO: ${recv.poId}", PAGE_WIDTH - 40f, y + 14f, regularPaint)
            canvas.drawText("Tanggal: ${recv.date}", PAGE_WIDTH - 40f, y + 28f, regularPaint)
            canvas.drawText("Penerima: ${recv.createdBy}", PAGE_WIDTH - 40f, y + 42f, regularPaint)
            boldPaint.textAlign = Paint.Align.LEFT
            regularPaint.textAlign = Paint.Align.LEFT

            y += 65f
            canvas.drawLine(40f, y, PAGE_WIDTH - 40f, y, linePaint)
            y += 20f

            if (recv.notes.isNotBlank()) {
                canvas.drawText("Catatan: ${recv.notes}", 40f, y, regularPaint)
                y += 20f
            }

            // Table Header
            canvas.drawRect(40f, y, PAGE_WIDTH - 40f, y + 22f, tableHeaderPaint)
            canvas.drawText("No", 50f, y + 15f, boldPaint)
            canvas.drawText("SKU", 80f, y + 15f, boldPaint)
            canvas.drawText("Nama Barang", 220f, y + 15f, boldPaint)
            boldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("Qty Diterima", PAGE_WIDTH - 50f, y + 15f, boldPaint)
            boldPaint.textAlign = Paint.Align.LEFT

            y += 30f

            recv.items.forEachIndexed { idx, item ->
                canvas.drawText("${idx + 1}", 50f, y, regularPaint)
                canvas.drawText(item.sku, 80f, y, regularPaint)
                val displayName = if (item.itemName.length > 35) item.itemName.take(34) + "..." else item.itemName
                canvas.drawText(displayName, 220f, y, regularPaint)

                regularPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("${item.qtyReceived} pcs", PAGE_WIDTH - 50f, y, regularPaint)
                regularPaint.textAlign = Paint.Align.LEFT

                y += 20f
                canvas.drawLine(40f, y - 5f, PAGE_WIDTH - 40f, y - 5f, linePaint)
            }

            y += 15f
            val totalQty = recv.items.sumOf { it.qtyReceived }
            boldPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("TOTAL DITERIMA: $totalQty pcs", PAGE_WIDTH - 50f, y, boldPaint)
            boldPaint.textAlign = Paint.Align.LEFT

            document.finishPage(page)

            val cacheDir = File(context.cacheDir, "pdf_reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val pdfFile = File(cacheDir, "${recv.receivingId}.pdf")
            FileOutputStream(pdfFile).use { fos ->
                document.writeTo(fos)
            }
            document.close()
            Result.success(pdfFile)
        } catch (e: Exception) {
            document.close()
            Log.e(TAG, "Error generating Receiving PDF: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Shares a generated PDF file via Android Share Sheet.
     */
    fun sharePdf(file: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Bagikan Dokumen ${file.name}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
