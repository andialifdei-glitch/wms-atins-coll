package com.example.services

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExcelExporter(private val context: Context) {
    companion object {
        private const val TAG = "ExcelExporter"
    }

    /**
     * Writes CSV data (with UTF-8 BOM for automatic Excel recognition) and shares via Intent.
     */
    suspend fun exportReport(
        reportTitle: String,
        headers: List<String>,
        rows: List<List<String>>
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val cacheDir = File(context.cacheDir, "reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val safeFileName = "${reportTitle.replace(Regex("[^a-zA-Z0-9_]"), "_")}_$timestamp.csv"
            val file = File(cacheDir, safeFileName)

            FileOutputStream(file).use { fos ->
                // UTF-8 BOM so Microsoft Excel opens it with proper UTF-8 encoding
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                OutputStreamWriter(fos, Charsets.UTF_8).use { writer ->
                    // Write Header
                    writer.write(headers.joinToString(",") { escapeCsv(it) } + "\n")

                    // Write Rows
                    for (row in rows) {
                        writer.write(row.joinToString(",") { escapeCsv(it) } + "\n")
                    }
                    writer.flush()
                }
            }

            Log.d(TAG, "Report exported to: ${file.absolutePath}")
            Result.success(file)
        } catch (e: Exception) {
            Log.e(TAG, "Error exporting report: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun escapeCsv(value: String): String {
        var str = value.replace("\"", "\"\"")
        if (str.contains(",") || str.contains("\n") || str.contains("\"")) {
            str = "\"$str\""
        }
        return str
    }

    fun shareExportedFile(file: File, reportTitle: String) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Laporan WMS - $reportTitle")
                putExtra(Intent.EXTRA_TEXT, "Terlampir file laporan $reportTitle dari sistem WMS Atin's Collection.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(shareIntent, "Bagikan Laporan Spreadsheet...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e(TAG, "Error sharing exported file: ${e.message}", e)
        }
    }
}
