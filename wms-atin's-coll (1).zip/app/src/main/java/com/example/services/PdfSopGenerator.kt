package com.example.services

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.models.SopPosting
import com.example.data.models.StockOpname
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Locale

class PdfSopGenerator(private val context: Context) {
    companion object {
        private const val TAG = "PdfSopGenerator"
        private const val PAGE_WIDTH = 595
        private const val PAGE_HEIGHT = 842
    }

    /**
     * Generates a Stock Opname Report PDF (SOP-YYYYMMDD-XXX.pdf)
     */
    suspend fun generateSopReportPdf(sop: StockOpname): Result<File> = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subTitlePaint = Paint().apply {
            color = Color.rgb(180, 75, 105) // Dusty pink
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val regularPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 9f
        }
        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }
        val headerBgPaint = Paint().apply {
            color = Color.rgb(245, 235, 238)
        }

        try {
            val items = sop.items
            val itemsPerPage = 25
            val totalPages = maxOf(1, (items.size + itemsPerPage - 1) / itemsPerPage)

            val totalSku = items.size
            val skuSurplus = items.count { ((it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot) > 0 }
            val skuShortage = items.count { ((it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot) < 0 }
            val skuMatch = items.count { ((it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot) == 0 }
            val totalSurplus = items.filter { ((it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot) > 0 }
                .sumOf { (it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot }
            val totalShortage = items.filter { ((it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot) < 0 }
                .sumOf { it.systemQtySnapshot - (it.physicalQty ?: it.systemQtySnapshot) }
            val netDifference = items.sumOf { (it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot }

            var itemIdx = 0
            for (pageNumber in 1..totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                val page = document.startPage(pageInfo)
                val canvas: Canvas = page.canvas

                var y = 40f

                // Header
                canvas.drawText("STOCK OPNAME REPORT", 40f, y, titlePaint)
                y += 18f
                canvas.drawText("Atin's Collection — Warehouse Management System", 40f, y, subTitlePaint)
                y += 18f

                canvas.drawLine(40f, y, (PAGE_WIDTH - 40).toFloat(), y, linePaint)
                y += 15f

                // Info block
                canvas.drawText("Document No : ${sop.documentNo}", 40f, y, boldPaint)
                canvas.drawText("Tanggal Opname : ${sop.opnameDate}", 320f, y, regularPaint)
                y += 14f
                canvas.drawText("Initialized By : ${sop.initializedBy}", 40f, y, regularPaint)
                val completedAtStr = sop.countingCompletedAt?.toDate()?.let {
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(it)
                } ?: "-"
                canvas.drawText("Completed By   : ${sop.countingCompletedBy.ifBlank { "-" }} ($completedAtStr)", 320f, y, regularPaint)
                y += 14f
                canvas.drawText("Status Dokumen: ${sop.status}", 40f, y, boldPaint)
                y += 18f

                // Summary Box on Page 1
                if (pageNumber == 1) {
                    canvas.drawRect(40f, y, (PAGE_WIDTH - 40).toFloat(), y + 42f, headerBgPaint)
                    canvas.drawText("Total SKU: $totalSku  |  Sesuai: $skuMatch  |  Surplus: $skuSurplus (+ $totalSurplus pcs)  |  Shortage: $skuShortage (- $totalShortage pcs)", 50f, y + 16f, regularPaint)
                    val netSign = if (netDifference > 0) "+$netDifference" else "$netDifference"
                    canvas.drawText("NET DIFFERENCE: $netSign pcs", 50f, y + 32f, boldPaint)
                    y += 55f
                }

                // Table Header
                canvas.drawRect(40f, y - 10f, (PAGE_WIDTH - 40).toFloat(), y + 12f, headerBgPaint)
                canvas.drawText("No", 45f, y + 5f, boldPaint)
                canvas.drawText("SKU", 70f, y + 5f, boldPaint)
                canvas.drawText("Nama Barang", 170f, y + 5f, boldPaint)
                canvas.drawText("Snapshot", 370f, y + 5f, boldPaint)
                canvas.drawText("Fisik", 435f, y + 5f, boldPaint)
                canvas.drawText("Difference", 485f, y + 5f, boldPaint)
                y += 20f

                // Table Rows
                val pageEndIdx = minOf(itemIdx + itemsPerPage, items.size)
                while (itemIdx < pageEndIdx) {
                    val item = items[itemIdx]
                    val phys = item.physicalQty ?: item.systemQtySnapshot
                    val diff = phys - item.systemQtySnapshot
                    val diffStr = if (diff > 0) "+$diff" else "$diff"

                    canvas.drawText("${itemIdx + 1}", 45f, y, regularPaint)
                    canvas.drawText(item.skuId, 70f, y, regularPaint)
                    val nameTrimmed = if (item.itemName.length > 30) item.itemName.substring(0, 28) + "..." else item.itemName
                    canvas.drawText(nameTrimmed, 170f, y, regularPaint)
                    canvas.drawText("${item.systemQtySnapshot}", 375f, y, regularPaint)
                    canvas.drawText("$phys", 440f, y, regularPaint)

                    val diffPaint = Paint(boldPaint).apply {
                        color = when {
                            diff < 0 -> Color.RED
                            diff > 0 -> Color.rgb(0, 140, 60)
                            else -> Color.DKGRAY
                        }
                    }
                    canvas.drawText(diffStr, 490f, y, diffPaint)

                    y += 16f
                    canvas.drawLine(40f, y - 4f, (PAGE_WIDTH - 40).toFloat(), y - 4f, linePaint)
                    itemIdx++
                }

                // Footer
                val footerY = (PAGE_HEIGHT - 35).toFloat()
                canvas.drawText("Hal $pageNumber dari $totalPages", (PAGE_WIDTH - 100).toFloat(), footerY, regularPaint)
                canvas.drawText("Dicetak: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(java.util.Date())}", 40f, footerY, regularPaint)

                document.finishPage(page)
            }

            val cacheDir = File(context.cacheDir, "reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val pdfFile = File(cacheDir, "${sop.documentNo}.pdf")
            FileOutputStream(pdfFile).use { fos ->
                document.writeTo(fos)
            }
            document.close()

            Log.d(TAG, "SOP Report PDF created: ${pdfFile.absolutePath}")
            Result.success(pdfFile)
        } catch (e: Exception) {
            document.close()
            Log.e(TAG, "Error generating SOP PDF: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Generates a Post Stock Opname Report PDF (POST-YYYYMMDD-XXX.pdf)
     */
    suspend fun generatePostReportPdf(posting: SopPosting, sop: StockOpname?): Result<File> = withContext(Dispatchers.IO) {
        val document = PdfDocument()

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subTitlePaint = Paint().apply {
            color = Color.rgb(180, 75, 105)
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val regularPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 9f
        }
        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }
        val headerBgPaint = Paint().apply {
            color = Color.rgb(240, 240, 245)
        }

        try {
            val items = posting.items
            val itemsPerPage = 25
            val totalPages = maxOf(1, (items.size + itemsPerPage - 1) / itemsPerPage)

            var itemIdx = 0
            for (pageNumber in 1..totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                val page = document.startPage(pageInfo)
                val canvas: Canvas = page.canvas

                var y = 40f

                // Header
                canvas.drawText("POST STOCK OPNAME REPORT", 40f, y, titlePaint)
                y += 18f
                canvas.drawText("Atin's Collection — Warehouse Management System", 40f, y, subTitlePaint)
                y += 18f

                canvas.drawLine(40f, y, (PAGE_WIDTH - 40).toFloat(), y, linePaint)
                y += 15f

                // Metadata
                canvas.drawText("POST Document No : ${posting.documentNo}", 40f, y, boldPaint)
                canvas.drawText("SOP Ref Document  : ${posting.sopDocumentNo}", 320f, y, boldPaint)
                y += 14f
                canvas.drawText("Tanggal Posting  : ${posting.date}", 40f, y, regularPaint)
                canvas.drawText("Posted By         : ${posting.postedBy}", 320f, y, regularPaint)
                y += 18f

                // Summary box on Page 1
                if (pageNumber == 1) {
                    canvas.drawRect(40f, y, (PAGE_WIDTH - 40).toFloat(), y + 42f, headerBgPaint)
                    canvas.drawText("Total SKU: ${posting.totalSku}  |  Total Surplus: +${posting.totalSurplus} pcs  |  Total Shortage: -${posting.totalShortage} pcs", 50f, y + 16f, regularPaint)
                    val netStr = if (posting.netDifference > 0) "+${posting.netDifference}" else "${posting.netDifference}"
                    canvas.drawText("NET DIFFERENCE: $netStr pcs  (Stock balances updated to final physical counts)", 50f, y + 32f, boldPaint)
                    y += 55f
                }

                // Table Header
                canvas.drawRect(40f, y - 10f, (PAGE_WIDTH - 40).toFloat(), y + 12f, headerBgPaint)
                canvas.drawText("No", 45f, y + 5f, boldPaint)
                canvas.drawText("SKU", 70f, y + 5f, boldPaint)
                canvas.drawText("Nama Barang", 170f, y + 5f, boldPaint)
                canvas.drawText("Before", 360f, y + 5f, boldPaint)
                canvas.drawText("Fisik", 410f, y + 5f, boldPaint)
                canvas.drawText("Adj", 455f, y + 5f, boldPaint)
                canvas.drawText("After", 495f, y + 5f, boldPaint)
                y += 20f

                val pageEndIdx = minOf(itemIdx + itemsPerPage, items.size)
                while (itemIdx < pageEndIdx) {
                    val item = items[itemIdx]
                    val adjStr = if (item.adjustment > 0) "+${item.adjustment}" else "${item.adjustment}"

                    canvas.drawText("${itemIdx + 1}", 45f, y, regularPaint)
                    canvas.drawText(item.sku, 70f, y, regularPaint)
                    val nameTrimmed = if (item.itemName.length > 28) item.itemName.substring(0, 26) + "..." else item.itemName
                    canvas.drawText(nameTrimmed, 170f, y, regularPaint)
                    canvas.drawText("${item.stockBefore}", 365f, y, regularPaint)
                    canvas.drawText("${item.physicalCount}", 415f, y, regularPaint)

                    val adjPaint = Paint(boldPaint).apply {
                        color = when {
                            item.adjustment < 0 -> Color.RED
                            item.adjustment > 0 -> Color.rgb(0, 140, 60)
                            else -> Color.DKGRAY
                        }
                    }
                    canvas.drawText(adjStr, 458f, y, adjPaint)
                    canvas.drawText("${item.stockAfter}", 498f, y, boldPaint)

                    y += 16f
                    canvas.drawLine(40f, y - 4f, (PAGE_WIDTH - 40).toFloat(), y - 4f, linePaint)
                    itemIdx++
                }

                // Footer
                val footerY = (PAGE_HEIGHT - 35).toFloat()
                canvas.drawText("Hal $pageNumber dari $totalPages", (PAGE_WIDTH - 100).toFloat(), footerY, regularPaint)
                canvas.drawText("Status: POSTED / COMPLETED", 40f, footerY, regularPaint)

                document.finishPage(page)
            }

            val cacheDir = File(context.cacheDir, "reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val pdfFile = File(cacheDir, "${posting.documentNo}.pdf")
            FileOutputStream(pdfFile).use { fos ->
                document.writeTo(fos)
            }
            document.close()

            Log.d(TAG, "POST Report PDF created: ${pdfFile.absolutePath}")
            Result.success(pdfFile)
        } catch (e: Exception) {
            document.close()
            Log.e(TAG, "Error generating POST PDF: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Shares a generated PDF file via Android Share Sheet.
     */
    fun sharePdf(file: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Bagikan Dokumen ${file.name}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
