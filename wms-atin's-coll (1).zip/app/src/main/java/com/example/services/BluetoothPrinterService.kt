package com.example.services

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.models.DeliveryOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.util.UUID

data class PrinterDeviceInfo(
    val name: String,
    val address: String,
    val isBonded: Boolean = false
)

class BluetoothPrinterService(private val context: Context) {
    companion object {
        private const val TAG = "BtPrinterService"
        // Standard Serial Port Profile (SPP) UUID for Bluetooth thermal printers
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        // ESC/POS Commands
        private val CMD_INIT = byteArrayOf(0x1B, 0x40) // Initialize printer
        private val CMD_CODE_PAGE_CP437 = byteArrayOf(0x1B, 0x74, 0x00) // Select Code Page 0 (PC437)
        private val CMD_LINE_SPACING_DEFAULT = byteArrayOf(0x1B, 0x32) // Default line spacing
        private val CMD_LINE_SPACING_COMFORTABLE = byteArrayOf(0x1B, 0x33, 32.toByte()) // Comfortable line spacing (32 dots)
        private val CMD_ALIGN_CENTER = byteArrayOf(0x1B, 0x61, 0x01)
        private val CMD_ALIGN_LEFT = byteArrayOf(0x1B, 0x61, 0x00)
        private val CMD_ALIGN_RIGHT = byteArrayOf(0x1B, 0x61, 0x02)
        private val CMD_BOLD_ON = byteArrayOf(0x1B, 0x45, 0x01)
        private val CMD_BOLD_OFF = byteArrayOf(0x1B, 0x45, 0x00)
        private val CMD_DOUBLE_HEIGHT_ON = byteArrayOf(0x1D, 0x21, 0x01)
        private val CMD_NORMAL_SIZE = byteArrayOf(0x1D, 0x21, 0x00)
        private val CMD_FEED_LINE = byteArrayOf(0x0A)
        private val CMD_CUT = byteArrayOf(0x1D, 0x56, 0x41, 0x10) // Cut paper
    }

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        manager?.adapter ?: BluetoothAdapter.getDefaultAdapter()
    }

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val connect = ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            val scan = ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
            connect && scan
        } else {
            val bt = ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED
            val admin = ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED
            bt && admin
        }
    }

    fun isBluetoothEnabled(): Boolean {
        return bluetoothAdapter?.isEnabled == true
    }

    @SuppressLint("MissingPermission")
    fun getPairedPrinters(): List<PrinterDeviceInfo> {
        if (!hasBluetoothPermission() || bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            return emptyList()
        }
        return try {
            val bonded = bluetoothAdapter!!.bondedDevices
            bonded.map { device ->
                PrinterDeviceInfo(
                    name = device.name ?: "Unknown Device",
                    address = device.address,
                    isBonded = true
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting paired printers: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Sanitizes input text to guarantee 100% 1-byte ASCII / Code Page 437 compatibility.
     * Replaces multibyte unicode characters (curly quotes, dashes, non-breaking spaces, box-drawings)
     * with standard single-byte ASCII characters to prevent printer garbage sequences like 'öÇöÇ...'.
     */
    private fun sanitizeText(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            when (ch) {
                // Curly quotes & apostrophes
                '‘', '’', '`', '´' -> sb.append('\'')
                '“', '”', '„', '«', '»' -> sb.append('"')
                // Dashes & hyphens
                '–', '—', '−', '‒' -> sb.append('-')
                // Ellipsis & bullets
                '…' -> sb.append("...")
                '•', '·', '∙' -> sb.append('-')
                // Whitespace
                '\u00A0', '\u2007', '\u202F' -> sb.append(' ') // Non-breaking spaces
                // Common Indonesian accented vowels -> plain ASCII
                'é', 'è', 'ê', 'ë' -> sb.append('e')
                'É', 'È', 'Ê', 'Ë' -> sb.append('E')
                'á', 'à', 'â', 'ã', 'ä', 'å' -> sb.append('a')
                'Á', 'À', 'Â', 'Ã', 'Ä', 'Å' -> sb.append('A')
                'í', 'ì', 'î', 'ï' -> sb.append('i')
                'Í', 'Ì', 'Î', 'Ï' -> sb.append('I')
                'ó', 'ò', 'ô', 'õ', 'ö' -> sb.append('o')
                'Ó', 'Ò', 'Ô', 'Õ', 'Ö' -> sb.append('O')
                'ú', 'ù', 'û', 'ü' -> sb.append('u')
                'Ú', 'Ù', 'Û', 'Ü' -> sb.append('U')
                'ñ' -> sb.append('n')
                'Ñ' -> sb.append('N')
                'ç' -> sb.append('c')
                'Ç' -> sb.append('C')
                // Formatting controls
                '\n', '\r', '\t' -> sb.append(ch)
                // Printable ASCII range (32 to 126)
                in ' '..'~' -> sb.append(ch)
                // Filter out any other multibyte unicode symbol
                else -> {
                    if (Character.isWhitespace(ch)) sb.append(' ')
                }
            }
        }
        return sb.toString()
    }

    /**
     * Splits text into multiple lines respecting word boundaries, up to maxCharsPerLine.
     * Prevents text truncation on narrow thermal paper (58mm, 80mm, 100mm).
     */
    private fun wrapText(text: String, maxCharsPerLine: Int): List<String> {
        val sanitized = sanitizeText(text)
        val rawLines = sanitized.split(Regex("\r?\n"))
        val result = mutableListOf<String>()

        for (rawLine in rawLines) {
            if (rawLine.length <= maxCharsPerLine) {
                result.add(rawLine)
                continue
            }
            val words = rawLine.split(Regex("\\s+")).filter { it.isNotEmpty() }
            val currentLine = StringBuilder()

            for (word in words) {
                if (currentLine.isEmpty()) {
                    if (word.length <= maxCharsPerLine) {
                        currentLine.append(word)
                    } else {
                        var rem = word
                        while (rem.length > maxCharsPerLine) {
                            result.add(rem.substring(0, maxCharsPerLine))
                            rem = rem.substring(maxCharsPerLine)
                        }
                        currentLine.append(rem)
                    }
                } else if (currentLine.length + 1 + word.length <= maxCharsPerLine) {
                    currentLine.append(' ').append(word)
                } else {
                    result.add(currentLine.toString())
                    currentLine.clear()
                    if (word.length <= maxCharsPerLine) {
                        currentLine.append(word)
                    } else {
                        var rem = word
                        while (rem.length > maxCharsPerLine) {
                            result.add(rem.substring(0, maxCharsPerLine))
                            rem = rem.substring(maxCharsPerLine)
                        }
                        currentLine.append(rem)
                    }
                }
            }
            if (currentLine.isNotEmpty()) {
                result.add(currentLine.toString())
            }
        }
        return if (result.isEmpty()) listOf("") else result
    }

    /**
     * Writes sanitized text encoded directly as 1-byte ASCII (ISO-8859-1 compatible).
     */
    private fun writeLine(stream: OutputStream, line: String) {
        val sanitized = sanitizeText(line)
        stream.write(sanitized.toByteArray(Charsets.ISO_8859_1))
        stream.write(CMD_FEED_LINE)
    }

    /**
     * Executes test print to the specified printer address.
     * Matches the exact Test Label requirements with zero multibyte garbage characters.
     */
    suspend fun printTest(printerAddress: String, paperSize: String): Result<Unit> = withContext(Dispatchers.IO) {
        val widthChars = when (paperSize) {
            "80mm" -> 48
            "100mm" -> 64
            else -> 32 // 58mm default
        }
        // Use pure ASCII '-' for dividers (never multibyte unicode box drawings)
        val divider = "-".repeat(widthChars)

        try {
            sendBytesToPrinter(printerAddress) { stream ->
                // Initialize printer & set Code Page 0 (CP437)
                stream.write(CMD_INIT)
                stream.write(CMD_CODE_PAGE_CP437)
                stream.write(CMD_LINE_SPACING_COMFORTABLE)

                // Header
                stream.write(CMD_ALIGN_CENTER)
                stream.write(CMD_BOLD_ON)
                stream.write(CMD_DOUBLE_HEIGHT_ON)
                writeLine(stream, "DELIVERY ORDER")
                stream.write(CMD_NORMAL_SIZE)
                stream.write(CMD_BOLD_OFF)
                stream.write(CMD_FEED_LINE)

                // DO ID & Ekspedisi
                stream.write(CMD_ALIGN_LEFT)
                writeLine(stream, "DO ID: DO-20261002-00001")
                writeLine(stream, "EKSPEDISI: Baraka")
                writeLine(stream, divider)

                // Pengirim
                writeLine(stream, "PENGIRIM: Atin's Collection")
                writeLine(stream, "NO HANDPHONE: 0899-7884-435")
                writeLine(stream, divider)

                // Penerima
                writeLine(stream, "NAMA PENERIMA: Hani")
                writeLine(stream, "NO TELEPON: 099878147362")
                writeLine(stream, "ALAMAT:")

                // Wrapped Address lines to prevent horizontal clipping
                val addressLines = wrapText("Jl. Contoh No. 123, Kec. Banjaran, Kab. Bandung", widthChars)
                for (addrLine in addressLines) {
                    writeLine(stream, addrLine)
                }
                writeLine(stream, divider)

                // Footer status
                stream.write(CMD_ALIGN_CENTER)
                writeLine(stream, "[TEST PRINT OK - $paperSize]")
                stream.write(CMD_FEED_LINE)
                stream.write(CMD_FEED_LINE)
                stream.write(CMD_FEED_LINE)
                stream.write(CMD_CUT)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Test print error: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Prints Delivery Order Shipping Label matching the minimal external security standard.
     * WHITELIST FIELDS ONLY:
     * - DO Number
     * - Shipping Service / Expedition
     * - Recipient Name, Phone, and Full Address
     * 
     * STRICTLY EXCLUDED: Store Name, Store Phone, Store Address, Shipping Cost, Item List, Prices.
     */
    suspend fun printDeliveryOrder(
        printerAddress: String,
        deliveryOrder: DeliveryOrder,
        paperSize: String,
        storeSettings: com.example.data.models.StoreSettings? = null,
        printedBy: String = ""
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val labelData = com.example.data.models.DoShippingLabelData.fromDeliveryOrder(
            doOrder = deliveryOrder,
            storeSettings = storeSettings,
            fallbackUser = printedBy
        )
        val widthChars = when (paperSize) {
            "80mm" -> 48
            "100mm" -> 64
            else -> 32 // 58mm default
        }
        // Strict ASCII '-' divider prevents printer from spitting 'öÇöÇ...'
        val divider = "-".repeat(widthChars)

        try {
            sendBytesToPrinter(printerAddress) { stream ->
                // Initialize printer & set Code Page 0 (CP437)
                stream.write(CMD_INIT)
                stream.write(CMD_CODE_PAGE_CP437)
                stream.write(CMD_LINE_SPACING_COMFORTABLE)

                // Header - DELIVERY ORDER (center, bold, uppercase)
                stream.write(CMD_ALIGN_CENTER)
                stream.write(CMD_BOLD_ON)
                stream.write(CMD_DOUBLE_HEIGHT_ON)
                writeLine(stream, "DELIVERY ORDER")
                stream.write(CMD_NORMAL_SIZE)
                stream.write(CMD_BOLD_OFF)
                stream.write(CMD_ALIGN_LEFT)
                stream.write(CMD_FEED_LINE)

                // DO and Ekspedisi
                writeLine(stream, "DO : ${labelData.doNumber}")
                writeLine(stream, "Ekspedisi : ${labelData.shippingService}")
                writeLine(stream, divider)
                stream.write(CMD_FEED_LINE)

                // PENGIRIM
                stream.write(CMD_BOLD_ON)
                writeLine(stream, "PENGIRIM")
                stream.write(CMD_BOLD_OFF)
                val senderLines = wrapText(labelData.senderName, widthChars)
                for (line in senderLines) {
                    writeLine(stream, line)
                }
                stream.write(CMD_FEED_LINE)

                // NO HANDPHONE
                stream.write(CMD_BOLD_ON)
                writeLine(stream, "NO HANDPHONE")
                stream.write(CMD_BOLD_OFF)
                writeLine(stream, labelData.senderPhone)
                writeLine(stream, divider)
                stream.write(CMD_FEED_LINE)

                // PENERIMA
                stream.write(CMD_BOLD_ON)
                writeLine(stream, "PENERIMA")
                stream.write(CMD_BOLD_OFF)
                val recipientLines = wrapText(labelData.recipientName, widthChars)
                for (line in recipientLines) {
                    writeLine(stream, line)
                }
                stream.write(CMD_FEED_LINE)

                // ALAMAT
                stream.write(CMD_BOLD_ON)
                writeLine(stream, "ALAMAT")
                stream.write(CMD_BOLD_OFF)
                val addressLines = wrapText(labelData.recipientAddress, widthChars)
                for (line in addressLines) {
                    writeLine(stream, line)
                }
                stream.write(CMD_FEED_LINE)

                // NO HANDPHONE
                stream.write(CMD_BOLD_ON)
                writeLine(stream, "NO HANDPHONE")
                stream.write(CMD_BOLD_OFF)
                writeLine(stream, labelData.recipientPhone)
                writeLine(stream, divider)
                stream.write(CMD_FEED_LINE)

                // SO, Tanggal Cetak, By
                writeLine(stream, "SO : ${labelData.soNumber}")
                val dateLines = wrapText("Tanggal Cetak : ${labelData.printDate}", widthChars)
                for (line in dateLines) {
                    writeLine(stream, line)
                }
                val byLines = wrapText("By : ${labelData.printedBy}", widthChars)
                for (line in byLines) {
                    writeLine(stream, line)
                }

                stream.write(CMD_FEED_LINE)
                stream.write(CMD_FEED_LINE)
                stream.write(CMD_FEED_LINE)
                stream.write(CMD_CUT)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Print DO error: ${e.message}", e)
            Result.failure(e)
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun sendBytesToPrinter(
        printerAddress: String,
        block: (OutputStream) -> Unit
    ) = withContext(Dispatchers.IO) {
        if (!hasBluetoothPermission()) {
            throw SecurityException("Izin Bluetooth belum diberikan")
        }
        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            throw IllegalStateException("Bluetooth belum aktif pada perangkat ini")
        }

        val device: BluetoothDevice = try {
            bluetoothAdapter!!.getRemoteDevice(printerAddress)
        } catch (e: Exception) {
            throw IllegalArgumentException("Alamat printer '$printerAddress' tidak valid: ${e.message}")
        }

        // Cancel discovery to conserve bandwidth & connection latency
        bluetoothAdapter?.cancelDiscovery()

        var socket: BluetoothSocket? = null
        try {
            Log.d(TAG, "Connecting to printer ${device.name} ($printerAddress)...")
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.connect()

            val outputStream = socket.outputStream
            block(outputStream)
            outputStream.flush()
            Log.d(TAG, "Data successfully sent to printer")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to connect to printer: ${e.message}", e)
            throw Exception(
                "Tidak dapat terhubung ke printer (${device.name ?: printerAddress}).\n" +
                "Periksa:\n" +
                "• Bluetooth aktif\n" +
                "• Printer menyala\n" +
                "• Printer sudah paired\n" +
                "• Jarak printer dekat"
            )
        } finally {
            try {
                socket?.close()
            } catch (ignored: Exception) {}
        }
    }
}
