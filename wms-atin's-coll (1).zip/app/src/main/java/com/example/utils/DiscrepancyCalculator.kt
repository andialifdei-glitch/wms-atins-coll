package com.example.utils

import java.text.NumberFormat
import java.util.Locale

/**
 * Result classification of stock discrepancy.
 */
enum class DiscrepancyResult(val label: String) {
    PLUS("PLUS"),
    MINUS("MINUS"),
    BALANCE("BALANCE")
}

/**
 * Item-level discrepancy evaluation.
 */
data class DiscrepancyItem(
    val sku: String,
    val itemName: String,
    val systemQty: Int,
    val actualQty: Int,
    val discrepancyQty: Int, // actualQty - systemQty
    val hpp: Long,
    val discrepancyValue: Long // discrepancyQty * hpp
)

/**
 * Summary discrepancy evaluation across multiple items.
 */
data class DiscrepancySummary(
    val totalPlusQty: Int,
    val totalMinusQty: Int, // positive magnitude of minus qty e.g. 18
    val netDiscrepancyQty: Int,
    val totalPlusValue: Long,
    val totalMinusValue: Long, // positive magnitude of minus value e.g. 425000
    val netDiscrepancyValue: Long, // signed sum of all discrepancy values
    val finalResult: DiscrepancyResult
)

object DiscrepancyCalculator {

    /**
     * Discrepancy Qty = Actual Qty - System Qty
     */
    fun calculateDiscrepancyQty(systemQty: Int, actualQty: Int): Int {
        return actualQty - systemQty
    }

    /**
     * Discrepancy Value = Discrepancy Qty * HPP (purchasing price)
     */
    fun calculateDiscrepancyValue(discrepancyQty: Int, hpp: Long): Long {
        return discrepancyQty.toLong() * hpp
    }

    /**
     * Evaluates item discrepancy.
     */
    fun calculateItem(
        sku: String,
        itemName: String,
        systemQty: Int,
        actualQty: Int,
        hpp: Long
    ): DiscrepancyItem {
        val diffQty = calculateDiscrepancyQty(systemQty, actualQty)
        val diffValue = calculateDiscrepancyValue(diffQty, hpp)
        return DiscrepancyItem(
            sku = sku,
            itemName = itemName,
            systemQty = systemQty,
            actualQty = actualQty,
            discrepancyQty = diffQty,
            hpp = hpp,
            discrepancyValue = diffValue
        )
    }

    /**
     * Calculates summary over a list of items using signed offset for net values.
     * Uses Net Discrepancy Value as the primary indicator for final result:
     * - Net Discrepancy Value > 0 -> PLUS
     * - Net Discrepancy Value < 0 -> MINUS
     * - Net Discrepancy Value == 0 -> BALANCE
     */
    fun calculateSummary(items: List<DiscrepancyItem>): DiscrepancySummary {
        var plusQty = 0
        var minusQty = 0
        var plusVal = 0L
        var minusVal = 0L
        var netVal = 0L
        var netQty = 0

        for (item in items) {
            netQty += item.discrepancyQty
            netVal += item.discrepancyValue

            if (item.discrepancyQty > 0) {
                plusQty += item.discrepancyQty
            } else if (item.discrepancyQty < 0) {
                minusQty += (-item.discrepancyQty)
            }

            if (item.discrepancyValue > 0) {
                plusVal += item.discrepancyValue
            } else if (item.discrepancyValue < 0) {
                minusVal += (-item.discrepancyValue)
            }
        }

        val result = when {
            netVal > 0 -> DiscrepancyResult.PLUS
            netVal < 0 -> DiscrepancyResult.MINUS
            else -> DiscrepancyResult.BALANCE
        }

        return DiscrepancySummary(
            totalPlusQty = plusQty,
            totalMinusQty = minusQty,
            netDiscrepancyQty = netQty,
            totalPlusValue = plusVal,
            totalMinusValue = minusVal,
            netDiscrepancyValue = netVal,
            finalResult = result
        )
    }

    /**
     * Indonesian Currency Formatting with correct signs:
     * +Rp50.000 / -Rp50.000 / Rp0
     */
    fun formatSignedCurrency(amount: Long): String {
        val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
        return when {
            amount > 0 -> "+${formatter.format(amount)}"
            amount < 0 -> "-${formatter.format(-amount)}"
            else -> formatter.format(0L)
        }
    }

    /**
     * Unsigned Currency Formatting: Rp10.000
     */
    fun formatCurrency(amount: Long): String {
        val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
        return formatter.format(amount)
    }

    /**
     * Formats signed quantity: +5 / -5 / 0
     */
    fun formatSignedQty(qty: Int): String {
        return when {
            qty > 0 -> "+$qty"
            else -> "$qty"
        }
    }
}
