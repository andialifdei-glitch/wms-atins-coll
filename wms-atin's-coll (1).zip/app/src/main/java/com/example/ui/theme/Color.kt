package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dusty Pink / Elegant Rose Palette
val DustyPinkPrimary = Color(0xFFB34B68)
val DustyPinkDark = Color(0xFF8E324C)
val DustyPinkLight = Color(0xFFD6738F)
val DustyPinkContainer = Color(0xFFFFD9E2)
val OnDustyPinkContainer = Color(0xFF3E001D)

val SoftSecondary = Color(0xFF75565F)
val SecondaryContainer = Color(0xFFFFD9E2)
val SoftGrayBg = Color(0xFFF9F7F8)
val CardSurface = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1E1A1B)
val TextMuted = Color(0xFF6B6567)
val BorderLight = Color(0xFFE9E0E2)

// Status Colors
val StatusSuccessGreen = Color(0xFF2E7D32)
val StatusWarningOrange = Color(0xFFE65100)
val StatusDangerRed = Color(0xFFC62828)
val StatusBlue = Color(0xFF1565C0)
val StatusPurple = Color(0xFF6A1B9A)
