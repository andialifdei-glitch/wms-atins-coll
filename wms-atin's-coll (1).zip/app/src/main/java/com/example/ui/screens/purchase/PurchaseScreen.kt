package com.example.ui.screens.purchase

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.models.PoItem
import com.example.data.models.Product
import com.example.data.models.PurchaseOrder
import com.example.data.models.ReceivingItem
import com.example.ui.WmsViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingDialog
import com.example.ui.components.SearchBarField
import com.example.ui.components.WmsTopBar
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchaseScreen(
    viewModel: WmsViewModel,
    onNavigateBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Purchase Order, 1 = Receiving
    val purchaseOrders by viewModel.purchaseOrders.collectAsState()
    val receivings by viewModel.receivings.collectAsState()
    val products by viewModel.products.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    var showCreatePoDialog by remember { mutableStateOf(false) }
    var selectedPoForDetail by remember { mutableStateOf<PurchaseOrder?>(null) }
    var selectedPoForReceiving by remember { mutableStateOf<PurchaseOrder?>(null) }

    if (isLoading) {
        LoadingDialog("Memproses Purchase Order...")
    }

    // Sub-view: PO Detail
    if (selectedPoForDetail != null) {
        PurchaseOrderDetailView(
            po = selectedPoForDetail!!,
            viewModel = viewModel,
            onBack = { selectedPoForDetail = null },
            onStartReceiving = {
                val currentPo = selectedPoForDetail!!
                selectedPoForDetail = null
                selectedPoForReceiving = currentPo
                selectedTab = 1
            }
        )
        return
    }

    // Modal: Buat PO Baru
    if (showCreatePoDialog) {
        CreatePoDialog(
            viewModel = viewModel,
            products = products,
            onDismiss = { showCreatePoDialog = false }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Purchase & Receiving",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isOnline = isOnline
            )
        },
        floatingActionButton = {
            if (selectedTab == 0) {
                FloatingActionButton(
                    onClick = { showCreatePoDialog = true },
                    containerColor = DustyPinkPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_create_po")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Buat Purchase Order")
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = DustyPinkPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Purchase Order (${purchaseOrders.size})") },
                    modifier = Modifier.testTag("tab_po")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Receiving Barang") },
                    modifier = Modifier.testTag("tab_receiving")
                )
            }

            if (selectedTab == 0) {
                PurchaseOrderListView(
                    purchaseOrders = purchaseOrders,
                    onPoClick = { selectedPoForDetail = it },
                    onCreatePo = { showCreatePoDialog = true }
                )
            } else {
                ReceivingFlowView(
                    viewModel = viewModel,
                    purchaseOrders = purchaseOrders,
                    preSelectedPo = selectedPoForReceiving,
                    onClearPreselectedPo = { selectedPoForReceiving = null }
                )
            }
        }
    }
}

// -------------------------------------------------------------
// PO LIST VIEW
// -------------------------------------------------------------
@Composable
fun PurchaseOrderListView(
    purchaseOrders: List<PurchaseOrder>,
    onPoClick: (PurchaseOrder) -> Unit,
    onCreatePo: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    val filtered = purchaseOrders.filter {
        it.poId.contains(searchQuery, ignoreCase = true) ||
        it.supplier.contains(searchQuery, ignoreCase = true) ||
        it.status.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.padding(16.dp)) {
            SearchBarField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Cari nomor PO, Supplier...",
                testTag = "po_search_bar"
            )
        }

        if (filtered.isEmpty()) {
            EmptyStateView(
                title = if (searchQuery.isEmpty()) "Belum ada Purchase Order" else "PO tidak ditemukan",
                description = "Purchase Order digunakan sebagai dasar untuk penerimaan (receiving) barang dari supplier.",
                actionButtonText = "+ Buat PO Baru",
                onActionClick = onCreatePo
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filtered, key = { it.poId }) { po ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPoClick(po) }
                            .testTag("po_card_${po.poId}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = po.poId,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = DustyPinkPrimary
                                )
                                Surface(
                                    color = when (po.status) {
                                        "COMPLETED" -> StatusSuccessGreen.copy(alpha = 0.15f)
                                        "PARTIAL" -> StatusWarningOrange.copy(alpha = 0.15f)
                                        "CANCELLED" -> StatusDangerRed.copy(alpha = 0.15f)
                                        else -> StatusBlue.copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = po.status,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = when (po.status) {
                                            "COMPLETED" -> StatusSuccessGreen
                                            "PARTIAL" -> StatusWarningOrange
                                            "CANCELLED" -> StatusDangerRed
                                            else -> StatusBlue
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Supplier: ${po.supplier}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )

                            Text(
                                text = "${po.items.size} item (${po.items.sumOf { it.qty }} pcs) • Tgl: ${po.poDate}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Dibuat oleh: ${po.createdBy}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                                Text(
                                    text = rupiahFormat.format(po.total),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// PO DETAIL VIEW & PDF
// -------------------------------------------------------------
@Composable
fun PurchaseOrderDetailView(
    po: PurchaseOrder,
    viewModel: WmsViewModel,
    onBack: () -> Unit,
    onStartReceiving: () -> Unit
) {
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    val scrollState = rememberScrollState()
    var showCancelPoDialog by remember { mutableStateOf(false) }

    androidx.activity.compose.BackHandler(onBack = onBack)

    if (showCancelPoDialog) {
        AlertDialog(
            onDismissRequest = { showCancelPoDialog = false },
            title = { Text("Batalkan Purchase Order?", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Nomor PO: ${po.poId}", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Status PO akan diubah menjadi CANCELED dan disimpan di database sebagai dokumen historis. PO yang dibatalkan tidak dapat diproses receiving.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCancelPoDialog = false
                        viewModel.cancelPurchaseOrder(po.poId)
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                    modifier = Modifier.testTag("confirm_cancel_po_button")
                ) {
                    Text("Batalkan PO")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelPoDialog = false }) {
                    Text("Kembali")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Detail ${po.poId}",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Informasi Supplier",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            color = when (po.status) {
                                "COMPLETED" -> StatusSuccessGreen.copy(alpha = 0.15f)
                                "PARTIAL" -> StatusWarningOrange.copy(alpha = 0.15f)
                                "CANCELLED" -> StatusDangerRed.copy(alpha = 0.15f)
                                else -> StatusBlue.copy(alpha = 0.15f)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = po.status,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = when (po.status) {
                                    "COMPLETED" -> StatusSuccessGreen
                                    "PARTIAL" -> StatusWarningOrange
                                    "CANCELLED" -> StatusDangerRed
                                    else -> StatusBlue
                                },
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Supplier: ${po.supplier}", style = MaterialTheme.typography.bodyMedium)
                    if (po.supplierAddress.isNotBlank()) {
                        Text(text = "Alamat: ${po.supplierAddress}", style = MaterialTheme.typography.bodyMedium)
                    }
                    if (po.supplierPhone.isNotBlank()) {
                        Text(text = "Telepon: ${po.supplierPhone}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Text(text = "Tanggal PO: ${po.poDate}", style = MaterialTheme.typography.bodyMedium)
                    if (po.notes.isNotBlank()) {
                        Text(text = "Catatan: ${po.notes}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Daftar Barang yang Dipesan",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    po.items.forEachIndexed { index, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = item.itemName, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${item.sku} • Pesan: ${item.qty} pcs • Diterima: ${item.receivedQty} pcs",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (item.receivedQty >= item.qty) StatusSuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "@ ${rupiahFormat.format(item.purchasingPrice)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                            Text(
                                text = rupiahFormat.format(item.subtotal),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        if (index < po.items.size - 1) {
                            HorizontalDivider(color = BorderLight)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = BorderLight)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "TOTAL PURCHASE ORDER", fontWeight = FontWeight.Bold)
                        Text(
                            text = rupiahFormat.format(po.total),
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = DustyPinkPrimary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action: Generate PDF per Section 27
            Button(
                onClick = { viewModel.generatePoPdfAndShare(po) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("po_generate_pdf_button")
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("GENERATE & SHARE PDF (A4)")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action: Receiving button if not completed/cancelled
            if (po.status != "COMPLETED" && po.status != "CANCELLED") {
                Button(
                    onClick = onStartReceiving,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("po_start_receiving_button")
                ) {
                    Icon(Icons.Default.MoveToInbox, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PROSES RECEIVING BARANG INI")
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = { showCancelPoDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDangerRed),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("cancel_po_button")
                ) {
                    Icon(Icons.Default.Cancel, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("BATALKAN PO (CANCEL PO)")
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

// -------------------------------------------------------------
// RECEIVING FLOW VIEW (STRICTLY PO-BASED)
// -------------------------------------------------------------
@Composable
fun ReceivingFlowView(
    viewModel: WmsViewModel,
    purchaseOrders: List<PurchaseOrder>,
    preSelectedPo: PurchaseOrder?,
    onClearPreselectedPo: () -> Unit
) {
    var selectedPoId by remember { mutableStateOf(preSelectedPo?.poId ?: "") }
    var receivingNotes by remember { mutableStateOf("") }
    val receivedQuantities = remember { mutableStateMapOf<String, Int>() }
    var showConfirmReceivingDialog by remember { mutableStateOf(false) }
    var receivingCountdown by remember { mutableIntStateOf(10) }
    var pendingReceivingItems by remember { mutableStateOf<List<ReceivingItem>>(emptyList()) }
    val products by viewModel.products.collectAsStateWithLifecycle()

    val activePos = purchaseOrders.filter { it.status == "CONFIRMED" || it.status == "PARTIAL" }
    val currentPo = purchaseOrders.find { it.poId == selectedPoId }

    val scrollState = rememberScrollState()

    LaunchedEffect(showConfirmReceivingDialog) {
        if (showConfirmReceivingDialog) {
            receivingCountdown = 10
            while (receivingCountdown > 0) {
                kotlinx.coroutines.delay(1000)
                receivingCountdown--
            }
        }
    }

    if (showConfirmReceivingDialog && currentPo != null) {
        AlertDialog(
            onDismissRequest = { showConfirmReceivingDialog = false },
            title = {
                Text("Apakah hasil receiving sudah sesuai?", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("Nomor PO: ${currentPo.poId}", fontWeight = FontWeight.SemiBold)
                    Text("Supplier: ${currentPo.supplier}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Daftar item PO yang diterima:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    pendingReceivingItems.forEachIndexed { idx, itm ->
                        Text(
                            text = "${idx + 1}. ${itm.itemName} — ${itm.qtyReceived} pcs",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showConfirmReceivingDialog = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Batal")
                    }
                    Button(
                        onClick = {
                            showConfirmReceivingDialog = false
                            viewModel.processReceiving(currentPo.poId, pendingReceivingItems, receivingNotes) { success ->
                                if (success) {
                                    selectedPoId = ""
                                    receivingNotes = ""
                                    onClearPreselectedPo()
                                }
                            }
                        },
                        enabled = receivingCountdown == 0,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("confirm_posting_receiving_button")
                    ) {
                        Text(if (receivingCountdown > 0) "Posting ($receivingCountdown)" else "Posting")
                    }
                }
            },
            dismissButton = null
        )
    }

    // Initialize quantities when PO changes
    LaunchedEffect(currentPo) {
        receivedQuantities.clear()
        currentPo?.items?.forEach { item ->
            val remaining = (item.qty - item.receivedQty).coerceAtLeast(0)
            receivedQuantities[item.sku] = remaining
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "Receiving Barang (Wajib Berdasarkan PO)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Barang yang diterima akan menambah stok fisik produk dan dicatat dalam audit mutasi stok.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Step 1: Select PO
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "1. Pilih Purchase Order", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(8.dp))

                if (activePos.isEmpty()) {
                    Text(
                        text = "Tidak ada Purchase Order yang aktif atau menunggu receiving. Buat PO terlebih dahulu.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusDangerRed
                    )
                } else {
                    activePos.forEach { po ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedPoId = po.poId
                                    onClearPreselectedPo()
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedPoId == po.poId,
                                onClick = {
                                    selectedPoId = po.poId
                                    onClearPreselectedPo()
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(text = "${po.poId} • ${po.supplier}", fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Status: ${po.status} • Total ${po.items.size} item (${po.poDate})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Step 2: Input Received Items
        if (currentPo != null) {
            Text(
                text = "2. Input Jumlah Barang Diterima",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    currentPo.items.forEachIndexed { index, item ->
                        val currentReceived = receivedQuantities[item.sku] ?: 0

                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    val prodWeight = products.find { it.sku == item.sku }?.weightInGrams ?: item.weightInGrams
                                    Text(text = item.itemName, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${item.sku} • Berat: ${if (prodWeight > 0) "$prodWeight g/pcs" else "Belum diset"} • Pesan: ${item.qty} pcs (Sudah datang: ${item.receivedQty} pcs)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Qty Diterima Saat Ini:", style = MaterialTheme.typography.bodySmall)
                                OutlinedTextField(
                                    value = currentReceived.toString(),
                                    onValueChange = { input ->
                                        val digits = input.filter { it.isDigit() }
                                        receivedQuantities[item.sku] = digits.toIntOrNull() ?: 0
                                    },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .width(100.dp)
                                        .testTag("receiving_qty_input_${item.sku}")
                                )
                                Text("pcs", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (index < currentPo.items.size - 1) {
                            HorizontalDivider(color = BorderLight)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = receivingNotes,
                onValueChange = { receivingNotes = it },
                label = { Text("Catatan Penerimaan / No Surat Jalan Supplier (opsional)") },
                singleLine = false,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    val receivingItems = currentPo.items.map { item ->
                        val qtyRecv = receivedQuantities[item.sku] ?: 0
                        val prodWeight = products.find { it.sku == item.sku }?.weightInGrams ?: item.weightInGrams
                        ReceivingItem(
                            sku = item.sku,
                            itemName = item.itemName,
                            qtyReceived = qtyRecv,
                            purchasingPrice = item.purchasingPrice,
                            weightInGrams = prodWeight
                        )
                    }.filter { it.qtyReceived > 0 }

                    if (receivingItems.isEmpty()) {
                        viewModel.showMessage("Harap isi jumlah barang yang diterima (minimal 1 item > 0)")
                        return@Button
                    }

                    pendingReceivingItems = receivingItems
                    showConfirmReceivingDialog = true
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("submit_receiving_button")
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("KONFIRMASI RECEIVING (TAMBAH STOK)")
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// -------------------------------------------------------------
// CREATE PO DIALOG
// -------------------------------------------------------------
@Composable
fun CreatePoDialog(
    viewModel: WmsViewModel,
    products: List<Product>,
    onDismiss: () -> Unit
) {
    var supplierName by remember { mutableStateOf("") }
    var supplierAddress by remember { mutableStateOf("") }
    var supplierPhone by remember { mutableStateOf("") }
    var poNotes by remember { mutableStateOf("") }
    var productSearch by remember { mutableStateOf("") }
    var isPickerOpen by remember { mutableStateOf(false) }

    val poItems = remember { mutableStateListOf<PoItem>() }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Buat Purchase Order Baru", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                Text(
                    text = "PO ID otomatis dibuat secara atomic (PO-YYYYMMDD-XXXXX).",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = supplierName,
                    onValueChange = {
                        supplierName = it
                        errorMsg = null
                    },
                    label = { Text("Nama Supplier *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = supplierPhone,
                    onValueChange = { supplierPhone = it },
                    label = { Text("Nomor Telepon Supplier") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = supplierAddress,
                    onValueChange = { supplierAddress = it },
                    label = { Text("Alamat Supplier") },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = poNotes,
                    onValueChange = { poNotes = it },
                    label = { Text("Catatan PO (opsional)") },
                    singleLine = false,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Items Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Daftar Item PO:", fontWeight = FontWeight.Bold)
                    TextButton(onClick = { isPickerOpen = !isPickerOpen }) {
                        Text(if (isPickerOpen) "Tutup" else "+ Pilih Produk")
                    }
                }

                if (isPickerOpen) {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            SearchBarField(
                                query = productSearch,
                                onQueryChange = { productSearch = it },
                                placeholder = "Cari SKU / nama produk..."
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            products.filter {
                                it.sku.contains(productSearch, ignoreCase = true) ||
                                it.itemName.contains(productSearch, ignoreCase = true)
                            }.take(5).forEach { prod ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val existing = poItems.find { it.sku == prod.sku }
                                            if (existing == null) {
                                                poItems.add(
                                                    PoItem(
                                                        sku = prod.sku,
                                                        itemName = prod.itemName,
                                                        qty = 10,
                                                        purchasingPrice = prod.purchasingPrice,
                                                        subtotal = 10 * prod.purchasingPrice,
                                                        receivedQty = 0,
                                                        weightInGrams = prod.weightInGrams
                                                    )
                                                )
                                            }
                                        }
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = prod.itemName, fontWeight = FontWeight.SemiBold)
                                    Text(text = rupiahFormat.format(prod.purchasingPrice), color = DustyPinkPrimary)
                                }
                                HorizontalDivider(color = BorderLight)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                poItems.forEachIndexed { idx, itm ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = itm.itemName, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "${itm.sku} • Qty: ${itm.qty} @ ${rupiahFormat.format(itm.purchasingPrice)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        IconButton(onClick = { poItems.removeAt(idx) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = StatusDangerRed)
                        }
                    }
                }

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMsg!!, color = StatusDangerRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (supplierName.trim().isBlank()) {
                        errorMsg = "Nama supplier wajib diisi"
                        return@Button
                    }
                    if (poItems.isEmpty()) {
                        errorMsg = "Pilih minimal satu produk untuk dipesan"
                        return@Button
                    }

                    viewModel.createPurchaseOrder(
                        supplier = supplierName,
                        supplierAddress = supplierAddress,
                        supplierPhone = supplierPhone,
                        notes = poNotes,
                        items = poItems.toList()
                    ) { po ->
                        if (po != null) onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
            ) {
                Text("Simpan PO")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}
