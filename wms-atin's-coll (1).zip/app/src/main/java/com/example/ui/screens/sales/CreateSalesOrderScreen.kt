package com.example.ui.screens.sales

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.models.Customer
import com.example.data.models.Product
import com.example.data.models.ShippingRate
import com.example.data.models.SoItem
import com.example.ui.WmsViewModel
import com.example.ui.components.SearchBarField
import com.example.ui.components.WmsTopBar
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.example.ui.theme.BorderLight
import com.example.ui.theme.DustyPinkPrimary
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusSuccessGreen
import com.example.ui.theme.TextMuted
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateSalesOrderScreen(
    viewModel: WmsViewModel,
    onBack: () -> Unit,
    onSuccess: () -> Unit
) {
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val shippingServices by viewModel.shippingServices.collectAsStateWithLifecycle()
    val shippingRates by viewModel.shippingRates.collectAsStateWithLifecycle()
    val isCalculatingShipping by viewModel.isCalculatingShipping.collectAsStateWithLifecycle()
    val shippingError by viewModel.shippingError.collectAsStateWithLifecycle()
    val storeSettings by viewModel.storeSettings.collectAsStateWithLifecycle()

    var customerSearch by remember { mutableStateOf("") }
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var showCustomerDropdown by remember { mutableStateOf(false) }

    var recipientName by remember { mutableStateOf("") }
    var recipientPhone by remember { mutableStateOf("") }
    var recipientAddress by remember { mutableStateOf("") }
    var selectedExpedition by remember { mutableStateOf("") }
    var expeditionSearch by remember { mutableStateOf("") }
    var showExpeditionDropdown by remember { mutableStateOf(false) }

    var selectedShippingRate by remember { mutableStateOf<ShippingRate?>(null) }
    var shippingCost by remember { mutableLongStateOf(0L) }

    // Payment Method & Kurir Toko manual cost state
    var selectedPaymentMethod by remember { mutableStateOf("NON-COD") } // "NON-COD" or "COD"
    var kurirTokoCostInput by remember { mutableStateOf("") }
    var kurirTokoCostError by remember { mutableStateOf<String?>(null) }

    var productSearch by remember { mutableStateOf("") }
    var showProductSearch by remember { mutableStateOf(false) }

    val orderItems = remember { mutableStateListOf<SoItem>() }
    val totalWeightInGrams by remember {
        derivedStateOf { orderItems.sumOf { it.qty * it.weightInGrams } }
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var itemIndexToEditPrice by remember { mutableStateOf<Int?>(null) }
    var editPriceInput by remember { mutableStateOf("") }

    // Section 15: Invalidasi Hasil Ongkir
    // Jika customer berubah, destination/alamat berubah, product berubah, quantity berubah, atau total weight berubah,
    // maka tarif sebelumnya tidak valid dan di-reset kembali ke '-'
    var lastCheckedDest by remember { mutableStateOf("") }
    var lastCheckedWeight by remember { mutableIntStateOf(0) }
    var lastCheckedAddress by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        viewModel.clearShippingRates()
        onDispose {
            viewModel.clearShippingRates()
        }
    }

    val currentDestKey = if (selectedCustomer != null) {
        "${selectedCustomer!!.districtName}, ${selectedCustomer!!.regencyName}, ${selectedCustomer!!.provinceName}".trim()
    } else {
        recipientAddress.trim()
    }

    LaunchedEffect(currentDestKey, recipientAddress, totalWeightInGrams, orderItems.size) {
        if (shippingRates.isNotEmpty() && (currentDestKey != lastCheckedDest || recipientAddress != lastCheckedAddress || totalWeightInGrams != lastCheckedWeight)) {
            viewModel.clearShippingRates()
            if (selectedShippingRate?.courier != "toko") {
                selectedShippingRate = null
                shippingCost = 0L
                if (selectedExpedition != "None") {
                    selectedExpedition = ""
                }
            }
        }
    }

    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    val scrollState = rememberScrollState()

    // Dialog Edit Harga Satuan SO (Section A1)
    if (itemIndexToEditPrice != null && itemIndexToEditPrice!! in orderItems.indices) {
        val targetItem = orderItems[itemIndexToEditPrice!!]
        AlertDialog(
            onDismissRequest = { itemIndexToEditPrice = null },
            title = { Text("Ubah Harga Barang Khusus SO", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(text = targetItem.itemName, fontWeight = FontWeight.SemiBold)
                    Text(text = "SKU: ${targetItem.sku}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Harga khusus ini hanya berlaku pada Sales Order ini (tidak mengubah harga Master Product).",
                        style = MaterialTheme.typography.labelSmall,
                        color = DustyPinkPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editPriceInput,
                        onValueChange = { editPriceInput = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Harga Satuan SO (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("so_custom_price_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newPrice = editPriceInput.toLongOrNull()
                        if (newPrice != null && newPrice >= 0L) {
                            val idx = itemIndexToEditPrice!!
                            val cur = orderItems[idx]
                            orderItems[idx] = cur.copy(
                                price = newPrice,
                                subtotal = cur.qty * newPrice
                            )
                            itemIndexToEditPrice = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
                ) {
                    Text("Terapkan Harga")
                }
            },
            dismissButton = {
                TextButton(onClick = { itemIndexToEditPrice = null }) {
                    Text("Batal")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Buat Sales Order Baru",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .imePadding()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            if (errorMessage != null) {
                Surface(
                    color = Color(0xFFFFEBEE),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(12.dp)) {
                        Icon(imageVector = Icons.Default.ErrorOutline, contentDescription = null, tint = StatusDangerRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = errorMessage!!, color = StatusDangerRed, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Customer Section
            Text(
                text = "1. Pilih / Cari Customer",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(8.dp))

            SearchBarField(
                query = customerSearch,
                onQueryChange = {
                    customerSearch = it
                    showCustomerDropdown = it.isNotEmpty()
                },
                placeholder = "Ketik nama customer...",
                testTag = "so_customer_search"
            )

            if (showCustomerDropdown && customerSearch.isNotEmpty()) {
                val matchedCustomers = customers.filter {
                    it.customerName.contains(customerSearch, ignoreCase = true) ||
                    it.phone.contains(customerSearch)
                }
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        if (matchedCustomers.isEmpty()) {
                            Text(
                                text = "Customer tidak ditemukan. Anda dapat mengisi form di bawah secara manual.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(8.dp)
                            )
                        } else {
                            matchedCustomers.take(5).forEach { cust ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedCustomer = cust
                                            recipientName = cust.customerName
                                            recipientPhone = cust.phone
                                            recipientAddress = cust.displayAddress.ifBlank { cust.fullAddress }
                                            customerSearch = cust.customerName
                                            showCustomerDropdown = false
                                            viewModel.clearShippingRates()
                                            selectedShippingRate = null
                                            shippingCost = 0L
                                            if (selectedExpedition != "None") {
                                                selectedExpedition = ""
                                            }
                                        }
                                        .padding(10.dp)
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = DustyPinkPrimary)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(text = cust.customerName, fontWeight = FontWeight.SemiBold)
                                        Text(text = "${cust.phone} • ${cust.fullAddress}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = recipientName,
                onValueChange = { recipientName = it },
                label = { Text("Nama Customer / Penerima *") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("so_recipient_name_field")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = recipientPhone,
                onValueChange = { recipientPhone = it },
                label = { Text("Nomor Telepon / WA *") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("so_recipient_phone_field")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = recipientAddress,
                onValueChange = {
                    recipientAddress = it
                    if (shippingRates.isNotEmpty()) {
                        viewModel.clearShippingRates()
                        selectedShippingRate = null
                        shippingCost = 0L
                        if (selectedExpedition != "None") {
                            selectedExpedition = ""
                        }
                    }
                },
                label = { Text("Alamat Lengkap Pengiriman *") },
                singleLine = false,
                minLines = 2,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("so_recipient_address_field")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Expedition & RajaOngkir Shipping Cost Section
            Text(
                text = "2. Pilih Jasa Kirim & Cek Ongkir (RajaOngkir)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    val destDisplay = if (selectedCustomer != null) {
                        if (selectedCustomer!!.districtName.isNotBlank() && selectedCustomer!!.regencyName.isNotBlank()) {
                            "Kec. ${selectedCustomer!!.districtName}, ${selectedCustomer!!.regencyName}, ${selectedCustomer!!.provinceName}".trim()
                        } else {
                            selectedCustomer!!.displayAddress.ifBlank { selectedCustomer!!.fullAddress }
                        }
                    } else {
                        recipientAddress
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            val storeOrigin = storeSettings.getShippingOriginName()
                            val isStoreAddressComplete = storeSettings.isRegionAddressComplete()
                            Text(
                                text = "Asal (Toko): $storeOrigin",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isStoreAddressComplete) TextMuted else StatusDangerRed
                            )
                            if (!isStoreAddressComplete) {
                                Text(
                                    text = "⚠️ Alamat toko belum lengkap di Pengaturan",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusDangerRed
                                )
                            }
                            Text(
                                text = "Tujuan: ${destDisplay.ifBlank { "Belum dipilih" }}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "Total Berat: $totalWeightInGrams gram",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = DustyPinkPrimary
                            )
                        }

                        Button(
                            onClick = {
                                if (!storeSettings.isRegionAddressComplete() && storeSettings.districtName.isBlank()) {
                                    errorMessage = "Alamat toko belum lengkap. Silakan lengkapi alamat toko pada Pengaturan & Printer."
                                    return@Button
                                }
                                val destQuery: String
                                if (selectedCustomer != null) {
                                    if (selectedCustomer!!.districtName.isBlank() || selectedCustomer!!.regencyName.isBlank()) {
                                        errorMessage = "Alamat wilayah customer belum lengkap. Silakan lengkapi alamat customer."
                                        return@Button
                                    }
                                    destQuery = "${selectedCustomer!!.districtName}, ${selectedCustomer!!.regencyName}, ${selectedCustomer!!.provinceName}".trim()
                                } else {
                                    if (recipientAddress.isBlank()) {
                                        errorMessage = "Pilih Customer atau isi Alamat Lengkap Pengiriman terlebih dahulu"
                                        return@Button
                                    }
                                    destQuery = recipientAddress.trim()
                                }
                                if (totalWeightInGrams <= 0) {
                                    errorMessage = "Tambahkan minimal 1 produk agar berat > 0 gram"
                                    return@Button
                                }
                                errorMessage = null
                                lastCheckedDest = destQuery
                                lastCheckedWeight = totalWeightInGrams
                                lastCheckedAddress = recipientAddress.trim()
                                viewModel.calculateShippingRates(
                                    origin = storeSettings.getShippingOriginName(),
                                    destination = destQuery,
                                    weightInGrams = totalWeightInGrams
                                )
                            },
                            enabled = !isCalculatingShipping,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                            modifier = Modifier.testTag("check_shipping_cost_btn")
                        ) {
                            if (isCalculatingShipping) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Mengecek ongkir...", fontSize = 12.sp)
                            } else {
                                Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Cek Ongkir", fontSize = 12.sp)
                            }
                        }
                    }

                    if (isCalculatingShipping) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = DustyPinkPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Menghitung ongkir...",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = DustyPinkPrimary
                            )
                        }
                    }

                    if (shippingError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = shippingError!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = StatusDangerRed
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = BorderLight)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Metode Pembayaran (COD / Non-COD)
                    Text(
                        text = "Metode Pembayaran:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = selectedPaymentMethod == "NON-COD",
                            onClick = {
                                selectedPaymentMethod = "NON-COD"
                                // If SPX Reguler (COD) was selected, deselect it because it is only for COD
                                if (selectedShippingRate?.serviceName == "SPX Reguler (COD)") {
                                    selectedShippingRate = null
                                    shippingCost = 0L
                                    selectedExpedition = ""
                                }
                            },
                            label = { Text("Transfer / Non-COD") },
                            leadingIcon = {
                                if (selectedPaymentMethod == "NON-COD") {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DustyPinkPrimary.copy(alpha = 0.15f),
                                selectedLabelColor = DustyPinkPrimary
                            ),
                            modifier = Modifier.testTag("payment_method_non_cod")
                        )

                        FilterChip(
                            selected = selectedPaymentMethod == "COD",
                            onClick = {
                                selectedPaymentMethod = "COD"
                            },
                            label = { Text("COD (Bayar di Tempat)") },
                            leadingIcon = {
                                if (selectedPaymentMethod == "COD") {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DustyPinkPrimary.copy(alpha = 0.15f),
                                selectedLabelColor = DustyPinkPrimary
                            ),
                            modifier = Modifier.testTag("payment_method_cod")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Pilihan Layanan Pengiriman Resmi:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Pilihan Pengiriman RajaOngkir
                    val allowedCourierTemplates = listOf(
                        Triple("wahana", "Wahana Ekonomis", "wahana"),
                        Triple("spx", "SPX Hemat", "spx_hemat"),
                        Triple("lion", "Lion Parcel JagoPack", "lion"),
                        Triple("spx", "SPX Reguler (COD)", "spx_reguler_cod")
                    )

                    allowedCourierTemplates.forEach { (courierCode, displayName, tag) ->
                        val isCodService = displayName.contains("COD", ignoreCase = true)
                        val isCodAllowed = selectedPaymentMethod == "COD"
                        val isLockedDueToCod = isCodService && !isCodAllowed

                        val matchedRate = shippingRates.find {
                            it.serviceName.equals(displayName, ignoreCase = true) ||
                            (it.courier.equals(courierCode, ignoreCase = true) && it.serviceName.contains(displayName, ignoreCase = true))
                        }

                        val isSelected = selectedShippingRate?.serviceName == displayName && selectedShippingRate?.courier == courierCode
                        val hasActualResult = matchedRate != null
                        val isAvailable = matchedRate?.isAvailable == true && !isLockedDueToCod

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = when {
                                isSelected -> DustyPinkPrimary.copy(alpha = 0.12f)
                                isLockedDueToCod -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                else -> MaterialTheme.colorScheme.surface
                            },
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) DustyPinkPrimary else BorderLight
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable(enabled = hasActualResult && isAvailable) {
                                    if (matchedRate != null && isAvailable) {
                                        selectedShippingRate = matchedRate.copy(serviceName = displayName)
                                        shippingCost = matchedRate.cost
                                        selectedExpedition = "$displayName (${courierCode.uppercase()})"
                                        kurirTokoCostError = null
                                    }
                                }
                                .testTag("shipping_service_$tag")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = {
                                            if (matchedRate != null && isAvailable) {
                                                selectedShippingRate = matchedRate.copy(serviceName = displayName)
                                                shippingCost = matchedRate.cost
                                                selectedExpedition = "$displayName (${courierCode.uppercase()})"
                                                kurirTokoCostError = null
                                            }
                                        },
                                        enabled = hasActualResult && isAvailable,
                                        colors = RadioButtonDefaults.colors(selectedColor = DustyPinkPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = displayName,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isLockedDueToCod) TextMuted else MaterialTheme.colorScheme.onSurface
                                                )
                                            )
                                            if (isCodService) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    color = if (isCodAllowed) StatusSuccessGreen.copy(alpha = 0.15f) else TextMuted.copy(alpha = 0.15f),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "KHUSUS COD",
                                                        style = MaterialTheme.typography.labelSmall.copy(
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold
                                                        ),
                                                        color = if (isCodAllowed) StatusSuccessGreen else TextMuted,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }

                                        if (isLockedDueToCod) {
                                            Text(
                                                text = "Hanya tersedia untuk metode pembayaran COD.",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = TextMuted
                                            )
                                        } else if (hasActualResult) {
                                            if (matchedRate!!.isAvailable) {
                                                Text(
                                                    text = "Estimasi: ${matchedRate.etd}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = TextMuted
                                                )
                                            } else {
                                                Text(
                                                    text = "Layanan tidak tersedia",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = StatusDangerRed
                                                )
                                            }
                                        } else {
                                            Text(
                                                text = "Klik 'Cek Ongkir' untuk memeriksa tarif.",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = TextMuted
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = when {
                                        isLockedDueToCod -> "-"
                                        hasActualResult && matchedRate!!.isAvailable -> rupiahFormat.format(matchedRate.cost)
                                        hasActualResult && !matchedRate!!.isAvailable -> "Layanan tidak tersedia"
                                        else -> "-"
                                    },
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = if (hasActualResult && !matchedRate!!.isAvailable && !isLockedDueToCod) 11.sp else 14.sp,
                                        color = when {
                                            isLockedDueToCod -> TextMuted
                                            hasActualResult && matchedRate!!.isAvailable && isSelected -> DustyPinkPrimary
                                            hasActualResult && matchedRate!!.isAvailable -> MaterialTheme.colorScheme.onSurface
                                            hasActualResult && !matchedRate!!.isAvailable -> StatusDangerRed
                                            else -> TextMuted
                                        }
                                    )
                                )
                            }
                        }
                    }

                    // 5. Kurir Toko (Pengiriman lokal/jarak dekat tanpa RajaOngkir API)
                    val isKurirTokoSelected = selectedShippingRate?.courier == "toko"
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isKurirTokoSelected) DustyPinkPrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            1.dp,
                            if (isKurirTokoSelected) DustyPinkPrimary else BorderLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("shipping_service_kurir_toko")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    RadioButton(
                                        selected = isKurirTokoSelected,
                                        onClick = {
                                            val manualCost = kurirTokoCostInput.filter { it.isDigit() }.toLongOrNull()
                                            if (manualCost == null || manualCost <= 0L) {
                                                kurirTokoCostError = "Masukkan biaya ongkir Kurir Toko (> Rp 0)"
                                            } else {
                                                kurirTokoCostError = null
                                            }
                                            selectedShippingRate = ShippingRate(
                                                courier = "toko",
                                                serviceCode = "KURIR_TOKO",
                                                serviceName = "Kurir Toko",
                                                cost = manualCost ?: 0L,
                                                etd = "Hari ini / Esok",
                                                isAvailable = true,
                                                message = "Pengiriman Lokal oleh Toko"
                                            )
                                            shippingCost = manualCost ?: 0L
                                            selectedExpedition = "Kurir Toko"
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = DustyPinkPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text(
                                            text = "Kurir Toko (Lokal / Jarak Dekat)",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "Tanpa API RajaOngkir • Input tarif manual oleh pengguna",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextMuted
                                        )
                                    }
                                }

                                Text(
                                    text = if (isKurirTokoSelected && shippingCost > 0L) rupiahFormat.format(shippingCost) else "-",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isKurirTokoSelected && shippingCost > 0L) DustyPinkPrimary else TextMuted
                                    )
                                )
                            }

                            if (isKurirTokoSelected) {
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = kurirTokoCostInput,
                                    onValueChange = { input ->
                                        val clean = input.filter { it.isDigit() }
                                        kurirTokoCostInput = clean
                                        val costVal = clean.toLongOrNull() ?: 0L
                                        if (costVal > 0L) {
                                            kurirTokoCostError = null
                                            shippingCost = costVal
                                            selectedShippingRate = selectedShippingRate?.copy(cost = costVal)
                                        } else {
                                            kurirTokoCostError = "Biaya kurir toko wajib diisi (> Rp 0)"
                                            shippingCost = 0L
                                            selectedShippingRate = selectedShippingRate?.copy(cost = 0L)
                                        }
                                    },
                                    label = { Text("Biaya Pengiriman Kurir Toko (Rp) *") },
                                    placeholder = { Text("Contoh: 15000") },
                                    isError = kurirTokoCostError != null,
                                    supportingText = {
                                        if (kurirTokoCostError != null) {
                                            Text(kurirTokoCostError!!, color = StatusDangerRed)
                                        } else {
                                            Text("Isi nominal tarif pengiriman kurir internal toko.", color = TextMuted)
                                        }
                                    },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("kurir_toko_cost_input")
                                )
                            }
                        }
                    }

                    // Option: Tanpa Ekspedisi / Ambil Sendiri
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = {
                                selectedShippingRate = null
                                shippingCost = 0L
                                selectedExpedition = "None"
                                kurirTokoCostError = null
                            },
                            modifier = Modifier.testTag("select_none_expedition_btn")
                        ) {
                            Text("Tanpa Ekspedisi (Ongkir Rp 0)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Products Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "3. Tambah Produk Pesanan",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                TextButton(onClick = { showProductSearch = !showProductSearch }) {
                    Icon(imageVector = if (showProductSearch) Icons.Default.Close else Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (showProductSearch) "Tutup Cari" else "+ Cari Produk")
                }
            }

            if (showProductSearch) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        SearchBarField(
                            query = productSearch,
                            onQueryChange = { productSearch = it },
                            placeholder = "Cari SKU, Nama Produk, Family...",
                            testTag = "so_product_search_input"
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        val matchedProds = products.filter {
                            (it.sku.contains(productSearch, ignoreCase = true) ||
                            it.itemName.contains(productSearch, ignoreCase = true) ||
                            it.familyCode.contains(productSearch, ignoreCase = true)) &&
                            it.isProductActive
                        }

                        if (matchedProds.isEmpty()) {
                            Text(
                                text = "Tidak ada produk aktif dengan berat valid yang cocok",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(8.dp)
                            )
                        } else {
                            matchedProds.take(6).forEach { prod ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val existingIndex = orderItems.indexOfFirst { it.sku == prod.sku }
                                            if (existingIndex >= 0) {
                                                val existing = orderItems[existingIndex]
                                                orderItems[existingIndex] = existing.copy(
                                                    qty = existing.qty + 1,
                                                    subtotal = (existing.qty + 1) * existing.price
                                                )
                                            } else {
                                                orderItems.add(
                                                    SoItem(
                                                        sku = prod.sku,
                                                        itemName = prod.itemName,
                                                        qty = 1,
                                                        price = prod.netPrice,
                                                        purchasingPriceSnapshot = prod.purchasingPrice,
                                                        subtotal = prod.netPrice,
                                                        weightInGrams = prod.weightInGrams
                                                    )
                                                )
                                            }
                                        }
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = prod.itemName, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "${prod.sku} • Berat: ${prod.weightInGrams}g • Stok: ${prod.stock} pcs",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = rupiahFormat.format(prod.netPrice),
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = DustyPinkPrimary
                                    )
                                }
                                HorizontalDivider(color = BorderLight)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Order Items List
            if (orderItems.isEmpty()) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Belum ada produk yang ditambahkan. Klik '+ Cari Produk' di atas.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        orderItems.forEachIndexed { index, item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            itemIndexToEditPrice = index
                                            editPriceInput = item.price.toString()
                                        }
                                ) {
                                    Text(text = item.itemName, fontWeight = FontWeight.SemiBold)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${item.sku} • @ ${rupiahFormat.format(item.price)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Ubah harga SO",
                                            tint = DustyPinkPrimary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            if (item.qty > 1) {
                                                orderItems[index] = item.copy(
                                                    qty = item.qty - 1,
                                                    subtotal = (item.qty - 1) * item.price
                                                )
                                            } else {
                                                orderItems.removeAt(index)
                                            }
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Kurangi")
                                    }

                                    Text(
                                        text = "${item.qty}",
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )

                                    IconButton(
                                        onClick = {
                                            orderItems[index] = item.copy(
                                                qty = item.qty + 1,
                                                subtotal = (item.qty + 1) * item.price
                                            )
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Tambah")
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = rupiahFormat.format(item.subtotal),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            if (index < orderItems.size - 1) {
                                HorizontalDivider(color = BorderLight)
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = BorderLight)

                        val subtotal = orderItems.sumOf { it.subtotal }
                        val grandTotal = subtotal + shippingCost

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Subtotal Produk", style = MaterialTheme.typography.bodyMedium)
                            Text(text = rupiahFormat.format(subtotal), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Total Berat", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "$totalWeightInGrams gram (${String.format(Locale.US, "%.2f", totalWeightInGrams / 1000.0)} kg)",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (selectedShippingRate != null) "Ongkir (${selectedShippingRate!!.serviceName})" else "Ongkos Kirim",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = if (shippingCost > 0L) rupiahFormat.format(shippingCost) else "Rp 0",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = if (shippingCost > 0L) StatusSuccessGreen else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = BorderLight)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "TOTAL SO", fontWeight = FontWeight.Bold)
                            Text(
                                text = rupiahFormat.format(grandTotal),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = DustyPinkPrimary
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (recipientName.isBlank()) {
                        errorMessage = "Nama Customer / Penerima wajib diisi"
                        return@Button
                    }
                    if (recipientAddress.isBlank()) {
                        errorMessage = "Alamat pengiriman wajib diisi"
                        return@Button
                    }
                    if (orderItems.isEmpty()) {
                        errorMessage = "Tambahkan minimal satu produk ke dalam pesanan"
                        return@Button
                    }

                    errorMessage = null
                    viewModel.createSalesOrder(
                        customerId = selectedCustomer?.customerId ?: "",
                        customerName = recipientName,
                        phone = recipientPhone,
                        address = recipientAddress,
                        expedition = if (selectedExpedition.trim().equals("None", ignoreCase = true)) "" else selectedExpedition.trim(),
                        items = orderItems.toList(),
                        shippingCost = shippingCost,
                        shippingCourier = selectedShippingRate?.courier ?: "",
                        shippingServiceName = selectedShippingRate?.serviceName ?: "",
                        totalWeightInGrams = totalWeightInGrams
                    ) { created ->
                        if (created != null) {
                            onSuccess()
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("submit_create_so_button")
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("SIMPAN SALES ORDER (CONFIRMED)")
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
