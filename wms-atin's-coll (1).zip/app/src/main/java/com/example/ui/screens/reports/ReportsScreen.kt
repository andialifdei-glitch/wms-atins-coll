package com.example.ui.screens.reports

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.models.Family
import com.example.services.PdfDocumentGenerator
import com.example.services.PdfPoGenerator
import com.example.services.PdfSopGenerator
import com.example.ui.WmsViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingDialog
import com.example.ui.components.SearchBarField
import com.example.ui.components.WmsTopBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: WmsViewModel
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedReportType by remember { mutableIntStateOf(0) }
    // 0 = Stock Report, 1 = Sales Orders, 2 = Delivery Orders, 3 = Purchase Orders, 4 = Receivings, 5 = Stock Opname

    val products by viewModel.products.collectAsState()
    val families by viewModel.families.collectAsState()
    val salesOrders by viewModel.salesOrders.collectAsState()
    val deliveryOrders by viewModel.deliveryOrders.collectAsState()
    val purchaseOrders by viewModel.purchaseOrders.collectAsState()
    val receivings by viewModel.receivings.collectAsState()
    val stockOpnames by viewModel.stockOpnames.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    val pdfDocGen = remember { PdfDocumentGenerator(context) }
    val pdfPoGen = remember { PdfPoGenerator(context) }
    val pdfSopGen = remember { PdfSopGenerator(context) }

    // Filters for Stock Report (Section H)
    var filterStockBelow5 by remember { mutableStateOf(false) }
    var selectedFamilyFilter by remember { mutableStateOf<Family?>(null) }
    var familySearchQuery by remember { mutableStateOf("") }
    var showFamilySearchDropdown by remember { mutableStateOf(false) }

    if (isLoading) {
        LoadingDialog("Memproses laporan...")
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Laporan Operasional WMS",
                isOnline = isOnline
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedReportType,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = DustyPinkPrimary
            ) {
                Tab(
                    selected = selectedReportType == 0,
                    onClick = { selectedReportType = 0 },
                    text = { Text("Stock Report") },
                    modifier = Modifier.testTag("report_tab_stock")
                )
                Tab(
                    selected = selectedReportType == 1,
                    onClick = { selectedReportType = 1 },
                    text = { Text("Sales Orders") },
                    modifier = Modifier.testTag("report_tab_sales_orders")
                )
                Tab(
                    selected = selectedReportType == 2,
                    onClick = { selectedReportType = 2 },
                    text = { Text("Delivery Orders") },
                    modifier = Modifier.testTag("report_tab_delivery_orders")
                )
                Tab(
                    selected = selectedReportType == 3,
                    onClick = { selectedReportType = 3 },
                    text = { Text("Purchase Orders") },
                    modifier = Modifier.testTag("report_tab_purchase_orders")
                )
                Tab(
                    selected = selectedReportType == 4,
                    onClick = { selectedReportType = 4 },
                    text = { Text("Receiving Report") },
                    modifier = Modifier.testTag("report_tab_receiving")
                )
                Tab(
                    selected = selectedReportType == 5,
                    onClick = { selectedReportType = 5 },
                    text = { Text("Stock Opname") },
                    modifier = Modifier.testTag("report_tab_stock_opname")
                )
            }

            // Export Button Bar (for Table / XLSX export)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when (selectedReportType) {
                        0 -> "Laporan Persediaan & Nilai Stok"
                        1 -> "Laporan Sales Order per Dokumen"
                        2 -> "Laporan Delivery Order per Dokumen"
                        3 -> "Laporan Purchase Order per Dokumen"
                        4 -> "Laporan Penerimaan Barang per Dokumen"
                        else -> "Laporan Stock Opname per Dokumen"
                    },
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f)
                )

                if (selectedReportType == 0) {
                    Button(
                        onClick = {
                            val headers = listOf("Family Code", "Item Code", "Item Name", "Last Receiving", "Current Stock", "Purchasing Price", "Net Price", "Stock Value")
                            val rows = products.map { p ->
                                val valTotal = p.stock * p.purchasingPrice
                                listOf(p.familyCode, p.sku, p.itemName, p.lastReceiving, p.stock.toString(), p.purchasingPrice.toString(), p.netPrice.toString(), valTotal.toString())
                            }
                            viewModel.exportReport("Stock_Report", headers, rows)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("export_xlsx_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export XLSX")
                    }
                }
            }

            // Report Body View
            when (selectedReportType) {
                0 -> {
                    // STOCK REPORT with Filter Stock < 5 & Filter Family (Section H1 & H2)
                    val filteredProducts = products.filter { p ->
                        val matchesStock = if (filterStockBelow5) p.stock < 5 else true
                        val matchesFamily = if (selectedFamilyFilter != null) p.familyCode == selectedFamilyFilter?.familyCode else true
                        matchesStock && matchesFamily
                    }

                    Column(modifier = Modifier.fillMaxSize()) {
                        // Filters Section
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, BorderLight),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Filter Laporan Stok:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)

                                    // Filter Stock < 5 Chip (Section H1)
                                    FilterChip(
                                        selected = filterStockBelow5,
                                        onClick = { filterStockBelow5 = !filterStockBelow5 },
                                        label = { Text("Stock < 5") },
                                        leadingIcon = {
                                            if (filterStockBelow5) {
                                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                            }
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = StatusDangerRed,
                                            selectedLabelColor = Color.White
                                        ),
                                        modifier = Modifier.testTag("filter_stock_below_5_chip")
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Filter Family with compact Search Bar (Section H2)
                                if (selectedFamilyFilter != null) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = DustyPinkPrimary.copy(alpha = 0.1f),
                                        border = BorderStroke(1.dp, DustyPinkPrimary.copy(alpha = 0.4f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Family: ${selectedFamilyFilter!!.familyName} (${selectedFamilyFilter!!.familyCode})",
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                                color = DustyPinkPrimary
                                            )
                                            IconButton(
                                                onClick = {
                                                    selectedFamilyFilter = null
                                                    familySearchQuery = ""
                                                },
                                                modifier = Modifier.size(24.dp).testTag("clear_family_filter_btn")
                                            ) {
                                                Icon(Icons.Default.Close, contentDescription = "Clear Family Filter", tint = DustyPinkPrimary)
                                            }
                                        }
                                    }
                                } else {
                                    SearchBarField(
                                        query = familySearchQuery,
                                        onQueryChange = {
                                            familySearchQuery = it
                                            showFamilySearchDropdown = true
                                        },
                                        placeholder = "Filter berdasarkan Family (Daster, Kulot...)",
                                        testTag = "stock_family_search_bar"
                                    )

                                    if (showFamilySearchDropdown && familySearchQuery.isNotEmpty()) {
                                        val matchingFamilies = families.filter {
                                            it.familyName.contains(familySearchQuery, ignoreCase = true) ||
                                            it.familyCode.contains(familySearchQuery, ignoreCase = true)
                                        }.take(5)

                                        Card(
                                            shape = RoundedCornerShape(8.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 4.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(6.dp)) {
                                                if (matchingFamilies.isEmpty()) {
                                                    Text("Family tidak ditemukan", style = MaterialTheme.typography.bodySmall, color = TextMuted, modifier = Modifier.padding(8.dp))
                                                } else {
                                                    matchingFamilies.forEach { fam ->
                                                        Row(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .clip(RoundedCornerShape(6.dp))
                                                                .clickable {
                                                                    selectedFamilyFilter = fam
                                                                    familySearchQuery = ""
                                                                    showFamilySearchDropdown = false
                                                                }
                                                                .padding(8.dp),
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Text(fam.familyName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                                            Text(fam.familyCode, style = MaterialTheme.typography.labelSmall, color = DustyPinkPrimary)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        if (filteredProducts.isEmpty()) {
                            EmptyStateView(
                                title = "Tidak ada produk yang cocok",
                                description = "Coba ubah filter Stock < 5 atau filter Family"
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(bottom = 80.dp)
                            ) {
                                items(filteredProducts, key = { it.sku }) { p ->
                                    val stockValue = p.stock * p.purchasingPrice
                                    Card(
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        modifier = Modifier.fillMaxWidth().testTag("stock_item_${p.sku}")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = p.itemName, fontWeight = FontWeight.Bold)
                                                Text(text = "${p.sku} (${p.familyCode})", style = MaterialTheme.typography.bodySmall, color = DustyPinkPrimary)
                                                Text(text = "Beli: ${rupiahFormat.format(p.purchasingPrice)} • Jual: ${rupiahFormat.format(p.netPrice)}", style = MaterialTheme.typography.labelSmall)
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = "${p.stock} pcs",
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (p.stock < 5) StatusDangerRed else StatusSuccessGreen
                                                )
                                                Text(text = "Nilai: ${rupiahFormat.format(stockValue)}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // SALES ORDERS REPORT (Document Level per Section I & J)
                    if (salesOrders.isEmpty()) {
                        EmptyStateView(title = "Belum Ada Data Sales Order")
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(salesOrders, key = { it.soId }) { so ->
                                DocumentReportCard(
                                    documentNumber = so.soId,
                                    date = so.date,
                                    status = so.status,
                                    partyLabel = "Customer: ${so.customerName}",
                                    summary = "${so.items.size} Items • Total: ${rupiahFormat.format(so.total)}",
                                    onGeneratePdf = {
                                        coroutineScope.launch {
                                            val res = pdfDocGen.generateSalesOrderPdf(so)
                                            res.fold(
                                                onSuccess = { file -> pdfDocGen.sharePdf(file) },
                                                onFailure = { Toast.makeText(context, "Gagal membuat PDF: ${it.message}", Toast.LENGTH_SHORT).show() }
                                            )
                                        }
                                    },
                                    testTag = "report_so_${so.soId}"
                                )
                            }
                        }
                    }
                }
                2 -> {
                    // DELIVERY ORDERS REPORT (Document Level per Section I & J)
                    if (deliveryOrders.isEmpty()) {
                        EmptyStateView(title = "Belum Ada Data Delivery Order")
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(deliveryOrders, key = { it.doId }) { d ->
                                DocumentReportCard(
                                    documentNumber = d.doId,
                                    date = d.date,
                                    status = if (d.isStockDeducted) "TERKIRIM" else "DIPROSES",
                                    partyLabel = "Penerima: ${d.recipientName} • Ref: ${d.soId}",
                                    summary = "${d.totalItems} Items • ${d.totalPcs} pcs • Ekspedisi: ${d.expedition.ifBlank { "None" }}",
                                    onGeneratePdf = {
                                        coroutineScope.launch {
                                            val res = pdfDocGen.generateDeliveryOrderPdf(d)
                                            res.fold(
                                                onSuccess = { file -> pdfDocGen.sharePdf(file) },
                                                onFailure = { Toast.makeText(context, "Gagal membuat PDF: ${it.message}", Toast.LENGTH_SHORT).show() }
                                            )
                                        }
                                    },
                                    testTag = "report_do_${d.doId}"
                                )
                            }
                        }
                    }
                }
                3 -> {
                    // PURCHASE ORDERS REPORT (Document Level per Section I & J)
                    if (purchaseOrders.isEmpty()) {
                        EmptyStateView(title = "Belum Ada Data Purchase Order")
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(purchaseOrders, key = { it.poId }) { po ->
                                DocumentReportCard(
                                    documentNumber = po.poId,
                                    date = po.poDate,
                                    status = po.status,
                                    partyLabel = "Supplier: ${po.supplier}",
                                    summary = "${po.items.size} Items • Total: ${rupiahFormat.format(po.total)}",
                                    onGeneratePdf = {
                                        coroutineScope.launch {
                                            val res = pdfPoGen.generatePurchaseOrderPdf(po)
                                            res.fold(
                                                onSuccess = { file -> pdfPoGen.sharePdf(file, po.poId) },
                                                onFailure = { Toast.makeText(context, "Gagal membuat PDF: ${it.message}", Toast.LENGTH_SHORT).show() }
                                            )
                                        }
                                    },
                                    testTag = "report_po_${po.poId}"
                                )
                            }
                        }
                    }
                }
                4 -> {
                    // RECEIVING REPORT (Document Level per Section I & J)
                    if (receivings.isEmpty()) {
                        EmptyStateView(title = "Belum Ada Data Receiving")
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(receivings, key = { it.receivingId }) { recv ->
                                DocumentReportCard(
                                    documentNumber = recv.receivingId,
                                    date = recv.date,
                                    status = "POSTED",
                                    partyLabel = "Ref PO: ${recv.poId}",
                                    summary = "${recv.items.size} Items • ${recv.items.sumOf { it.qtyReceived }} pcs • By: ${recv.createdBy}",
                                    onGeneratePdf = {
                                        coroutineScope.launch {
                                            val res = pdfDocGen.generateReceivingPdf(recv)
                                            res.fold(
                                                onSuccess = { file -> pdfDocGen.sharePdf(file) },
                                                onFailure = { Toast.makeText(context, "Gagal membuat PDF: ${it.message}", Toast.LENGTH_SHORT).show() }
                                            )
                                        }
                                    },
                                    testTag = "report_recv_${recv.receivingId}"
                                )
                            }
                        }
                    }
                }
                5 -> {
                    // STOCK OPNAME REPORT (Document Level per Section I & J)
                    if (stockOpnames.isEmpty()) {
                        EmptyStateView(title = "Belum Ada Data Stock Opname")
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(stockOpnames, key = { it.sopId }) { sop ->
                                DocumentReportCard(
                                    documentNumber = sop.documentNo,
                                    date = sop.opnameDate,
                                    status = sop.status,
                                    partyLabel = "Dibuat oleh: ${sop.initializedBy}",
                                    summary = "${sop.items.count { it.hasBeenCounted }} dari ${sop.items.size} SKU dihitung",
                                    onGeneratePdf = {
                                        coroutineScope.launch {
                                            val res = pdfSopGen.generateSopReportPdf(sop)
                                            res.fold(
                                                onSuccess = { file -> pdfSopGen.sharePdf(file) },
                                                onFailure = { Toast.makeText(context, "Gagal membuat PDF: ${it.message}", Toast.LENGTH_SHORT).show() }
                                            )
                                        }
                                    },
                                    testTag = "report_sop_${sop.sopId}"
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Standard Document-Level Report Card (Section I & J)
 * 1 card represents 1 document with Generate PDF button.
 */
@Composable
fun DocumentReportCard(
    documentNumber: String,
    date: String,
    status: String,
    partyLabel: String,
    summary: String,
    onGeneratePdf: () -> Unit,
    testTag: String
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = documentNumber,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = DustyPinkPrimary
                )
                Surface(
                    color = when (status) {
                        "COMPLETED", "DELIVERY ORDER", "POSTED" -> StatusSuccessGreen.copy(alpha = 0.15f)
                        "CANCELLED", "CANCELED" -> StatusDangerRed.copy(alpha = 0.15f)
                        "PROCESSING" -> DustyPinkPrimary.copy(alpha = 0.15f)
                        else -> StatusWarningOrange.copy(alpha = 0.15f)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = status,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = when (status) {
                            "COMPLETED", "DELIVERY ORDER", "POSTED" -> StatusSuccessGreen
                            "CANCELLED", "CANCELED" -> StatusDangerRed
                            "PROCESSING" -> DustyPinkPrimary
                            else -> StatusWarningOrange
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = partyLabel,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = summary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Tanggal: $date",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onGeneratePdf,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_pdf_$documentNumber")
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate PDF")
            }
        }
    }
}
