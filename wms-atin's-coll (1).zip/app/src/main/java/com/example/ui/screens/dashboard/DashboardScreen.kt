package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.WmsViewModel
import com.example.ui.components.WmsTopBar
import com.example.ui.theme.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MetricCardData(
    val title: String,
    val value: String,
    val subtitle: String? = null,
    val icon: ImageVector,
    val accentColor: Color,
    val testTag: String,
    val onClick: (() -> Unit)? = null
)

@Composable
fun DashboardScreen(
    viewModel: WmsViewModel,
    onNavigateToSales: () -> Unit,
    onNavigateToInventory: () -> Unit,
    onNavigateToPurchase: () -> Unit,
    onNavigateToStockOpname: () -> Unit,
    onRequestLogout: () -> Unit
) {
    val products by viewModel.products.collectAsState()
    val purchaseOrders by viewModel.purchaseOrders.collectAsState()
    val salesOrders by viewModel.salesOrders.collectAsState()
    val deliveryOrders by viewModel.deliveryOrders.collectAsState()
    val receivings by viewModel.receivings.collectAsState()
    val stockMovements by viewModel.stockMovements.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()

    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    // Calculations
    val totalSku = products.size
    val totalStock = products.sumOf { it.stock }
    val outOfStock = products.count { it.stock <= 0 }
    val lowStock = products.count { it.stock in 1..9 }

    val todayDos = deliveryOrders.filter { it.date == todayStr }
    val todaySalesAmount = todayDos.sumOf { doOrder -> doOrder.items.sumOf { it.subtotal } }
    val todayItemsSold = todayDos.sumOf { it.totalPcs }

    val todayReceivingsCount = receivings.count { it.date == todayStr }

    val todayReturns = stockMovements.count { it.date == todayStr && it.type == "RETURN" }
    val todayBreakages = stockMovements.count { it.date == todayStr && it.type == "BREAKAGE" }

    val poPending = purchaseOrders.count { it.status == "CONFIRMED" || it.status == "PARTIAL" }
    val soReady = salesOrders.count { it.status == "READY TO DELIVER" }
    val doTodayCount = todayDos.size

    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "WMS Atin's Coll",
                userRole = "${currentUser?.name} (${currentUser?.role})",
                isOnline = isOnline,
                onLogoutClick = onRequestLogout
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Welcome Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DustyPinkPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_welcome_card")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Halo, ${currentUser?.name ?: "User"}!",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Operasional Gudang & Persediaan Siap",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.9f))
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warehouse,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "Ringkasan Persediaan (Inventory)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 4 Grid inventory cards
            Row(modifier = Modifier.fillMaxWidth()) {
                MetricItem(
                    title = "Total SKU",
                    value = "$totalSku",
                    icon = Icons.Default.Category,
                    color = DustyPinkPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToInventory,
                    testTag = "metric_total_sku"
                )
                Spacer(modifier = Modifier.width(10.dp))
                MetricItem(
                    title = "Total Stok Fisik",
                    value = "$totalStock pcs",
                    icon = Icons.Default.Inventory2,
                    color = StatusBlue,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToInventory,
                    testTag = "metric_total_stock"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricItem(
                    title = "Stok Habis (0)",
                    value = "$outOfStock SKU",
                    icon = Icons.Default.HighlightOff,
                    color = if (outOfStock > 0) StatusDangerRed else TextMuted,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToInventory,
                    testTag = "metric_out_of_stock"
                )
                Spacer(modifier = Modifier.width(10.dp))
                MetricItem(
                    title = "Stok Menipis (<10)",
                    value = "$lowStock SKU",
                    icon = Icons.Default.WarningAmber,
                    color = if (lowStock > 0) StatusWarningOrange else TextMuted,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToInventory,
                    testTag = "metric_low_stock"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Operasional Hari Ini (${todayStr})",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricItem(
                    title = "Penjualan DO Hari Ini",
                    value = rupiahFormat.format(todaySalesAmount),
                    icon = Icons.Default.AttachMoney,
                    color = StatusSuccessGreen,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToSales,
                    testTag = "metric_today_sales"
                )
                Spacer(modifier = Modifier.width(10.dp))
                MetricItem(
                    title = "Barang Terjual",
                    value = "$todayItemsSold pcs",
                    icon = Icons.Default.ShoppingBag,
                    color = StatusPurple,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToSales,
                    testTag = "metric_today_sold"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricItem(
                    title = "DO Dikirim Hari Ini",
                    value = "$doTodayCount DO",
                    icon = Icons.Default.LocalShipping,
                    color = DustyPinkPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToSales,
                    testTag = "metric_today_do"
                )
                Spacer(modifier = Modifier.width(10.dp))
                MetricItem(
                    title = "SO Siap Kirim",
                    value = "$soReady SO",
                    icon = Icons.Default.CheckCircleOutline,
                    color = if (soReady > 0) StatusWarningOrange else StatusSuccessGreen,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToSales,
                    testTag = "metric_so_ready"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricItem(
                    title = "PO Menunggu Kirim",
                    value = "$poPending PO",
                    icon = Icons.Default.AssignmentLate,
                    color = StatusBlue,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToPurchase,
                    testTag = "metric_po_pending"
                )
                Spacer(modifier = Modifier.width(10.dp))
                MetricItem(
                    title = "Receiving Masuk",
                    value = "$todayReceivingsCount PO",
                    icon = Icons.Default.MoveToInbox,
                    color = StatusSuccessGreen,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToPurchase,
                    testTag = "metric_today_receiving"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricItem(
                    title = "Return Hari Ini",
                    value = "$todayReturns log",
                    icon = Icons.Default.Replay,
                    color = StatusWarningOrange,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_today_return"
                )
                Spacer(modifier = Modifier.width(10.dp))
                MetricItem(
                    title = "Kerusakan / Cacat",
                    value = "$todayBreakages log",
                    icon = Icons.Default.BrokenImage,
                    color = StatusDangerRed,
                    modifier = Modifier.weight(1f),
                    testTag = "metric_today_breakage"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MetricItem(
                    title = "Stock Opname (Audit)",
                    value = "Audit Stok Fisik",
                    icon = Icons.Default.Checklist,
                    color = DustyPinkPrimary,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = onNavigateToStockOpname,
                    testTag = "metric_stock_opname"
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun MetricItem(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    testTag: String
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = modifier
            .testTag(testTag)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                ),
                maxLines = 1
            )
        }
    }
}
