package com.example.ui.screens.more

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.TestApiKeyResult
import com.example.data.models.UserRole
import com.example.ui.WmsViewModel
import com.example.ui.components.WmsTopBar
import com.example.ui.theme.*

@Composable
fun RajaOngkirApiScreen(
    viewModel: WmsViewModel,
    onBack: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val isRootAdmin = currentUser?.role == UserRole.ROOT_ADMIN.label

    val metadata by viewModel.rajaOngkirMetadata.collectAsState()
    val isTesting by viewModel.isTestingApiKey.collectAsState()
    val isSaving by viewModel.isSavingApiKey.collectAsState()

    var inputApiKey by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    // Validation state
    var testedApiKey by remember { mutableStateOf<String?>(null) }
    var isTestPassed by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    // Dialog state for alerts
    var alertTitle by remember { mutableStateOf<String?>(null) }
    var alertMessage by remember { mutableStateOf<String?>(null) }
    var isSuccessAlert by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    // Alert Dialog
    if (alertTitle != null && alertMessage != null) {
        AlertDialog(
            onDismissRequest = {
                alertTitle = null
                alertMessage = null
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isSuccessAlert) Icons.Default.CheckCircle else Icons.Default.Error,
                        contentDescription = null,
                        tint = if (isSuccessAlert) StatusSuccessGreen else StatusDangerRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = alertTitle!!,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            },
            text = {
                Text(
                    text = alertMessage!!,
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        alertTitle = null
                        alertMessage = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSuccessAlert) DustyPinkPrimary else MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("alert_ok_btn")
                ) {
                    Text("OK")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "RajaOngkir API",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Guard: If not Root Admin
            if (!isRootAdmin) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth().testTag("access_denied_card")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = StatusDangerRed)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Akses Terbatas (ROOT_ADMIN Only)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = StatusDangerRed
                            )
                            Text(
                                text = "Hanya Root Admin yang berhak melihat status dan mengubah RajaOngkir API Key.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Kembali")
                }
                return@Scaffold
            }

            // Status Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Status Integrasi RajaOngkir",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (metadata.configured) StatusSuccessGreen else StatusWarningOrange,
                            modifier = Modifier.size(10.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (metadata.configured) "API Key Aktif: ● Terkonfigurasi" else "API Key Aktif: ● Belum dikonfigurasi",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = if (metadata.configured) StatusSuccessGreen else StatusWarningOrange
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Kunci Aktif Saat Ini: ${metadata.activeKeyMasked}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )

                    if (metadata.updatedAt != null) {
                        val dateFormatted = remember(metadata.updatedAt) {
                            val sdf = java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale("id", "ID"))
                            sdf.format(metadata.updatedAt!!.toDate())
                        }
                        Text(
                            text = "Terakhir diperbarui: $dateFormatted oleh ${metadata.updatedBy}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Configuration Form Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Kelola API Key",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Masukkan RajaOngkir API Key (Komerce) baru untuk diuji dan disimpan.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Masked / Secure Input Field
                    OutlinedTextField(
                        value = inputApiKey,
                        onValueChange = { newValue ->
                            inputApiKey = newValue
                            validationError = null
                            // Invalidate test if input changes
                            if (testedApiKey != null && newValue != testedApiKey) {
                                isTestPassed = false
                            }
                        },
                        label = { Text("RajaOngkir API Key") },
                        placeholder = { Text("••••••••••••••••") },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(
                                onClick = { isPasswordVisible = !isPasswordVisible },
                                modifier = Modifier.testTag("toggle_api_key_visibility_btn")
                            ) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (isPasswordVisible) "Sembunyikan" else "Tampilkan"
                                )
                            }
                        },
                        isError = validationError != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("rajaongkir_api_key_input")
                    )

                    if (validationError != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = validationError!!,
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusDangerRed
                        )
                    }

                    if (isTestPassed && testedApiKey == inputApiKey && inputApiKey.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = StatusSuccessGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "API Key sudah diuji dan valid. Siap disimpan.",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = StatusSuccessGreen
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Buttons: Uji API Key & Simpan API Key
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Button 1: Uji API Key
                        OutlinedButton(
                            onClick = {
                                val trimmed = inputApiKey.trim()
                                if (trimmed.isBlank()) {
                                    validationError = "API Key wajib diisi."
                                    return@OutlinedButton
                                }
                                validationError = null

                                viewModel.testRajaOngkirApiKey(trimmed) { result ->
                                    testedApiKey = trimmed
                                    when (result) {
                                        is TestApiKeyResult.Success -> {
                                            isTestPassed = true
                                            isSuccessAlert = true
                                            alertTitle = "API Key Valid"
                                            alertMessage = "API Key berhasil digunakan untuk mengakses RajaOngkir."
                                        }
                                        is TestApiKeyResult.InvalidKey -> {
                                            isTestPassed = false
                                            isSuccessAlert = false
                                            alertTitle = "API Key Tidak Valid"
                                            alertMessage = "RajaOngkir menolak API Key yang diberikan."
                                        }
                                        is TestApiKeyResult.QuotaExceeded -> {
                                            isTestPassed = false
                                            isSuccessAlert = false
                                            alertTitle = "Batas Kuota Tercapai"
                                            alertMessage = result.message
                                        }
                                        is TestApiKeyResult.Forbidden -> {
                                            isTestPassed = false
                                            isSuccessAlert = false
                                            alertTitle = "Akses Ditolak"
                                            alertMessage = result.message
                                        }
                                        is TestApiKeyResult.ServerError -> {
                                            isTestPassed = false
                                            isSuccessAlert = false
                                            alertTitle = "Server RajaOngkir Gangguan"
                                            alertMessage = result.message
                                        }
                                        is TestApiKeyResult.NetworkError -> {
                                            isTestPassed = false
                                            isSuccessAlert = false
                                            alertTitle = "Pengujian Gagal"
                                            alertMessage = "Tidak dapat terhubung ke server RajaOngkir."
                                        }
                                    }
                                }
                            },
                            enabled = !isTesting && !isSaving,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("test_api_key_btn")
                        ) {
                            if (isTesting) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Menguji...", fontSize = 12.sp)
                            } else {
                                Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Uji API Key", fontSize = 12.sp)
                            }
                        }

                        // Button 2: Simpan API Key
                        Button(
                            onClick = {
                                val trimmed = inputApiKey.trim()
                                if (trimmed.isBlank()) {
                                    validationError = "API Key wajib diisi."
                                    return@Button
                                }
                                if (testedApiKey == null || !isTestPassed) {
                                    validationError = "Silakan uji API Key terlebih dahulu."
                                    return@Button
                                }
                                if (testedApiKey != trimmed) {
                                    validationError = "API Key berubah. Silakan lakukan pengujian ulang."
                                    return@Button
                                }

                                validationError = null

                                viewModel.saveRajaOngkirApiKey(trimmed) { success, err ->
                                    if (success) {
                                        inputApiKey = ""
                                        testedApiKey = null
                                        isTestPassed = false
                                        isSuccessAlert = true
                                        alertTitle = "Berhasil"
                                        alertMessage = "API Key berhasil diperbarui."
                                    } else {
                                        isSuccessAlert = false
                                        alertTitle = "Penyimpanan Gagal"
                                        alertMessage = err ?: "Gagal memperbarui API Key."
                                    }
                                }
                            },
                            enabled = !isTesting && !isSaving && isTestPassed && testedApiKey == inputApiKey && inputApiKey.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("save_api_key_btn")
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Menyimpan...", fontSize = 12.sp)
                            } else {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Simpan API Key", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Security Notice Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = DustyPinkPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Kebijakan Keamanan & Secret Management",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• API Key tidak pernah disimpan secara terbuka di Android, APK, maupun Firestore.\n" +
                               "• Pengujian API Key menggunakan kuota minimal (1 hit) tanpa loop atau mass retry.\n" +
                               "• Setiap pembaruan API Key dicatat dalam Audit Log tanpa menyertakan nilai secret.\n" +
                               "• Jika pengujian gagal, API Key lama tetap aman dan aktif digunakan oleh sistem.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
