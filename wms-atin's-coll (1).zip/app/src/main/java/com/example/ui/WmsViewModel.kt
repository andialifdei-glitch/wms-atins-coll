package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.AuthManager
import com.example.data.firebase.FirestoreManager
import com.example.data.models.*
import com.example.data.repositories.*
import com.example.services.BluetoothPrinterService
import com.example.services.ExcelExporter
import com.example.services.ExcelSopExporter
import com.example.services.PdfPoGenerator
import com.example.services.PdfSopGenerator
import com.example.services.PrinterDeviceInfo
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class WmsViewModel(application: Application) : AndroidViewModel(application) {
    private val db = FirestoreManager.getFirestore(application)

    val authManager = AuthManager(db)
    val familyRepo = FamilyRepository(db)
    val productRepo = ProductRepository(db)
    val customerRepo = CustomerRepository(db)
    val regionRepo = RegionRepository(db, application)
    val shippingRepo = ShippingServiceRepository(db)
    val poRepo = PurchaseOrderRepository(db)
    val receivingRepo = ReceivingRepository(db)
    val soRepo = SalesOrderRepository(db)
    val doRepo = DeliveryOrderRepository(db)
    val inventoryRepo = InventoryRepository(db)
    val promoRepo = PromoPriceRepository(db)
    val userRepo = UserRepository(db)
    val settingsRepo = SettingsRepository(db)
    val sopRepo = StockOpnameRepository(db, productRepo)
    val shippingCostRepo = ShippingCostRepository()
    val rajaOngkirAdminRepo = RajaOngkirAdminRepository(db)

    val printerService = BluetoothPrinterService(application)
    val pdfGenerator = PdfPoGenerator(application)
    val excelExporter = ExcelExporter(application)
    val pdfSopGen = PdfSopGenerator(application)
    val excelSopExp = ExcelSopExporter(application)
    val docPdfGen = com.example.services.PdfDocumentGenerator(application)

    // User session
    val currentUser: StateFlow<UserAccount?> = authManager.currentUser

    // Connection status
    private val _isOnline = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    // Global UI Feedback (Snackbar / Alert message)
    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Data streams
    val families: StateFlow<List<Family>> = familyRepo.listenFamilies()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val products: StateFlow<List<Product>> = productRepo.listenProducts()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val customers: StateFlow<List<Customer>> = customerRepo.listenCustomers()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val shippingServices: StateFlow<List<ShippingService>> = shippingRepo.listenShippingServices()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val purchaseOrders: StateFlow<List<PurchaseOrder>> = poRepo.listenPurchaseOrders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val receivings: StateFlow<List<Receiving>> = receivingRepo.listenReceivings()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val salesOrders: StateFlow<List<SalesOrder>> = soRepo.listenSalesOrders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val deliveryOrders: StateFlow<List<DeliveryOrder>> = doRepo.listenDeliveryOrders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val stockMovements: StateFlow<List<StockMovement>> = inventoryRepo.listenStockMovements()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val stockAdjustments: StateFlow<List<StockAdjustment>> = inventoryRepo.listenAdjustments()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val promotions: StateFlow<List<PromoPrice>> = promoRepo.listenPromotions()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val userAccounts: StateFlow<List<UserAccount>> = userRepo.listenUsers()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val stockOpnames: StateFlow<List<StockOpname>> = sopRepo.listenStockOpnames()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val sopPostings: StateFlow<List<SopPosting>> = sopRepo.listenPostings()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val storeSettings: StateFlow<StoreSettings> = settingsRepo.settings

    // Paired Bluetooth printers
    private val _pairedPrinters = MutableStateFlow<List<PrinterDeviceInfo>>(emptyList())
    val pairedPrinters: StateFlow<List<PrinterDeviceInfo>> = _pairedPrinters.asStateFlow()

    // Session Management (5 minutes timeout)
    companion object {
        const val SESSION_TIMEOUT_MS = 5 * 60 * 1000L // 5 minutes
    }
    private val _lastActivityTime = MutableStateFlow(System.currentTimeMillis())

    fun recordUserActivity() {
        _lastActivityTime.value = System.currentTimeMillis()
    }

    init {
        viewModelScope.launch {
            authManager.bootstrapRootAdminIfNeeded()
            shippingRepo.bootstrapDefaultsIfNeeded()
            settingsRepo.loadSettings()
            refreshPrinters()
        }

        // Monitor session timeout every 5 seconds
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(5000L)
                if (currentUser.value != null) {
                    val idleTime = System.currentTimeMillis() - _lastActivityTime.value
                    if (idleTime >= SESSION_TIMEOUT_MS) {
                        Log.d("WmsViewModel", "Auto-logout: user inactive for ${idleTime / 1000}s")
                        logout()
                        showMessage("Sesi Anda telah berakhir karena tidak ada aktivitas selama 5 menit.")
                    }
                }
            }
        }
    }

    fun clearUiMessage() {
        _uiMessage.value = null
    }

    fun showMessage(msg: String) {
        _uiMessage.value = msg
    }

    fun refreshPrinters() {
        _pairedPrinters.value = printerService.getPairedPrinters()
    }

    // AUTH
    fun login(userId: String, pass: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = authManager.login(userId, pass)
            _isLoading.value = false
            res.fold(
                onSuccess = { user ->
                    recordUserActivity()
                    onResult(true, null)
                },
                onFailure = { err ->
                    onResult(false, err.message)
                }
            )
        }
    }

    fun logout() {
        authManager.logout()
    }

    // FAMILY
    fun createFamily(name: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Admin"
            val res = familyRepo.createFamily(name, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Family ${it.familyCode} berhasil dibuat")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal membuat Family")
                    onDone(false)
                }
            )
        }
    }

    fun updateFamily(familyId: String, newCode: String, newName: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Admin"
            val role = currentUser.value?.role ?: ""
            val res = familyRepo.updateFamily(familyId, newCode, newName, user, role)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Family berhasil diperbarui")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memperbarui Family")
                    onDone(false)
                }
            )
        }
    }

    fun deleteFamily(familyCode: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val role = currentUser.value?.role ?: ""
            val res = familyRepo.deleteFamily(familyCode, role)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Family $familyCode berhasil dihapus")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal menghapus Family")
                    onDone(false)
                }
            )
        }
    }

    // PRODUCT
    fun createProduct(
        familyCode: String,
        itemName: String,
        purchasingPrice: Long,
        netPrice: Long,
        initialStock: Int,
        weightInGrams: Int = 0,
        onDone: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = productRepo.createProduct(familyCode, itemName, purchasingPrice, netPrice, initialStock, weightInGrams, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Produk baru berhasil dibuat dengan SKU: ${it.sku}")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal membuat produk")
                    onDone(false)
                }
            )
        }
    }

    fun updateProduct(
        sku: String,
        itemName: String,
        purchasingPrice: Long,
        netPrice: Long,
        weightInGrams: Int = 0,
        onDone: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val role = currentUser.value?.role ?: ""
            val res = productRepo.updateProduct(sku, itemName, purchasingPrice, netPrice, weightInGrams, user, role)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Produk $sku berhasil disimpan")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memperbarui produk")
                    onDone(false)
                }
            )
        }
    }

    fun deleteProduct(sku: String) {
        viewModelScope.launch {
            val res = productRepo.deleteProduct(sku)
            res.fold(
                onSuccess = { showMessage("Produk $sku berhasil dihapus") },
                onFailure = { showMessage("Gagal menghapus produk: ${it.message}") }
            )
        }
    }

    fun toggleProductStatus(sku: String, newActive: Boolean, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name?.ifBlank { "Admin" } ?: "Admin"
            val role = currentUser.value?.role ?: ""
            if (role != com.example.data.models.UserRole.ROOT_ADMIN.label) {
                showMessage("Akses Ditolak: Hanya Root Admin yang berhak mengubah status produk")
                _isLoading.value = false
                onDone(false)
                return@launch
            }
            val res = productRepo.toggleProductStatus(sku, newActive, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Status produk $sku berhasil diubah menjadi ${if (newActive) "Aktif" else "Nonaktif"}")
                    onDone(true)
                },
                onFailure = {
                    showMessage("Gagal mengubah status produk: ${it.message}")
                    onDone(false)
                }
            )
        }
    }

    // REGION STATEFLOWS (Indonesia Administrative Master Data)
    private val _provinces = MutableStateFlow<List<Region>>(emptyList())
    val provinces: StateFlow<List<Region>> = _provinces.asStateFlow()

    private val _regencies = MutableStateFlow<List<Region>>(emptyList())
    val regencies: StateFlow<List<Region>> = _regencies.asStateFlow()

    private val _districts = MutableStateFlow<List<Region>>(emptyList())
    val districts: StateFlow<List<Region>> = _districts.asStateFlow()

    private val _villages = MutableStateFlow<List<Region>>(emptyList())
    val villages: StateFlow<List<Region>> = _villages.asStateFlow()

    private val _isRegionLoading = MutableStateFlow(false)
    val isRegionLoading: StateFlow<Boolean> = _isRegionLoading.asStateFlow()

    private val _regionError = MutableStateFlow<String?>(null)
    val regionError: StateFlow<String?> = _regionError.asStateFlow()

    fun loadProvinces() {
        if (_provinces.value.isNotEmpty()) return
        viewModelScope.launch {
            _isRegionLoading.value = true
            _regionError.value = null
            val res = regionRepo.getProvinces()
            _isRegionLoading.value = false
            res.fold(
                onSuccess = { _provinces.value = it },
                onFailure = { _regionError.value = it.message ?: "Gagal memuat data provinsi." }
            )
        }
    }

    fun loadRegencies(provinceCode: String) {
        viewModelScope.launch {
            _isRegionLoading.value = true
            _regionError.value = null
            _districts.value = emptyList()
            _villages.value = emptyList()
            val res = regionRepo.getRegencies(provinceCode)
            _isRegionLoading.value = false
            res.fold(
                onSuccess = { _regencies.value = it },
                onFailure = { _regionError.value = it.message ?: "Gagal memuat data Kabupaten/Kota." }
            )
        }
    }

    fun loadDistricts(regencyCode: String) {
        viewModelScope.launch {
            _isRegionLoading.value = true
            _regionError.value = null
            _villages.value = emptyList()
            val res = regionRepo.getDistricts(regencyCode)
            _isRegionLoading.value = false
            res.fold(
                onSuccess = { _districts.value = it },
                onFailure = { _regionError.value = it.message ?: "Gagal memuat data Kecamatan." }
            )
        }
    }

    fun loadVillages(districtCode: String) {
        viewModelScope.launch {
            _isRegionLoading.value = true
            _regionError.value = null
            val res = regionRepo.getVillages(districtCode)
            _isRegionLoading.value = false
            res.fold(
                onSuccess = { _villages.value = it },
                onFailure = { _regionError.value = it.message ?: "Gagal memuat data Desa/Kelurahan." }
            )
        }
    }

    fun clearRegencies() {
        _regencies.value = emptyList()
        _districts.value = emptyList()
        _villages.value = emptyList()
    }

    fun clearDistricts() {
        _districts.value = emptyList()
        _villages.value = emptyList()
    }

    fun clearVillages() {
        _villages.value = emptyList()
    }

    // CUSTOMER
    fun addCustomer(
        name: String,
        phone: String,
        addressDetail: String,
        provinceCode: String,
        provinceName: String,
        regencyCode: String,
        regencyName: String,
        districtCode: String,
        districtName: String,
        onDone: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = customerRepo.addCustomer(
                name = name,
                phone = phone,
                addressDetail = addressDetail,
                provinceCode = provinceCode,
                provinceName = provinceName,
                regencyCode = regencyCode,
                regencyName = regencyName,
                districtCode = districtCode,
                districtName = districtName
            )
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Customer ${it.customerCode} - ${it.customerName} berhasil ditambahkan")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal menambahkan customer")
                    onDone(false)
                }
            )
        }
    }

    fun addCustomer(name: String, phone: String, address: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val res = customerRepo.addCustomer(name, phone, address)
            res.fold(
                onSuccess = {
                    showMessage("Customer ${it.customerCode} - ${it.customerName} berhasil ditambahkan")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal menambahkan customer")
                    onDone(false)
                }
            )
        }
    }

    fun updateCustomer(id: String, name: String, phone: String, address: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val res = customerRepo.updateCustomer(id, name, phone, address)
            res.fold(
                onSuccess = {
                    showMessage("Data customer berhasil diperbarui")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memperbarui customer")
                    onDone(false)
                }
            )
        }
    }

    fun deleteCustomer(id: String) {
        viewModelScope.launch {
            customerRepo.deleteCustomer(id)
            showMessage("Customer telah dihapus")
        }
    }

    // SHIPPING
    fun addShippingService(name: String) {
        viewModelScope.launch {
            val res = shippingRepo.addShippingService(name)
            res.fold(
                onSuccess = { showMessage("Ekspedisi ${it.name} berhasil ditambahkan") },
                onFailure = { showMessage(it.message ?: "Gagal menambahkan ekspedisi") }
            )
        }
    }

    fun updateShippingService(id: String, name: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val role = currentUser.value?.role ?: ""
            val res = shippingRepo.updateShippingService(id, name, role)
            res.fold(
                onSuccess = {
                    showMessage("Ekspedisi berhasil diperbarui")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memperbarui ekspedisi")
                    onDone(false)
                }
            )
        }
    }

    fun deleteShippingService(id: String, onDone: ((Boolean) -> Unit)? = null) {
        viewModelScope.launch {
            val role = currentUser.value?.role ?: ""
            val res = shippingRepo.deleteShippingService(id, role)
            res.fold(
                onSuccess = {
                    showMessage("Ekspedisi telah dihapus")
                    onDone?.invoke(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal menghapus ekspedisi")
                    onDone?.invoke(false)
                }
            )
        }
    }

    // PURCHASE ORDER
    fun createPurchaseOrder(
        supplier: String,
        supplierAddress: String,
        supplierPhone: String,
        notes: String,
        items: List<PoItem>,
        onDone: (PurchaseOrder?) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = poRepo.createPurchaseOrder(supplier, supplierAddress, supplierPhone, notes, items, user)
            _isLoading.value = false
            res.fold(
                onSuccess = { po ->
                    showMessage("Purchase Order ${po.poId} berhasil dibuat")
                    onDone(po)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal membuat Purchase Order")
                    onDone(null)
                }
            )
        }
    }

    fun cancelPurchaseOrder(poId: String) {
        viewModelScope.launch {
            val user = currentUser.value?.name ?: "Staff"
            val res = poRepo.cancelPurchaseOrder(poId, user)
            res.fold(
                onSuccess = { showMessage("Purchase Order $poId berhasil dibatalkan") },
                onFailure = { showMessage("Gagal membatalkan PO: ${it.message}") }
            )
        }
    }

    fun generatePoPdfAndShare(po: PurchaseOrder) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = pdfGenerator.generatePurchaseOrderPdf(po)
            _isLoading.value = false
            res.fold(
                onSuccess = { file ->
                    pdfGenerator.sharePdf(file, po.poId)
                },
                onFailure = {
                    showMessage("Gagal membuat PDF PO: ${it.message}")
                }
            )
        }
    }

    fun generateSoPdfAndShare(so: SalesOrder) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = docPdfGen.generateSalesOrderPdf(so)
            _isLoading.value = false
            res.fold(
                onSuccess = { file -> docPdfGen.sharePdf(file) },
                onFailure = { showMessage("Gagal membuat PDF SO: ${it.message}") }
            )
        }
    }

    fun generateDoPdfAndShare(doOrder: DeliveryOrder) {
        viewModelScope.launch {
            _isLoading.value = true
            val store = storeSettings.value
            val user = currentUser.value?.name?.takeIf { it.isNotBlank() }
                ?: currentUser.value?.email?.takeIf { it.isNotBlank() }
                ?: currentUser.value?.userId?.takeIf { it.isNotBlank() }
                ?: com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.displayName?.takeIf { it.isNotBlank() }
                ?: com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.email?.takeIf { it.isNotBlank() }
                ?: "-"
            val res = docPdfGen.generateDeliveryOrderPdf(doOrder, store, user)
            _isLoading.value = false
            res.fold(
                onSuccess = { file -> docPdfGen.sharePdf(file) },
                onFailure = { showMessage("Gagal membuat PDF DO: ${it.message}") }
            )
        }
    }

    fun generateReceivingPdfAndShare(recv: Receiving) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = docPdfGen.generateReceivingPdf(recv)
            _isLoading.value = false
            res.fold(
                onSuccess = { file -> docPdfGen.sharePdf(file) },
                onFailure = { showMessage("Gagal membuat PDF Receiving: ${it.message}") }
            )
        }
    }

    // RECEIVING
    fun processReceiving(
        poId: String,
        items: List<ReceivingItem>,
        notes: String,
        onDone: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = receivingRepo.processReceiving(poId, items, notes, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Receiving untuk PO $poId berhasil diproses. Stock telah bertambah.")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memproses receiving")
                    onDone(false)
                }
            )
        }
    }

    // SHIPPING CALCULATION (RajaOngkir via Cloud Function)
    private val _shippingRates = MutableStateFlow<List<ShippingRate>>(emptyList())
    val shippingRates: StateFlow<List<ShippingRate>> = _shippingRates.asStateFlow()

    private val _isCalculatingShipping = MutableStateFlow(false)
    val isCalculatingShipping: StateFlow<Boolean> = _isCalculatingShipping.asStateFlow()

    private val _shippingError = MutableStateFlow<String?>(null)
    val shippingError: StateFlow<String?> = _shippingError.asStateFlow()

    fun calculateShippingRates(origin: String, destination: String, weightInGrams: Int) {
        viewModelScope.launch {
            _isCalculatingShipping.value = true
            _shippingError.value = null
            _shippingRates.value = emptyList()
            val res = shippingCostRepo.calculateShippingCost(origin, destination, weightInGrams)
            _isCalculatingShipping.value = false
            res.fold(
                onSuccess = { rates ->
                    _shippingRates.value = rates
                    _shippingError.value = null
                    showMessage("Tarif ongkir berhasil dihitung (${rates.size} opsi tersedia)")
                },
                onFailure = { err ->
                    val msg = err.message ?: "Gagal mengecek ongkir. Silakan coba kembali."
                    _shippingError.value = msg
                    showMessage(msg)
                    _shippingRates.value = emptyList()
                }
            )
        }
    }

    fun clearShippingRates() {
        _shippingRates.value = emptyList()
        _shippingError.value = null
    }

    // RAJAONGKIR API KEY MANAGEMENT (ROOT_ADMIN ONLY)
    val rajaOngkirMetadata: StateFlow<RajaOngkirConfigMetadata> = rajaOngkirAdminRepo.listenConfigMetadata()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), RajaOngkirConfigMetadata(configured = true))

    private val _isTestingApiKey = MutableStateFlow(false)
    val isTestingApiKey: StateFlow<Boolean> = _isTestingApiKey.asStateFlow()

    private val _isSavingApiKey = MutableStateFlow(false)
    val isSavingApiKey: StateFlow<Boolean> = _isSavingApiKey.asStateFlow()

    fun testRajaOngkirApiKey(apiKey: String, onResult: (TestApiKeyResult) -> Unit) {
        viewModelScope.launch {
            val user = currentUser.value
            val role = user?.role ?: ""
            val userId = user?.userId ?: ""
            if (role != com.example.data.models.UserRole.ROOT_ADMIN.label) {
                showMessage("Akses ditolak: Hanya Root Admin yang dapat menguji API Key")
                return@launch
            }
            _isTestingApiKey.value = true
            val res = rajaOngkirAdminRepo.testApiKey(apiKey, userId, role)
            _isTestingApiKey.value = false
            res.fold(
                onSuccess = { testResult ->
                    onResult(testResult)
                },
                onFailure = { err ->
                    onResult(TestApiKeyResult.NetworkError(err.message ?: "Pengujian gagal."))
                }
            )
        }
    }

    fun saveRajaOngkirApiKey(apiKey: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val user = currentUser.value
            val role = user?.role ?: ""
            val userId = user?.userId ?: ""
            if (role != com.example.data.models.UserRole.ROOT_ADMIN.label) {
                showMessage("Akses ditolak: Hanya Root Admin yang dapat menyimpan API Key")
                onResult(false, "Akses ditolak: Hanya Root Admin yang dapat menyimpan API Key")
                return@launch
            }
            _isSavingApiKey.value = true
            val res = rajaOngkirAdminRepo.saveApiKey(apiKey, userId, role)
            _isSavingApiKey.value = false
            res.fold(
                onSuccess = {
                    showMessage("API Key berhasil diperbarui.")
                    onResult(true, null)
                },
                onFailure = { err ->
                    val msg = err.message ?: "Gagal memperbarui API Key"
                    showMessage(msg)
                    onResult(false, msg)
                }
            )
        }
    }

    // SALES ORDER
    fun createSalesOrder(
        customerId: String,
        customerName: String,
        phone: String,
        address: String,
        expedition: String,
        items: List<SoItem>,
        shippingCost: Long = 0L,
        shippingCourier: String = "",
        shippingServiceName: String = "",
        totalWeightInGrams: Int = 0,
        onDone: (SalesOrder?) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = soRepo.createSalesOrder(
                customerId = customerId,
                customerName = customerName,
                phone = phone,
                address = address,
                expedition = expedition,
                items = items,
                user = user,
                shippingCost = shippingCost,
                shippingCourier = shippingCourier,
                shippingServiceName = shippingServiceName,
                totalWeightInGrams = totalWeightInGrams
            )
            _isLoading.value = false
            res.fold(
                onSuccess = { so ->
                    showMessage("Sales Order ${so.soId} berhasil dibuat (Status: CONFIRMED)")
                    onDone(so)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal membuat Sales Order")
                    onDone(null)
                }
            )
        }
    }

    fun updateSalesOrder(
        soId: String,
        customerName: String,
        phone: String,
        address: String,
        expedition: String,
        items: List<SoItem>,
        shippingCost: Long = 0L,
        shippingCourier: String = "",
        shippingServiceName: String = "",
        totalWeightInGrams: Int = 0,
        onDone: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = soRepo.updateSalesOrder(
                soId = soId,
                customerName = customerName,
                phone = phone,
                address = address,
                expedition = expedition,
                items = items,
                user = user,
                shippingCost = shippingCost,
                shippingCourier = shippingCourier,
                shippingServiceName = shippingServiceName,
                totalWeightInGrams = totalWeightInGrams
            )
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Sales Order $soId berhasil diperbarui")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memperbarui SO")
                    onDone(false)
                }
            )
        }
    }

    fun markSoProcessing(soId: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val user = currentUser.value?.name ?: "Staff"
            val res = soRepo.markProcessing(soId, user)
            res.fold(
                onSuccess = {
                    showMessage("Status SO $soId diubah menjadi PROCESSING")
                    onDone(true)
                },
                onFailure = {
                    showMessage("Gagal update status SO: ${it.message}")
                    onDone(false)
                }
            )
        }
    }

    fun updateSoItems(soId: String, items: List<SoItem>, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = soRepo.updateSoItems(soId, items, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Item Sales Order $soId berhasil diperbarui")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memperbarui item SO")
                    onDone(false)
                }
            )
        }
    }

    fun markSoReadyToDeliver(soId: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val user = currentUser.value?.name ?: "Staff"
            val res = soRepo.markReadyToDeliver(soId, user)
            res.fold(
                onSuccess = {
                    showMessage("Status SO $soId diubah menjadi READY TO DELIVER")
                    onDone(true)
                },
                onFailure = {
                    showMessage("Gagal update status SO: ${it.message}")
                    onDone(false)
                }
            )
        }
    }

    fun cancelSalesOrder(soId: String, reason: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val user = currentUser.value?.name ?: "Staff"
            val res = soRepo.cancelSalesOrder(soId, reason, user)
            res.fold(
                onSuccess = {
                    showMessage("Sales Order $soId berhasil dibatalkan")
                    onDone(true)
                },
                onFailure = {
                    showMessage("Gagal membatalkan SO: ${it.message}")
                    onDone(false)
                }
            )
        }
    }

    // DELIVERY ORDER
    fun createDeliveryOrder(
        soId: String,
        onDone: (DeliveryOrder?) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val store = storeSettings.value
            val res = doRepo.createDeliveryOrder(soId, store.storeName, store.storePhone, store.getFullAddress(), user)
            _isLoading.value = false
            res.fold(
                onSuccess = { dOrder ->
                    showMessage("Delivery Order ${dOrder.doId} berhasil dibuat! Stock otomatis terpotong.")
                    onDone(dOrder)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal membuat Delivery Order")
                    onDone(null)
                }
            )
        }
    }

    // PRINTING
    fun testPrint(printerAddress: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val size = storeSettings.value.labelSize
            val res = printerService.printTest(printerAddress, size)
            _isLoading.value = false
            res.fold(
                onSuccess = { showMessage("Test Print berhasil dikirim ke printer") },
                onFailure = { showMessage(it.message ?: "Test Print gagal") }
            )
        }
    }

    fun printDeliveryOrder(dOrder: DeliveryOrder, printerAddress: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val size = storeSettings.value.labelSize
            val store = storeSettings.value
            val user = currentUser.value?.name?.takeIf { it.isNotBlank() }
                ?: currentUser.value?.email?.takeIf { it.isNotBlank() }
                ?: currentUser.value?.userId?.takeIf { it.isNotBlank() }
                ?: com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.displayName?.takeIf { it.isNotBlank() }
                ?: com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.email?.takeIf { it.isNotBlank() }
                ?: "-"
            val res = printerService.printDeliveryOrder(printerAddress, dOrder, size, store, user)
            _isLoading.value = false
            res.fold(
                onSuccess = { showMessage("Delivery Order ${dOrder.doId} berhasil dicetak") },
                onFailure = { showMessage(it.message ?: "Gagal mencetak DO") }
            )
        }
    }

    // INVENTORY ADJUSTMENT / BREAKAGE / RETURN
    fun adjustStock(sku: String, type: String, qty: Int, reason: String, notes: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = inventoryRepo.adjustStock(sku, type, qty, reason, notes, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Penyesuaian stok $sku ($type $qty) berhasil disimpan")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal melakukan penyesuaian stok")
                    onDone(false)
                }
            )
        }
    }

    fun executeAdjustment(adjustmentId: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name?.takeIf { it.isNotBlank() } ?: "Petugas Gudang"
            val res = inventoryRepo.executeAdjustment(adjustmentId, user)
            _isLoading.value = false
            res.fold(
                onSuccess = { adj ->
                    showMessage("Penyesuaian stok ${adj.sku} berhasil dieksekusi secara atomik! Stok produk telah diperbarui.")
                    onDone(true)
                },
                onFailure = { err ->
                    showMessage(err.message ?: "Gagal mengeksekusi penyesuaian stok")
                    onDone(false)
                }
            )
        }
    }

    fun recordBreakage(sku: String, qty: Int, reason: String, notes: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = inventoryRepo.recordBreakage(sku, qty, reason, notes, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Laporan kerusakan $sku ($qty pcs) berhasil disimpan. Stok telah dikurangi.")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal mencatat kerusakan")
                    onDone(false)
                }
            )
        }
    }

    fun recordReturn(
        ref: String,
        customer: String,
        sku: String,
        qty: Int,
        reason: String,
        condition: String,
        notes: String,
        onDone: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = inventoryRepo.recordReturn(ref, customer, sku, qty, reason, condition, notes, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Return dari $customer ($qty pcs) berhasil disimpan. Stok telah dikembalikan.")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memproses return")
                    onDone(false)
                }
            )
        }
    }

    fun recordSupplierReturn(
        ref: String,
        supplier: String,
        sku: String,
        qty: Int,
        reason: String,
        notes: String,
        onDone: (Boolean) -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val res = inventoryRepo.recordSupplierReturn(ref, supplier, sku, qty, reason, notes, user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Retur ke Supplier $supplier ($qty pcs) berhasil disimpan. Stok telah dipotong.")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal memproses retur supplier")
                    onDone(false)
                }
            )
        }
    }

    // PROMOTIONS
    fun addPromoPrice(sku: String, itemName: String, price: Long, start: String, end: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val res = promoRepo.addPromoPrice(sku, itemName, price, start, end)
            res.fold(
                onSuccess = {
                    showMessage("Promo harga untuk $sku berhasil ditambahkan")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal menambahkan promo")
                    onDone(false)
                }
            )
        }
    }

    fun togglePromoStatus(id: String, active: Boolean) {
        viewModelScope.launch {
            promoRepo.togglePromoStatus(id, active)
        }
    }

    fun deletePromo(id: String) {
        viewModelScope.launch {
            promoRepo.deletePromo(id)
            showMessage("Promo telah dihapus")
        }
    }

    // USERS
    fun createUser(userId: String, name: String, role: String, pass: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = userRepo.createUser(userId, name, role, pass)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("User ${it.userId} (${it.role}) berhasil didaftarkan")
                    onDone(true)
                },
                onFailure = {
                    showMessage(it.message ?: "Gagal membuat user")
                    onDone(false)
                }
            )
        }
    }

    fun updateUser(userId: String, name: String, role: String, newPass: String?, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val res = userRepo.updateUser(userId, name, role, newPass)
            res.fold(
                onSuccess = {
                    showMessage("Data user $userId berhasil disimpan")
                    onDone(true)
                },
                onFailure = {
                    showMessage("Gagal mengupdate user: ${it.message}")
                    onDone(false)
                }
            )
        }
    }

    fun toggleUserStatus(userId: String, active: Boolean) {
        viewModelScope.launch {
            val res = userRepo.toggleUserStatus(userId, active)
            res.fold(
                onSuccess = { showMessage("Status user $userId berhasil diubah") },
                onFailure = { showMessage(it.message ?: "Gagal mengubah status") }
            )
        }
    }

    fun deleteUser(userId: String) {
        viewModelScope.launch {
            val res = userRepo.deleteUser(userId)
            res.fold(
                onSuccess = { showMessage("User $userId telah dihapus") },
                onFailure = { showMessage(it.message ?: "Gagal menghapus user") }
            )
        }
    }

    // SETTINGS
    fun updateStoreSettings(newSettings: StoreSettings, onDone: (Boolean) -> Unit = {}) {
        val role = currentUser.value?.role ?: ""
        val user = currentUser.value?.name ?: "User"
        if (role != com.example.data.models.UserRole.ROOT_ADMIN.label) {
            showMessage("Hanya Root Admin yang berhak mengubah informasi dan alamat toko")
            onDone(false)
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            val res = settingsRepo.updateSettings(newSettings, userRole = role, user = user)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Informasi dan alamat toko berhasil disimpan")
                    onDone(true)
                },
                onFailure = {
                    showMessage("Gagal menyimpan pengaturan: ${it.message}")
                    onDone(false)
                }
            )
        }
    }

    // AUDIT
    suspend fun runDuplicateAudit(): Map<String, Any> {
        val skuAudit = productRepo.auditSkuDuplicates()
        val famAudit = familyRepo.auditFamilyDuplicates()
        return mapOf(
            "skuAudit" to skuAudit,
            "familyAudit" to famAudit
        )
    }

    // EXPORTS
    fun exportReport(title: String, headers: List<String>, rows: List<List<String>>) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = excelExporter.exportReport(title, headers, rows)
            _isLoading.value = false
            res.fold(
                onSuccess = { file ->
                    excelExporter.shareExportedFile(file, title)
                },
                onFailure = {
                    showMessage("Gagal mengekspor laporan: ${it.message}")
                }
            )
        }
    }

    // ==========================================
    // STOCK OPNAME LIFECYCLE & WORKFLOWS
    // ==========================================

    fun initializeStockOpname(notes: String = "", onDone: (StockOpname?) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Admin"
            val role = currentUser.value?.role ?: ""
            val activeMasterProducts = products.value
            val res = sopRepo.initializeStockOpname(user, role, notes, fallbackProducts = activeMasterProducts)
            _isLoading.value = false
            res.fold(
                onSuccess = { sop ->
                    showMessage("Stock Opname ${sop.documentNo} berhasil diinisialisasi")
                    onDone(sop)
                },
                onFailure = { err ->
                    showMessage(err.message ?: "Gagal inisialisasi Stock Opname")
                    onDone(null)
                }
            )
        }
    }

    fun saveItemCount(sopId: String, sku: String, physicalQty: Int, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val role = currentUser.value?.role ?: ""
            val res = sopRepo.saveItemCount(sopId, sku, physicalQty, user, role)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    onDone(true)
                },
                onFailure = { err ->
                    showMessage(err.message ?: "Gagal menyimpan count")
                    onDone(false)
                }
            )
        }
    }

    fun completeCounting(sopId: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Staff"
            val role = currentUser.value?.role ?: ""
            val res = sopRepo.completeCounting(sopId, user, role)
            _isLoading.value = false
            res.fold(
                onSuccess = { sop ->
                    showMessage("Stock Opname selesai dihitung! Dokumen ${sop.documentNo} telah dikunci.")
                    onDone(true)
                },
                onFailure = { err ->
                    showMessage(err.message ?: "Gagal menyelesaikan counting")
                    onDone(false)
                }
            )
        }
    }

    fun cancelStockOpname(sopId: String, reason: String = "Dibatalkan oleh user", onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Admin"
            val role = currentUser.value?.role ?: ""
            val res = sopRepo.cancelStockOpname(sopId, reason, user, role)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Stock Opname berhasil dibatalkan")
                    onDone(true)
                },
                onFailure = { err ->
                    showMessage(err.message ?: "Gagal membatalkan Stock Opname")
                    onDone(false)
                }
            )
        }
    }

    fun saveAdjustment(sopId: String, sku: String, newPhysicalQty: Int, reason: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Admin"
            val role = currentUser.value?.role ?: ""
            val res = sopRepo.saveAdjustment(sopId, sku, newPhysicalQty, reason, user, role)
            _isLoading.value = false
            res.fold(
                onSuccess = {
                    showMessage("Adjustment SKU $sku berhasil disimpan")
                    onDone(true)
                },
                onFailure = { err ->
                    showMessage(err.message ?: "Gagal menyimpan adjustment")
                    onDone(false)
                }
            )
        }
    }

    fun postStockOpname(sopId: String, onDone: (SopPosting?) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val user = currentUser.value?.name ?: "Admin"
            val role = currentUser.value?.role ?: ""
            val res = sopRepo.postStockOpname(sopId, user, role)
            _isLoading.value = false
            res.fold(
                onSuccess = { posting ->
                    showMessage("POSTING ${posting.documentNo} BERHASIL! Stok inventory telah diperbarui.")
                    onDone(posting)
                },
                onFailure = { err ->
                    showMessage(err.message ?: "Gagal posting Stock Opname")
                    onDone(null)
                }
            )
        }
    }

    fun generateAndShareSopPdf(sop: StockOpname) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = pdfSopGen.generateSopReportPdf(sop)
            _isLoading.value = false
            res.fold(
                onSuccess = { file ->
                    pdfSopGen.sharePdf(file)
                },
                onFailure = { err ->
                    showMessage("Gagal membuat PDF: ${err.message}")
                }
            )
        }
    }

    fun generateAndSharePostPdf(posting: SopPosting, sop: StockOpname?) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = pdfSopGen.generatePostReportPdf(posting, sop)
            _isLoading.value = false
            res.fold(
                onSuccess = { file ->
                    pdfSopGen.sharePdf(file)
                },
                onFailure = { err ->
                    showMessage("Gagal membuat PDF: ${err.message}")
                }
            )
        }
    }

    fun exportAndSharePostExcel(posting: SopPosting) {
        viewModelScope.launch {
            _isLoading.value = true
            val res = excelSopExp.exportPostReportExcel(posting)
            _isLoading.value = false
            res.fold(
                onSuccess = { file ->
                    excelSopExp.shareExcel(file)
                },
                onFailure = { err ->
                    showMessage("Gagal ekspor Excel: ${err.message}")
                }
            )
        }
    }

    fun getAuditTrails(documentNo: String? = null): Flow<List<AuditTrail>> {
        return sopRepo.listenAuditTrails(documentNo)
    }
}
