package com.example.ui.navigation

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.WmsViewModel
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.inventory.InventoryScreen
import com.example.ui.screens.more.MoreScreen
import com.example.ui.screens.opname.StockOpnameScreen
import com.example.ui.screens.purchase.PurchaseScreen
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.sales.CreateSalesOrderScreen
import com.example.ui.screens.sales.SalesScreen
import com.example.ui.theme.DustyPinkPrimary
import com.example.ui.theme.StatusDangerRed

sealed class BottomNavDestination(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : BottomNavDestination("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Sales : BottomNavDestination("sales", "Sales", Icons.Default.ShoppingCart)
    object Reports : BottomNavDestination("reports", "Laporan", Icons.Default.BarChart)
    object More : BottomNavDestination("more", "Lainnya", Icons.Default.Apps)
}

@Composable
fun WmsAppShell(viewModel: WmsViewModel) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val uiMessage by viewModel.uiMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var lastBackPressTime by remember { mutableLongStateOf(0L) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiMessage) {
        uiMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUiMessage()
        }
    }

    // Confirmation Logout Dialog
    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = {
                Text(
                    text = "Konfirmasi Logout",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = "Apakah Anda yakin ingin logout?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirmDialog = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                    modifier = Modifier.testTag("confirm_logout_button")
                ) {
                    Text("Logout")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showLogoutConfirmDialog = false },
                    modifier = Modifier.testTag("cancel_logout_button")
                ) {
                    Text("Batal")
                }
            }
        )
    }

    // Capture all gestures (taps, drags, scrolls) to continuously reset the 5-minute session timeout
    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        awaitPointerEvent(PointerEventPass.Initial)
                        viewModel.recordUserActivity()
                    }
                }
            }
    ) {
        if (currentUser == null) {
            // Back handler on login screen: double press required to exit
            BackHandler(enabled = true) {
                val now = System.currentTimeMillis()
                if (now - lastBackPressTime < 2000L) {
                    (context as? Activity)?.finish()
                } else {
                    lastBackPressTime = now
                    Toast.makeText(context, "Tekan sekali lagi untuk keluar", Toast.LENGTH_SHORT).show()
                }
            }

            LoginScreen(
                viewModel = viewModel,
                onLoginSuccess = {}
            )
        } else {
            var currentTab by remember { mutableStateOf<BottomNavDestination>(BottomNavDestination.Dashboard) }
            var currentSubScreen by remember { mutableStateOf<String?>(null) }
            // "CREATE_SO", "INVENTORY", "PURCHASE"

            // Comprehensive BackHandler:
            // 1. Sub-screen -> pop back to current tab
            // 2. Non-Dashboard tab -> go to Dashboard tab
            // 3. Root Dashboard -> show Toast "Tekan sekali lagi untuk keluar", exit if pressed twice in 2000ms
            BackHandler(enabled = true) {
                when {
                    currentSubScreen != null -> {
                        currentSubScreen = null
                    }
                    currentTab != BottomNavDestination.Dashboard -> {
                        currentTab = BottomNavDestination.Dashboard
                    }
                    else -> {
                        val now = System.currentTimeMillis()
                        if (now - lastBackPressTime < 2000L) {
                            (context as? Activity)?.finish()
                        } else {
                            lastBackPressTime = now
                            Toast.makeText(context, "Tekan sekali lagi untuk keluar", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }

            Scaffold(
                snackbarHost = { SnackbarHost(snackbarHostState) },
                bottomBar = {
                    if (currentSubScreen == null) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = DustyPinkPrimary
                        ) {
                            val navItems = listOf(
                                BottomNavDestination.Dashboard,
                                BottomNavDestination.Sales,
                                BottomNavDestination.Reports,
                                BottomNavDestination.More
                            )

                            navItems.forEach { item ->
                                val isSelected = currentTab.route == item.route
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = {
                                        currentTab = item
                                        currentSubScreen = null
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = item.title
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = item.title,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = DustyPinkPrimary,
                                        selectedTextColor = DustyPinkPrimary,
                                        indicatorColor = DustyPinkPrimary.copy(alpha = 0.12f)
                                    ),
                                    modifier = Modifier.testTag("nav_item_${item.route}")
                                )
                            }
                        }
                    }
                }
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    when {
                        currentSubScreen == "CREATE_SO" -> {
                            CreateSalesOrderScreen(
                                viewModel = viewModel,
                                onBack = { currentSubScreen = null },
                                onSuccess = { currentSubScreen = null }
                            )
                        }
                        currentSubScreen == "INVENTORY" -> {
                            InventoryScreen(
                                viewModel = viewModel,
                                onNavigateBack = { currentSubScreen = null }
                            )
                        }
                        currentSubScreen == "PURCHASE" -> {
                            PurchaseScreen(
                                viewModel = viewModel,
                                onNavigateBack = { currentSubScreen = null }
                            )
                        }
                        currentSubScreen == "STOCK_OPNAME" -> {
                            StockOpnameScreen(
                                viewModel = viewModel,
                                onNavigateBack = { currentSubScreen = null }
                            )
                        }
                        currentTab == BottomNavDestination.Dashboard -> {
                            DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToSales = { currentTab = BottomNavDestination.Sales },
                                onNavigateToInventory = { currentSubScreen = "INVENTORY" },
                                onNavigateToPurchase = { currentSubScreen = "PURCHASE" },
                                onNavigateToStockOpname = { currentSubScreen = "STOCK_OPNAME" },
                                onRequestLogout = { showLogoutConfirmDialog = true }
                            )
                        }
                        currentTab == BottomNavDestination.Sales -> {
                            SalesScreen(
                                viewModel = viewModel,
                                onCreateSoClick = { currentSubScreen = "CREATE_SO" }
                            )
                        }
                        currentTab == BottomNavDestination.Reports -> {
                            ReportsScreen(
                                viewModel = viewModel
                            )
                        }
                        currentTab == BottomNavDestination.More -> {
                            MoreScreen(
                                viewModel = viewModel,
                                onNavigateToInventory = { currentSubScreen = "INVENTORY" },
                                onNavigateToPurchase = { currentSubScreen = "PURCHASE" },
                                onNavigateToStockOpname = { currentSubScreen = "STOCK_OPNAME" }
                            )
                        }
                    }
                }
            }
        }
    }
}
