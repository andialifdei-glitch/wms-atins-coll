package com.example.ui.screens.sales

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.DeliveryOrder
import com.example.data.models.Product
import com.example.data.models.SalesOrder
import com.example.data.models.SoItem
import com.example.ui.WmsViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingDialog
import com.example.ui.components.SearchBarField
import com.example.ui.components.WmsTopBar
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesScreen(
    viewModel: WmsViewModel,
    onCreateSoClick: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Sales Order, 1 = Delivery Order
    var searchQuery by remember { mutableStateOf("") }
    var selectedSoIdForDetail by remember { mutableStateOf<String?>(null) }
    var selectedDoForDetail by remember { mutableStateOf<DeliveryOrder?>(null) }
    var soStatusFilter by remember { mutableIntStateOf(0) } // 0 = Semua, 1 = Confirmed, 2 = Processing, 3 = Ready to Deliver, 4 = Selesai (DO), 5 = Batal
    val isOnline by viewModel.isOnline.collectAsState()

    val salesOrders by viewModel.salesOrders.collectAsState()
    val deliveryOrders by viewModel.deliveryOrders.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    if (isLoading) {
        LoadingDialog("Memproses transaksi...")
    }

    // Sub-screen: SO Detail
    val activeSoForDetail = salesOrders.find { it.soId == selectedSoIdForDetail }
    if (activeSoForDetail != null) {
        SalesOrderDetailView(
            so = activeSoForDetail,
            viewModel = viewModel,
            onBack = { selectedSoIdForDetail = null }
        )
        return
    }

    // Sub-screen: DO Detail
    if (selectedDoForDetail != null) {
        DeliveryOrderDetailView(
            doOrder = selectedDoForDetail!!,
            viewModel = viewModel,
            onBack = { selectedDoForDetail = null }
        )
        return
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Sales & Pengiriman",
                isOnline = isOnline
            )
        },
        floatingActionButton = {
            if (selectedTab == 0) {
                FloatingActionButton(
                    onClick = onCreateSoClick,
                    containerColor = DustyPinkPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_create_so")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Buat Sales Order")
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Tab Selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = DustyPinkPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "Sales Order (${salesOrders.size})",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    modifier = Modifier.testTag("tab_sales_order")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "Delivery Order (${deliveryOrders.size})",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    modifier = Modifier.testTag("tab_delivery_order")
                )
            }

            // SO Status Filter Tabs (Section A3)
            if (selectedTab == 0) {
                val statusTabs = listOf("Semua", "Confirmed", "Processing", "Ready to Deliver", "Selesai", "Batal")
                ScrollableTabRow(
                    selectedTabIndex = soStatusFilter,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = DustyPinkPrimary
                ) {
                    statusTabs.forEachIndexed { index, label ->
                        val count = when (index) {
                            1 -> salesOrders.count { it.status == "CONFIRMED" }
                            2 -> salesOrders.count { it.status == "PROCESSING" }
                            3 -> salesOrders.count { it.status == "READY TO DELIVER" }
                            4 -> salesOrders.count { it.status == "DELIVERY ORDER" }
                            5 -> salesOrders.count { it.status == "CANCELLED" }
                            else -> salesOrders.size
                        }
                        Tab(
                            selected = soStatusFilter == index,
                            onClick = { soStatusFilter = index },
                            text = { Text("$label ($count)") },
                            modifier = Modifier.testTag("so_status_tab_$index")
                        )
                    }
                }
            }

            // Search Bar
            PaddingValues(16.dp).let {
                Box(modifier = Modifier.padding(16.dp)) {
                    SearchBarField(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        placeholder = if (selectedTab == 0) "Cari nomor SO, customer..." else "Cari nomor DO, penerima...",
                        testTag = "sales_search_bar"
                    )
                }
            }

            // Tab Content
            if (selectedTab == 0) {
                val filteredSos = salesOrders.filter { so ->
                    val matchesStatus = when (soStatusFilter) {
                        1 -> so.status == "CONFIRMED"
                        2 -> so.status == "PROCESSING"
                        3 -> so.status == "READY TO DELIVER"
                        4 -> so.status == "DELIVERY ORDER"
                        5 -> so.status == "CANCELLED"
                        else -> true
                    }
                    val matchesQuery = so.soId.contains(searchQuery, ignoreCase = true) ||
                        so.customerName.contains(searchQuery, ignoreCase = true) ||
                        so.status.contains(searchQuery, ignoreCase = true)
                    matchesStatus && matchesQuery
                }

                if (filteredSos.isEmpty()) {
                    EmptyStateView(
                        title = if (searchQuery.isEmpty()) "Belum ada Sales Order" else "Tidak ada SO yang cocok",
                        description = if (searchQuery.isEmpty()) "Buat Sales Order baru untuk mencatat pesanan pelanggan" else null,
                        actionButtonText = if (searchQuery.isEmpty()) "+ Buat Sales Order" else null,
                        onActionClick = if (searchQuery.isEmpty()) onCreateSoClick else null
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        items(filteredSos, key = { it.soId }) { so ->
                            SalesOrderCard(
                                so = so,
                                onClick = { selectedSoIdForDetail = so.soId }
                            )
                        }
                    }
                }
            } else {
                val filteredDos = deliveryOrders.filter {
                    it.doId.contains(searchQuery, ignoreCase = true) ||
                    it.soId.contains(searchQuery, ignoreCase = true) ||
                    it.recipientName.contains(searchQuery, ignoreCase = true) ||
                    it.expedition.contains(searchQuery, ignoreCase = true)
                }

                if (filteredDos.isEmpty()) {
                    EmptyStateView(
                        title = if (searchQuery.isEmpty()) "Belum ada Delivery Order" else "Tidak ada DO yang cocok",
                        description = "Delivery Order dibuat dari Sales Order yang sudah berstatus READY TO DELIVER"
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        items(filteredDos, key = { it.doId }) { doOrder ->
                            DeliveryOrderCard(
                                doOrder = doOrder,
                                onClick = { selectedDoForDetail = doOrder }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SalesOrderCard(so: SalesOrder, onClick: () -> Unit) {
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    val (statusBg, statusFg) = when (so.status) {
        "READY TO DELIVER" -> StatusWarningOrange.copy(alpha = 0.15f) to StatusWarningOrange
        "DELIVERY ORDER" -> StatusSuccessGreen.copy(alpha = 0.15f) to StatusSuccessGreen
        "CANCELLED" -> StatusDangerRed.copy(alpha = 0.15f) to StatusDangerRed
        else -> DustyPinkPrimary.copy(alpha = 0.15f) to DustyPinkPrimary
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("so_card_${so.soId}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = so.soId,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = DustyPinkPrimary
                )
                Surface(
                    color = statusBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = so.status,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = statusFg,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = so.customerName,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = "${so.items.size} item (${so.items.sumOf { it.qty }} pcs) • Ekspedisi: ${so.expedition.ifBlank { "Standar" }}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = so.date,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
                Text(
                    text = rupiahFormat.format(so.total),
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun DeliveryOrderCard(doOrder: DeliveryOrder, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("do_card_${doOrder.doId}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = doOrder.doId,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = StatusBlue
                )
                Surface(
                    color = StatusSuccessGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "TERKIRIM (STOK -)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = StatusSuccessGreen,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Penerima: ${doOrder.recipientName} (${doOrder.recipientPhone})",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = "SO: ${doOrder.soId} • Ekspedisi: ${doOrder.expedition}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(
                text = "Isi: ${doOrder.totalItems} item / ${doOrder.totalPcs} pcs",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = doOrder.date,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }
    }
}

@Composable
fun SalesOrderDetailView(
    so: SalesOrder,
    viewModel: WmsViewModel,
    onBack: () -> Unit
) {
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    val context = LocalContext.current
    val isLoading by viewModel.isLoading.collectAsState()
    var showCancelDialog by remember { mutableStateOf(false) }
    var cancelReason by remember { mutableStateOf("") }
    var cancelError by remember { mutableStateOf<String?>(null) }
    var showEditItemsDialog by remember { mutableStateOf(false) }
    val products by viewModel.products.collectAsState()

    val scrollState = rememberScrollState()

    androidx.activity.compose.BackHandler(onBack = onBack)

    if (showEditItemsDialog) {
        EditSoItemsDialog(
            so = so,
            products = products,
            onSave = { updatedItems ->
                viewModel.updateSoItems(so.soId, updatedItems) { success ->
                    if (success) {
                        showEditItemsDialog = false
                    }
                }
            },
            onDismiss = { showEditItemsDialog = false }
        )
    }

    // Cancel SO Dialog per section 39 & 40:
    // "Tombol harus menggunakan tulisan: Batalkan. Saat ditekan: Batalkan Sales Order? Alasan pembatalan: [.....] [ Kembali ] [ Batalkan ]"
    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = {
                Text(
                    text = "Batalkan Sales Order?",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column {
                    Text(
                        text = "Nomor SO: ${so.soId}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Alasan pembatalan (wajib):",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = cancelReason,
                        onValueChange = {
                            cancelReason = it
                            cancelError = null
                        },
                        placeholder = { Text("Contoh: Customer membatalkan pesanan") },
                        singleLine = false,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_cancel_reason_input")
                    )
                    if (cancelError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = cancelError!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (cancelReason.trim().isBlank()) {
                            cancelError = "Alasan pembatalan harus diisi"
                            return@Button
                        }
                        viewModel.cancelSalesOrder(so.soId, cancelReason) { success ->
                            if (success) {
                                showCancelDialog = false
                                onBack()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                    modifier = Modifier.testTag("dialog_confirm_cancel_button")
                ) {
                    Text("Batalkan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) {
                    Text("Kembali")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Detail ${so.soId}",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Customer & Shipping Info
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Informasi Customer",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            color = when (so.status) {
                                "READY TO DELIVER" -> StatusWarningOrange.copy(alpha = 0.15f)
                                "DELIVERY ORDER" -> StatusSuccessGreen.copy(alpha = 0.15f)
                                "CANCELLED" -> StatusDangerRed.copy(alpha = 0.15f)
                                else -> DustyPinkPrimary.copy(alpha = 0.15f)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = so.status,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = when (so.status) {
                                    "READY TO DELIVER" -> StatusWarningOrange
                                    "DELIVERY ORDER" -> StatusSuccessGreen
                                    "CANCELLED" -> StatusDangerRed
                                    else -> DustyPinkPrimary
                                },
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Nama: ${so.customerName}", style = MaterialTheme.typography.bodyMedium)
                    Text(text = "Telepon: ${so.phone}", style = MaterialTheme.typography.bodyMedium)
                    Text(text = "Alamat: ${so.address}", style = MaterialTheme.typography.bodyMedium)
                    Text(text = "Ekspedisi: ${so.expedition}", style = MaterialTheme.typography.bodyMedium)
                    Text(text = "Tanggal: ${so.date}", style = MaterialTheme.typography.bodyMedium)

                    if (so.cancelReason.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Alasan Dibatalkan: ${so.cancelReason}",
                            style = MaterialTheme.typography.bodyMedium.copy(color = StatusDangerRed)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Items List
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Daftar Barang Pesanan",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                if (so.status == "CONFIRMED") {
                    TextButton(
                        onClick = { showEditItemsDialog = true },
                        modifier = Modifier.testTag("so_edit_items_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tambah / Ubah Item")
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    so.items.forEachIndexed { index, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.itemName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = "${item.sku} • ${item.qty} pcs x ${rupiahFormat.format(item.price)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = rupiahFormat.format(item.subtotal),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        if (index < so.items.size - 1) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = BorderLight)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = BorderLight)

                    val subtotalProd = so.items.sumOf { it.subtotal }
                    val weightGrams = if (so.totalWeightInGrams > 0) so.totalWeightInGrams else so.items.sumOf { it.qty * it.weightInGrams }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Subtotal Produk", style = MaterialTheme.typography.bodyMedium)
                        Text(text = rupiahFormat.format(subtotalProd), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Total Berat", style = MaterialTheme.typography.bodyMedium)
                        Text(text = "$weightGrams gram", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val serviceLabel = so.shippingServiceName.ifBlank { so.expedition.ifBlank { "None" } }
                        Text(text = "Ongkir ($serviceLabel)", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = if (so.shippingCost > 0L) rupiahFormat.format(so.shippingCost) else "Rp 0",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = if (so.shippingCost > 0L) StatusSuccessGreen else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = BorderLight)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "TOTAL SALES ORDER",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = rupiahFormat.format(so.total),
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = DustyPinkPrimary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            // 1. WhatsApp Share with complete item detail, shipping, and total
            OutlinedButton(
                onClick = {
                    val sb = StringBuilder()
                    sb.append("*SALES ORDER*\n")
                    sb.append("${so.soId}\n\n")
                    sb.append("Customer: ${so.customerName}\n")
                    if (so.address.isNotBlank()) {
                        sb.append("Alamat: ${so.address}\n\n")
                    } else {
                        sb.append("\n")
                    }

                    var totalQty = 0
                    so.items.forEachIndexed { idx, item ->
                        totalQty += item.qty
                        sb.append("${idx + 1}. ${item.itemName}\n")
                        sb.append("   Qty: ${item.qty} pcs\n")
                        sb.append("   Harga: ${rupiahFormat.format(item.price)}\n")
                        sb.append("   Subtotal: ${rupiahFormat.format(item.subtotal)}\n\n")
                    }
                    sb.append("-------------------------\n")
                    sb.append("Total Item: $totalQty pcs\n")
                    val totalW = if (so.totalWeightInGrams > 0) so.totalWeightInGrams else so.items.sumOf { it.qty * it.weightInGrams }
                    if (totalW > 0) {
                        sb.append("Total Berat: $totalW gram\n")
                    }
                    val subProd = so.items.sumOf { it.subtotal }
                    sb.append("Subtotal Produk: ${rupiahFormat.format(subProd)}\n")

                    if (so.shippingCost > 0L || so.shippingServiceName.isNotBlank()) {
                        val sName = so.shippingServiceName.ifBlank { so.expedition }
                        sb.append("Jasa Kirim: $sName\n")
                        sb.append("Ongkos Kirim: ${rupiahFormat.format(so.shippingCost)}\n")
                    } else if (so.expedition.isNotBlank() && !so.expedition.equals("None", ignoreCase = true)) {
                        sb.append("Ekspedisi: ${so.expedition}\n")
                    }

                    sb.append("Total Tagihan: ${rupiahFormat.format(so.total)}\n")

                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, sb.toString())
                    }
                    val shareChooser = Intent.createChooser(sendIntent, "Bagikan ke WhatsApp...")
                    context.startActivity(shareChooser)
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusSuccessGreen),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("so_whatsapp_share_button")
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Share via WhatsApp")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Lifecycle buttons (A3 & A4)
            if (so.status == "CONFIRMED") {
                Button(
                    onClick = {
                        viewModel.markSoProcessing(so.soId) { success ->
                            if (success) onBack()
                        }
                    },
                    enabled = !isLoading,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("so_processing_button")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Processing")
                }
            }

            if (so.status == "PROCESSING") {
                Button(
                    onClick = {
                        viewModel.markSoReadyToDeliver(so.soId) { success ->
                            if (success) onBack()
                        }
                    },
                    enabled = !isLoading,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusWarningOrange),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("so_ready_to_deliver_button")
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ready to Deliver")
                }
            }

            if (so.status == "READY TO DELIVER") {
                Button(
                    onClick = {
                        viewModel.createDeliveryOrder(so.soId) { createdDo ->
                            if (createdDo != null) onBack()
                        }
                    },
                    enabled = !isLoading,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("so_create_do_button")
                ) {
                    Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isLoading) "Memproses DO & Stok..." else "Create DO (Potong Stok)")
                }
            }

            // Cancel SO button per Section 39:
            // "Tombol harus menggunakan tulisan: Batalkan. Jangan hanya icon."
            if (so.status != "CANCELLED" && so.status != "DELIVERY ORDER") {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { showCancelDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDangerRed),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("so_cancel_button")
                ) {
                    Icon(imageVector = Icons.Default.Cancel, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Batalkan")
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun DeliveryOrderDetailView(
    doOrder: DeliveryOrder,
    viewModel: WmsViewModel,
    onBack: () -> Unit
) {
    val pairedPrinters by viewModel.pairedPrinters.collectAsState()
    val storeSettings by viewModel.storeSettings.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    var selectedPrinterAddress by remember {
        mutableStateOf(storeSettings.defaultPrinterAddress.ifBlank { pairedPrinters.firstOrNull()?.address ?: "" })
    }

    val scrollState = rememberScrollState()
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    androidx.activity.compose.BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Detail ${doOrder.doId}",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Preview Label DO Pengiriman (Format Resmi DO Pengiriman)
            val labelData = remember(doOrder, storeSettings, currentUser) {
                com.example.data.models.DoShippingLabelData.fromDeliveryOrder(
                    doOrder = doOrder,
                    storeSettings = storeSettings,
                    userAccount = currentUser
                )
            }

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("do_shipping_label_preview")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "DELIVERY ORDER",
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "DO : ${labelData.doNumber}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Ekspedisi : ${labelData.shippingService}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderLight)

                    Text(
                        text = "PENGIRIM",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = labelData.senderName,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "NO HANDPHONE",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = labelData.senderPhone,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderLight)

                    Text(
                        text = "PENERIMA",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = labelData.recipientName,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "ALAMAT",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = labelData.recipientAddress,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "NO HANDPHONE",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = labelData.recipientPhone,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderLight)

                    Text(
                        text = "SO : ${labelData.soNumber}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tanggal Cetak : ${labelData.printDate}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "By : ${labelData.printedBy}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Thermal Printer Selection
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Cetak DO ke Thermal Printer",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        IconButton(onClick = { viewModel.refreshPrinters() }) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Segarkan Printer")
                        }
                    }

                    if (pairedPrinters.isEmpty()) {
                        Text(
                            text = "Tidak ada printer Bluetooth yang terpasang (paired). Pasangkan printer thermal Anda di menu Bluetooth Android terlebih dahulu.",
                            style = MaterialTheme.typography.bodySmall,
                            color = StatusDangerRed
                        )
                    } else {
                        Text(
                            text = "Pilih Printer:",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        pairedPrinters.forEach { p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { selectedPrinterAddress = p.address }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedPrinterAddress == p.address,
                                    onClick = { selectedPrinterAddress = p.address }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = p.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = p.address,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (selectedPrinterAddress.isBlank()) {
                                viewModel.showMessage("Harap pilih printer thermal Bluetooth terlebih dahulu")
                                return@Button
                            }
                            viewModel.printDeliveryOrder(doOrder, selectedPrinterAddress)
                        },
                        enabled = selectedPrinterAddress.isNotBlank(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("print_do_submit_button")
                    ) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("CETAK DELIVERY ORDER")
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun EditSoItemsDialog(
    so: SalesOrder,
    products: List<Product>,
    onSave: (List<SoItem>) -> Unit,
    onDismiss: () -> Unit
) {
    val items = remember { mutableStateListOf<SoItem>().apply { addAll(so.items) } }
    var showProductSearch by remember { mutableStateOf(false) }
    var productSearchQuery by remember { mutableStateOf("") }
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Tambah / Ubah Item SO",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                Text(
                    text = "Harga satuan yang diubah di sini adalah snapshot khusus untuk Sales Order ini dan tidak mengubah harga Master Product.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Product Search & Add Section
                if (!showProductSearch) {
                    OutlinedButton(
                        onClick = { showProductSearch = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("+ Tambah Produk ke SO")
                    }
                } else {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Pilih Produk", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                IconButton(onClick = { showProductSearch = false }, modifier = Modifier.size(24.dp)) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = productSearchQuery,
                                onValueChange = { productSearchQuery = it },
                                placeholder = { Text("Cari SKU / nama...") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            val matches = products.filter {
                                (it.sku.contains(productSearchQuery, ignoreCase = true) ||
                                it.itemName.contains(productSearchQuery, ignoreCase = true)) &&
                                it.isProductActive
                            }.take(5)

                            if (matches.isEmpty()) {
                                Text("Produk tidak ditemukan atau belum memiliki berat valid", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            } else {
                                matches.forEach { p ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable {
                                                val existingIdx = items.indexOfFirst { it.sku == p.sku }
                                                if (existingIdx >= 0) {
                                                    val cur = items[existingIdx]
                                                    items[existingIdx] = cur.copy(
                                                        qty = cur.qty + 1,
                                                        subtotal = (cur.qty + 1) * cur.price
                                                    )
                                                } else {
                                                    items.add(
                                                        SoItem(
                                                            sku = p.sku,
                                                            itemName = p.itemName,
                                                            qty = 1,
                                                            price = p.netPrice,
                                                            subtotal = p.netPrice,
                                                            purchasingPriceSnapshot = p.purchasingPrice,
                                                            weightInGrams = p.weightInGrams
                                                        )
                                                    )
                                                }
                                                showProductSearch = false
                                                productSearchQuery = ""
                                            }
                                            .padding(vertical = 6.dp, horizontal = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(p.itemName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                            Text("${p.sku} • Stok: ${p.stock}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                        }
                                        Text(rupiahFormat.format(p.netPrice), style = MaterialTheme.typography.bodySmall, color = DustyPinkPrimary, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Daftar Item Saat Ini:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                items.forEachIndexed { index, item ->
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.itemName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("SKU: ${item.sku}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                }
                                if (items.size > 1) {
                                    IconButton(
                                        onClick = { items.removeAt(index) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus", tint = StatusDangerRed)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = item.qty.toString(),
                                    onValueChange = { input ->
                                        val newQty = input.filter { it.isDigit() }.toIntOrNull() ?: 1
                                        val validQty = if (newQty < 1) 1 else newQty
                                        items[index] = item.copy(
                                            qty = validQty,
                                            subtotal = validQty * item.price
                                        )
                                    },
                                    label = { Text("Qty") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedTextField(
                                    value = item.price.toString(),
                                    onValueChange = { input ->
                                        val newPrice = input.filter { it.isDigit() }.toLongOrNull() ?: 0L
                                        items[index] = item.copy(
                                            price = newPrice,
                                            subtotal = item.qty * newPrice
                                        )
                                    },
                                    label = { Text("Harga SO (Rp)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1.5f)
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Subtotal: ${rupiahFormat.format(item.subtotal)}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = DustyPinkPrimary,
                                modifier = Modifier.align(Alignment.End)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                val totalOrder = items.sumOf { it.subtotal }
                Text(
                    text = "Total Baru: ${rupiahFormat.format(totalOrder)}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = DustyPinkPrimary)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (items.isNotEmpty()) {
                        onSave(items.toList())
                    }
                },
                enabled = items.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                modifier = Modifier.testTag("save_edited_so_items_btn")
            ) {
                Text("Simpan Perubahan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
