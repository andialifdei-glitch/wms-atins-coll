package com.example.ui.screens.more

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Customer
import com.example.data.models.PromoPrice
import com.example.data.models.Region
import com.example.data.models.ShippingService
import com.example.data.models.StoreSettings
import com.example.data.models.UserAccount
import com.example.data.models.UserRole
import com.example.ui.WmsViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingDialog
import com.example.ui.components.SearchBarField
import com.example.ui.components.WmsTopBar
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@Composable
fun MoreScreen(
    viewModel: WmsViewModel,
    onNavigateToInventory: () -> Unit,
    onNavigateToPurchase: () -> Unit,
    onNavigateToStockOpname: () -> Unit
) {
    var subScreen by remember { mutableStateOf<String?>(null) }
    // null = Main Menu, "MASTER", "PROMO", "USERS", "SETTINGS"

    val isOnline by viewModel.isOnline.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    androidx.activity.compose.BackHandler(enabled = subScreen != null) {
        subScreen = null
    }

    when (subScreen) {
        "MASTER" -> MasterManagementScreen(viewModel = viewModel, onBack = { subScreen = null })
        "PROMO" -> PromoPriceScreen(viewModel = viewModel, onBack = { subScreen = null })
        "USERS" -> UserManagementScreen(viewModel = viewModel, onBack = { subScreen = null })
        "SETTINGS" -> SettingsAndPrinterScreen(viewModel = viewModel, onNavigateToRajaOngkir = { subScreen = "RAJAONGKIR" }, onBack = { subScreen = null })
        "RAJAONGKIR" -> RajaOngkirApiScreen(viewModel = viewModel, onBack = { subScreen = "SETTINGS" })
        else -> {
            Scaffold(
                topBar = {
                    WmsTopBar(
                        title = "Menu Lainnya",
                        isOnline = isOnline
                    )
                }
            ) { paddingValues ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Manajemen Operasional Gudang",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    MoreMenuItem(
                        title = "Inventory & Persediaan",
                        subtitle = "Produk, Stok Fisik, Family, Stock Adjustment, Return, Breakage",
                        icon = Icons.Default.Inventory2,
                        accentColor = DustyPinkPrimary,
                        onClick = onNavigateToInventory,
                        testTag = "menu_inventory"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    MoreMenuItem(
                        title = "Purchase & Penerimaan (Receiving)",
                        subtitle = "Purchase Order ke Supplier & Proses Receiving Barang",
                        icon = Icons.Default.ShoppingBag,
                        accentColor = StatusBlue,
                        onClick = onNavigateToPurchase,
                        testTag = "menu_purchase"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    MoreMenuItem(
                        title = "Stock Opname",
                        subtitle = "Penghitungan fisik (counting), adjustment selisih & posting audit",
                        icon = Icons.Default.Checklist,
                        accentColor = DustyPinkPrimary,
                        onClick = onNavigateToStockOpname,
                        testTag = "menu_stock_opname"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    MoreMenuItem(
                        title = "Data Master",
                        subtitle = "Pelanggan (Customer) & Layanan Ekspedisi Pengiriman",
                        icon = Icons.Default.FolderShared,
                        accentColor = StatusPurple,
                        onClick = { subScreen = "MASTER" },
                        testTag = "menu_master"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    MoreMenuItem(
                        title = "Promo Price (Harga Promo)",
                        subtitle = "Kelola harga diskon/promo terpisah dari master produk",
                        icon = Icons.Default.LocalOffer,
                        accentColor = StatusWarningOrange,
                        onClick = { subScreen = "PROMO" },
                        testTag = "menu_promo"
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "Sistem & Administrasi",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    if (currentUser?.role == UserRole.ROOT_ADMIN.label || currentUser?.role == UserRole.ADMIN_GUDANG.label) {
                        MoreMenuItem(
                            title = "User Management (Kelola Pengguna)",
                            subtitle = "Tambah staf gudang, atur hak akses & status user",
                            icon = Icons.Default.ManageAccounts,
                            accentColor = DustyPinkPrimary,
                            onClick = { subScreen = "USERS" },
                            testTag = "menu_users"
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    MoreMenuItem(
                        title = "Pengaturan Printer & Toko",
                        subtitle = "Koneksi thermal Bluetooth, ukuran kertas, tes print & audit database",
                        icon = Icons.Default.Settings,
                        accentColor = SoftSecondary,
                        onClick = { subScreen = "SETTINGS" },
                        testTag = "menu_settings"
                    )

                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}

@Composable
fun MoreMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// -------------------------------------------------------------
// MASTER SCREEN (CUSTOMER & EXPEDITION)
// -------------------------------------------------------------
@Composable
fun MasterManagementScreen(
    viewModel: WmsViewModel,
    onBack: () -> Unit
) {
    var tabIndex by remember { mutableIntStateOf(0) } // 0 = Customer, 1 = Expedition
    val customers by viewModel.customers.collectAsState()
    val shippingServices by viewModel.shippingServices.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isRootAdmin = currentUser?.role == UserRole.ROOT_ADMIN.label

    var showAddCustDialog by remember { mutableStateOf(false) }
    var showAddExpDialog by remember { mutableStateOf(false) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }
    var expeditionToDelete by remember { mutableStateOf<ShippingService?>(null) }
    var expeditionDeleteCountdown by remember { mutableIntStateOf(10) }
    var expeditionToEdit by remember { mutableStateOf<ShippingService?>(null) }

    LaunchedEffect(expeditionToDelete) {
        if (expeditionToDelete != null) {
            expeditionDeleteCountdown = 10
            while (expeditionDeleteCountdown > 0) {
                kotlinx.coroutines.delay(1000)
                expeditionDeleteCountdown--
            }
        }
    }

    if (showAddCustDialog) {
        AddCustomerDialog(viewModel = viewModel, onDismiss = { showAddCustDialog = false })
    }
    if (showAddExpDialog) {
        AddExpeditionDialog(viewModel = viewModel, onDismiss = { showAddExpDialog = false })
    }

    // Customer Delete Confirmation (Section G)
    if (customerToDelete != null) {
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = { Text("Hapus Customer?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Data customer '${customerToDelete?.customerName}' ini akan dihapus.\nApakah Anda yakin?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val id = customerToDelete!!.customerId
                        customerToDelete = null
                        viewModel.deleteCustomer(id)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Hapus")
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToDelete = null }) {
                    Text("Batal")
                }
            }
        )
    }

    // Ekspedisi Delete Confirmation with 10s Countdown (Section N1)
    if (expeditionToDelete != null) {
        AlertDialog(
            onDismissRequest = { expeditionToDelete = null },
            title = { Text("Hapus Ekspedisi?", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Data ekspedisi '${expeditionToDelete?.name}' akan dihapus.")
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Tindakan ini tidak dapat dibatalkan.", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            },
            confirmButton = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { expeditionToDelete = null },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Batal")
                    }
                    Button(
                        onClick = {
                            val id = expeditionToDelete!!.shippingServiceId
                            expeditionToDelete = null
                            viewModel.deleteShippingService(id)
                        },
                        enabled = expeditionDeleteCountdown == 0,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (expeditionDeleteCountdown > 0) "Hapus ($expeditionDeleteCountdown)" else "Hapus")
                    }
                }
            },
            dismissButton = null
        )
    }

    // Edit Ekspedisi (Section N2 & N3 - Root Admin only)
    if (expeditionToEdit != null) {
        var editName by remember { mutableStateOf(expeditionToEdit!!.name) }
        var selectedService by remember { mutableStateOf("Reguler") }
        val servicesList = listOf("Hemat", "Reguler", "Ekonomis", "Ekspress", "Jagopack", "None")

        AlertDialog(
            onDismissRequest = { expeditionToEdit = null },
            title = { Text("Edit Ekspedisi", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Nama Ekspedisi") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Service Ekspedisi:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    servicesList.forEach { svc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedService = svc }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selectedService == svc, onClick = { selectedService = svc })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = svc, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editName.isNotBlank()) {
                            val id = expeditionToEdit!!.shippingServiceId
                            val finalName = if (selectedService == "None" || selectedService.isBlank()) editName.trim() else "${editName.trim()} - $selectedService"
                            expeditionToEdit = null
                            viewModel.updateShippingService(id, finalName) { }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
                ) {
                    Text("Simpan")
                }
            },
            dismissButton = {
                TextButton(onClick = { expeditionToEdit = null }) { Text("Batal") }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Data Master",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (tabIndex == 0) showAddCustDialog = true else showAddExpDialog = true
                },
                containerColor = DustyPinkPrimary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Tambah")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = tabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = DustyPinkPrimary
            ) {
                Tab(
                    selected = tabIndex == 0,
                    onClick = { tabIndex = 0 },
                    text = { Text("Customer (${customers.size})") }
                )
                Tab(
                    selected = tabIndex == 1,
                    onClick = { tabIndex = 1 },
                    text = { Text("Ekspedisi (${shippingServices.size})") }
                )
            }

            if (tabIndex == 0) {
                if (customers.isEmpty()) {
                    EmptyStateView(
                        title = "Belum Ada Data Customer",
                        actionButtonText = "+ Tambah Customer",
                        onActionClick = { showAddCustDialog = true }
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        items(customers, key = { it.customerId }) { cust ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (cust.customerCode.isNotBlank()) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = DustyPinkPrimary.copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = cust.customerCode,
                                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                        color = DustyPinkPrimary,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                            }
                                            Text(text = cust.customerName, fontWeight = FontWeight.Bold)
                                        }
                                        Text(text = cust.phone, style = MaterialTheme.typography.bodySmall, color = DustyPinkPrimary)
                                        Text(text = cust.displayAddress, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                    }
                                    IconButton(onClick = { customerToDelete = cust }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = StatusDangerRed)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(shippingServices, key = { it.shippingServiceId }) { exp ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = exp.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Row {
                                    if (isRootAdmin) {
                                        IconButton(onClick = { expeditionToEdit = exp }) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Ekspedisi", tint = DustyPinkPrimary)
                                        }
                                        IconButton(onClick = { expeditionToDelete = exp }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = StatusDangerRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RegionSelectorField(
    label: String,
    selectedRegionName: String?,
    placeholder: String,
    disabledPlaceholder: String? = null,
    isEnabled: Boolean = true,
    isLoading: Boolean = false,
    onClick: () -> Unit,
    testTag: String
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (isEnabled) MaterialTheme.colorScheme.onSurface else TextMuted
        )
        Spacer(modifier = Modifier.height(4.dp))
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = when {
                !isEnabled -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                !selectedRegionName.isNullOrBlank() -> DustyPinkPrimary.copy(alpha = 0.08f)
                else -> MaterialTheme.colorScheme.surface
            },
            border = BorderStroke(
                1.dp,
                when {
                    !isEnabled -> BorderLight.copy(alpha = 0.5f)
                    !selectedRegionName.isNullOrBlank() -> DustyPinkPrimary.copy(alpha = 0.5f)
                    else -> BorderLight
                }
            ),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable(enabled = isEnabled && !isLoading, onClick = onClick)
                .testTag(testTag)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isLoading) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = DustyPinkPrimary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Memuat data wilayah...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )
                    }
                } else if (!selectedRegionName.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedRegionName,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Terpilih",
                            tint = StatusSuccessGreen,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                } else {
                    Text(
                        text = if (!isEnabled && disabledPlaceholder != null) disabledPlaceholder else placeholder,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }

                if (isEnabled && !isLoading) {
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Buka Selector",
                        tint = if (!selectedRegionName.isNullOrBlank()) DustyPinkPrimary else TextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun SearchableRegionDialog(
    title: String,
    regions: List<Region>,
    isLoading: Boolean,
    errorMessage: String?,
    onRetry: () -> Unit,
    onSelect: (Region) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = remember(searchQuery, regions) {
        if (searchQuery.isBlank()) regions else regions.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
            it.code.contains(searchQuery, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 220.dp, max = 450.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Cari wilayah...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Hapus")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("region_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                when {
                    isLoading -> {
                        Box(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = DustyPinkPrimary, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Memuat data wilayah...", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            }
                        }
                    }
                    errorMessage != null -> {
                        Box(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = errorMessage,
                                    color = StatusDangerRed,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = onRetry,
                                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
                                ) {
                                    Text("Coba Lagi")
                                }
                            }
                        }
                    }
                    filtered.isEmpty() -> {
                        Box(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Tidak ada wilayah yang cocok", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                    }
                    else -> {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f)
                        ) {
                            items(filtered, key = { it.code }) { region ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            onSelect(region)
                                            onDismiss() // Close immediately upon selection per Section 22
                                        }
                                        .padding(horizontal = 10.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = region.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = region.code,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted
                                    )
                                }
                                HorizontalDivider(color = BorderLight.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun AddCustomerDialog(viewModel: WmsViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var addressDetail by remember { mutableStateOf("") }

    var selectedProvince by remember { mutableStateOf<Region?>(null) }
    var selectedRegency by remember { mutableStateOf<Region?>(null) }
    var selectedDistrict by remember { mutableStateOf<Region?>(null) }

    var activeDialogLevel by remember { mutableStateOf<String?>(null) } // "PROVINCE", "REGENCY", "DISTRICT"
    var validationError by remember { mutableStateOf<String?>(null) }

    val provinces by viewModel.provinces.collectAsState()
    val regencies by viewModel.regencies.collectAsState()
    val districts by viewModel.districts.collectAsState()
    val isRegionLoading by viewModel.isRegionLoading.collectAsState()
    val regionError by viewModel.regionError.collectAsState()

    // Load provinces initially when dialog appears
    LaunchedEffect(Unit) {
        viewModel.loadProvinces()
    }

    val scrollState = rememberScrollState()

    // Sub-dialog selector for Province (Section 5)
    if (activeDialogLevel == "PROVINCE") {
        SearchableRegionDialog(
            title = "Pilih Provinsi",
            regions = provinces,
            isLoading = isRegionLoading && provinces.isEmpty(),
            errorMessage = regionError,
            onRetry = { viewModel.loadProvinces() },
            onSelect = { prov ->
                if (selectedProvince?.code != prov.code) {
                    selectedProvince = prov
                    // Cascading Reset (Sections 11 & 12)
                    selectedRegency = null
                    selectedDistrict = null
                    viewModel.clearRegencies()
                    viewModel.loadRegencies(prov.code)
                }
                activeDialogLevel = null
            },
            onDismiss = { activeDialogLevel = null }
        )
    }

    // Sub-dialog selector for Regency / City (Section 7)
    if (activeDialogLevel == "REGENCY" && selectedProvince != null) {
        SearchableRegionDialog(
            title = "Pilih Kabupaten/Kota (${selectedProvince!!.name})",
            regions = regencies,
            isLoading = isRegionLoading && regencies.isEmpty(),
            errorMessage = regionError,
            onRetry = { viewModel.loadRegencies(selectedProvince!!.code) },
            onSelect = { reg ->
                if (selectedRegency?.code != reg.code) {
                    selectedRegency = reg
                    // Cascading Reset (Section 12)
                    selectedDistrict = null
                    viewModel.clearDistricts()
                    viewModel.loadDistricts(reg.code)
                }
                activeDialogLevel = null
            },
            onDismiss = { activeDialogLevel = null }
        )
    }

    // Sub-dialog selector for District / Kecamatan (Section 9)
    if (activeDialogLevel == "DISTRICT" && selectedRegency != null) {
        SearchableRegionDialog(
            title = "Pilih Kecamatan (${selectedRegency!!.name})",
            regions = districts,
            isLoading = isRegionLoading && districts.isEmpty(),
            errorMessage = regionError,
            onRetry = { viewModel.loadDistricts(selectedRegency!!.code) },
            onSelect = { dist ->
                selectedDistrict = dist
                activeDialogLevel = null
            },
            onDismiss = { activeDialogLevel = null }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Tambah Customer Baru",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                // Customer Code (Section 24: AUTO GENERATED, read-only)
                OutlinedTextField(
                    value = "CS-AUTO (Dibuat otomatis oleh sistem)",
                    onValueChange = {},
                    enabled = false,
                    label = { Text("Customer Code") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                        disabledBorderColor = BorderLight,
                        disabledLabelColor = DustyPinkPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("cust_code_auto")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        validationError = null
                    },
                    label = { Text("Nama Customer *") },
                    placeholder = { Text("Contoh: Toko ABC") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("cust_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        phone = it
                        validationError = null
                    },
                    label = { Text("Nomor Telepon *") },
                    placeholder = { Text("08xxxxxxxxxx") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("cust_phone_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Wilayah Administratif *",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = DustyPinkPrimary
                )
                Text(
                    text = "Pilih secara bertingkat: Provinsi > Kab/Kota > Kecamatan",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 1. Selector Provinsi (Section 5)
                RegionSelectorField(
                    label = "Provinsi *",
                    selectedRegionName = selectedProvince?.name,
                    placeholder = "Pilih Provinsi ▼",
                    isEnabled = true,
                    isLoading = isRegionLoading && provinces.isEmpty(),
                    onClick = {
                        viewModel.loadProvinces()
                        activeDialogLevel = "PROVINCE"
                    },
                    testTag = "cust_province_selector"
                )

                // 2. Selector Kabupaten / Kota (Section 7, 10)
                RegionSelectorField(
                    label = "Kabupaten/Kota *",
                    selectedRegionName = selectedRegency?.name,
                    placeholder = "Pilih Kabupaten/Kota ▼",
                    disabledPlaceholder = "Pilih Provinsi terlebih dahulu",
                    isEnabled = selectedProvince != null,
                    isLoading = isRegionLoading && regencies.isEmpty() && selectedProvince != null,
                    onClick = {
                        activeDialogLevel = "REGENCY"
                    },
                    testTag = "cust_regency_selector"
                )

                // 3. Selector Kecamatan (Section 9, 10)
                RegionSelectorField(
                    label = "Kecamatan *",
                    selectedRegionName = selectedDistrict?.name,
                    placeholder = "Pilih Kecamatan ▼",
                    disabledPlaceholder = "Pilih Kabupaten/Kota terlebih dahulu",
                    isEnabled = selectedRegency != null,
                    isLoading = isRegionLoading && districts.isEmpty() && selectedRegency != null,
                    onClick = {
                        activeDialogLevel = "DISTRICT"
                    },
                    testTag = "cust_district_selector"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Alamat Detail (Section 14)
                OutlinedTextField(
                    value = addressDetail,
                    onValueChange = {
                        addressDetail = it
                        validationError = null
                    },
                    label = { Text("Alamat Detail (Jalan, RT/RW, No. Rumah) *") },
                    placeholder = { Text("Jl. Raya Banjaran No. 123 RT 01/RW 05") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth().testTag("cust_address_detail_input")
                )

                if (validationError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = validationError!!,
                        color = StatusDangerRed,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanName = name.trim()
                    if (cleanName.isBlank()) {
                        validationError = "Nama Customer tidak boleh kosong"
                        return@Button
                    }
                    if (selectedProvince == null) {
                        validationError = "Provinsi wajib dipilih"
                        return@Button
                    }
                    if (selectedRegency == null) {
                        validationError = "Kabupaten/Kota wajib dipilih"
                        return@Button
                    }
                    if (selectedDistrict == null) {
                        validationError = "Kecamatan wajib dipilih"
                        return@Button
                    }
                    if (addressDetail.trim().isBlank()) {
                        validationError = "Alamat detail tidak boleh kosong"
                        return@Button
                    }

                    viewModel.addCustomer(
                        name = cleanName,
                        phone = phone.trim(),
                        addressDetail = addressDetail.trim(),
                        provinceCode = selectedProvince!!.code,
                        provinceName = selectedProvince!!.name,
                        regencyCode = selectedRegency!!.code,
                        regencyName = selectedRegency!!.name,
                        districtCode = selectedDistrict!!.code,
                        districtName = selectedDistrict!!.name
                    ) { success ->
                        if (success) onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                modifier = Modifier.testTag("cust_save_btn")
            ) {
                Text("Simpan Customer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun AddExpeditionDialog(viewModel: WmsViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Layanan Ekspedisi", fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nama Ekspedisi (misal: JNE, J&T)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        viewModel.addShippingService(name)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
            ) {
                Text("Simpan")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

// -------------------------------------------------------------
// PROMO PRICE SCREEN (SECTION 21)
// -------------------------------------------------------------
@Composable
fun PromoPriceScreen(
    viewModel: WmsViewModel,
    onBack: () -> Unit
) {
    val promotions by viewModel.promotions.collectAsState()
    val products by viewModel.products.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var promoSearchQuery by remember { mutableStateOf("") }
    var promoToDelete by remember { mutableStateOf<PromoPrice?>(null) }
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    if (promoToDelete != null) {
        AlertDialog(
            onDismissRequest = { promoToDelete = null },
            title = { Text("Hapus Promo?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Apakah Anda yakin ingin menghapus promo untuk produk '${promoToDelete?.itemName}' ini?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val id = promoToDelete!!.promoId
                        promoToDelete = null
                        viewModel.deletePromo(id)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Hapus")
                }
            },
            dismissButton = {
                TextButton(onClick = { promoToDelete = null }) { Text("Batal") }
            }
        )
    }

    if (showAddDialog) {
        var selectedSku by remember { mutableStateOf(products.firstOrNull()?.sku ?: "") }
        var promoPriceStr by remember { mutableStateOf("") }
        var startDate by remember { mutableStateOf("2026-10-01") }
        var endDate by remember { mutableStateOf("2026-10-31") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Tambah Promo Harga", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Pilih Produk:", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    products.take(4).forEach { p ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedSku = p.sku }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selectedSku == p.sku, onClick = { selectedSku = p.sku })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "${p.sku} - ${p.itemName}", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = promoPriceStr,
                        onValueChange = { promoPriceStr = it.filter { c -> c.isDigit() } },
                        label = { Text("Harga Promo (Rp) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        label = { Text("Tanggal Mulai (YYYY-MM-DD)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = endDate,
                        onValueChange = { endDate = it },
                        label = { Text("Tanggal Selesai (YYYY-MM-DD)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val price = promoPriceStr.toLongOrNull() ?: 0L
                        val prod = products.find { it.sku == selectedSku }
                        if (prod != null && price > 0) {
                            viewModel.addPromoPrice(selectedSku, prod.itemName, price, startDate, endDate) { success ->
                                if (success) showAddDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
                ) {
                    Text("Simpan Promo")
                }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Batal") } }
        )
    }

    val filteredPromotions = promotions.filter {
        it.itemName.contains(promoSearchQuery, ignoreCase = true) ||
        it.sku.contains(promoSearchQuery, ignoreCase = true) ||
        it.promoId.contains(promoSearchQuery, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Promo Price",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = DustyPinkPrimary,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Tambah Promo")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Search Bar (Section O1)
            SearchBarField(
                query = promoSearchQuery,
                onQueryChange = { promoSearchQuery = it },
                placeholder = "🔍 Cari Promo (nama produk, SKU)...",
                testTag = "promo_search_bar"
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (filteredPromotions.isEmpty()) {
                EmptyStateView(
                    title = if (promoSearchQuery.isEmpty()) "Belum Ada Promo Harga" else "Promo tidak ditemukan",
                    description = if (promoSearchQuery.isEmpty()) "Kelola harga diskon tanpa mengubah master harga net produk." else null,
                    actionButtonText = if (promoSearchQuery.isEmpty()) "+ Buat Promo" else null,
                    onActionClick = if (promoSearchQuery.isEmpty()) { { showAddDialog = true } } else null
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredPromotions, key = { it.promoId }) { promo ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = promo.itemName, fontWeight = FontWeight.Bold)
                                    Text(text = "${promo.sku} • Periode: ${promo.startDate} s/d ${promo.endDate}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                                    Text(text = "Harga Promo: ${rupiahFormat.format(promo.promoPrice)}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = DustyPinkPrimary))
                                }
                                IconButton(onClick = { promoToDelete = promo }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = StatusDangerRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// USER MANAGEMENT (SECTION 5 & 6)
// -------------------------------------------------------------
@Composable
fun UserManagementScreen(
    viewModel: WmsViewModel,
    onBack: () -> Unit
) {
    val users by viewModel.userAccounts.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isRootAdmin = currentUser?.role == UserRole.ROOT_ADMIN.label

    var showAddDialog by remember { mutableStateOf(false) }
    var userToEdit by remember { mutableStateOf<UserAccount?>(null) }
    var userToDelete by remember { mutableStateOf<UserAccount?>(null) }
    var deleteCountdown by remember { mutableIntStateOf(10) }

    var editRole by remember { mutableStateOf("") }
    var editPassword by remember { mutableStateOf("") }
    var showEditCountdownDialog by remember { mutableStateOf(false) }
    var editCountdown by remember { mutableIntStateOf(10) }

    LaunchedEffect(userToDelete) {
        if (userToDelete != null) {
            deleteCountdown = 10
            while (deleteCountdown > 0) {
                kotlinx.coroutines.delay(1000)
                deleteCountdown--
            }
        }
    }

    LaunchedEffect(showEditCountdownDialog) {
        if (showEditCountdownDialog) {
            editCountdown = 10
            while (editCountdown > 0) {
                kotlinx.coroutines.delay(1000)
                editCountdown--
            }
        }
    }

    // Confirmation Edit User with 10s Countdown (Section P2)
    if (showEditCountdownDialog && userToEdit != null) {
        AlertDialog(
            onDismissRequest = { showEditCountdownDialog = false },
            title = { Text("Ubah data user?", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("User:\n${userToEdit?.userId}", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Perubahan:")
                    Text("Role: ${userToEdit?.role} → $editRole", fontWeight = FontWeight.Bold, color = DustyPinkPrimary)
                    if (editPassword.isNotBlank()) {
                        Text("Password: Diperbarui via Firebase Auth", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    }
                }
            },
            confirmButton = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showEditCountdownDialog = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Batal")
                    }
                    Button(
                        onClick = {
                            val target = userToEdit!!
                            showEditCountdownDialog = false
                            userToEdit = null
                            viewModel.updateUser(target.userId, target.name, editRole, editPassword.ifBlank { null }) { }
                        },
                        enabled = editCountdown == 0,
                        colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (editCountdown > 0) "Lanjut ($editCountdown)" else "Lanjut")
                    }
                }
            },
            dismissButton = null
        )
    }

    // Delete User with 10s Countdown (Section P3)
    if (userToDelete != null) {
        AlertDialog(
            onDismissRequest = { userToDelete = null },
            title = { Text("Hapus User?", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("User:\n${userToDelete?.userId}", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("User tidak dapat menggunakan aplikasi setelah dihapus.", style = MaterialTheme.typography.bodyMedium, color = StatusDangerRed)
                }
            },
            confirmButton = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { userToDelete = null }, modifier = Modifier.fillMaxWidth()) {
                        Text("Batal")
                    }
                    Button(
                        onClick = {
                            val id = userToDelete!!.userId
                            userToDelete = null
                            viewModel.deleteUser(id)
                        },
                        enabled = deleteCountdown == 0,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (deleteCountdown > 0) "Hapus ($deleteCountdown)" else "Hapus")
                    }
                }
            },
            dismissButton = null
        )
    }

    // Form Edit User Dialog
    if (userToEdit != null && !showEditCountdownDialog) {
        AlertDialog(
            onDismissRequest = { userToEdit = null },
            title = { Text("Edit User: ${userToEdit?.userId}", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Pilih Role Baru:", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    listOf(UserRole.ROOT_ADMIN.label, UserRole.ADMIN_GUDANG.label, UserRole.STAFF_GUDANG.label).forEach { r ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { editRole = r }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = editRole == r, onClick = { editRole = r })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = r, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = editPassword,
                        onValueChange = { editPassword = it },
                        label = { Text("Ganti Password (kosongkan jika tidak ubah)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showEditCountdownDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
                ) {
                    Text("Konfirmasi Perubahan")
                }
            },
            dismissButton = {
                TextButton(onClick = { userToEdit = null }) { Text("Batal") }
            }
        )
    }

    if (showAddDialog) {
        var userId by remember { mutableStateOf("") }
        var name by remember { mutableStateOf("") }
        var role by remember { mutableStateOf(UserRole.STAFF_GUDANG.label) }
        var password by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Tambah Pengguna Baru", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = userId,
                        onValueChange = { userId = it },
                        label = { Text("User ID (misal: admingudang, staff1)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nama Lengkap") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password Akun") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Role Akses:", style = MaterialTheme.typography.labelMedium)
                    listOf(UserRole.ADMIN_GUDANG.label, UserRole.STAFF_GUDANG.label).forEach { r ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { role = r }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = role == r, onClick = { role = r })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = r, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (userId.isNotBlank() && password.isNotBlank()) {
                            viewModel.createUser(userId, name, role, password) { success ->
                                if (success) showAddDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
                ) {
                    Text("Simpan User")
                }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Batal") } }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "User Management",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        },
        floatingActionButton = {
            if (isRootAdmin) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = DustyPinkPrimary,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = "Tambah User")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(users, key = { it.userId }) { u ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "${u.name} (@${u.userId})", fontWeight = FontWeight.Bold)
                            Text(
                                text = "Role: ${u.role}",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (u.role == UserRole.ROOT_ADMIN.label) DustyPinkPrimary else StatusBlue
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isRootAdmin) {
                                IconButton(onClick = {
                                    userToEdit = u
                                    editRole = u.role
                                    editPassword = ""
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit User", tint = DustyPinkPrimary)
                                }
                                if (u.userId != "admin") {
                                    IconButton(onClick = { userToDelete = u }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Hapus User", tint = StatusDangerRed)
                                    }
                                }
                            }

                            if (u.userId == "admin") {
                                Surface(
                                    color = DustyPinkPrimary.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "ROOT",
                                        fontWeight = FontWeight.Bold,
                                        color = DustyPinkPrimary,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// -------------------------------------------------------------
// SETTINGS, PRINTER & DIAGNOSTIC SCREEN
// -------------------------------------------------------------
@Composable
fun SettingsAndPrinterScreen(
    viewModel: WmsViewModel,
    onNavigateToRajaOngkir: () -> Unit,
    onBack: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val isRootAdmin = currentUser?.role == UserRole.ROOT_ADMIN.label

    val storeSettings by viewModel.storeSettings.collectAsState()
    val pairedPrinters by viewModel.pairedPrinters.collectAsState()

    var storeName by remember(storeSettings) { mutableStateOf(storeSettings.storeName) }
    var storePhone by remember(storeSettings) { mutableStateOf(storeSettings.storePhone) }
    var storeEmail by remember(storeSettings) { mutableStateOf(storeSettings.storeEmail) }
    var detailAddress by remember(storeSettings) { mutableStateOf(storeSettings.detailAddress) }
    var postalCode by remember(storeSettings) { mutableStateOf(storeSettings.postalCode) }

    var selectedProvince by remember(storeSettings) {
        mutableStateOf(
            if (storeSettings.provinceCode.isNotBlank() && storeSettings.provinceName.isNotBlank()) {
                Region(code = storeSettings.provinceCode, name = storeSettings.provinceName, level = "PROVINCE")
            } else null
        )
    }
    var selectedRegency by remember(storeSettings) {
        mutableStateOf(
            if (storeSettings.regencyCode.isNotBlank() && storeSettings.regencyName.isNotBlank()) {
                Region(code = storeSettings.regencyCode, name = storeSettings.regencyName, level = "REGENCY", parentCode = storeSettings.provinceCode)
            } else null
        )
    }
    var selectedDistrict by remember(storeSettings) {
        mutableStateOf(
            if (storeSettings.districtCode.isNotBlank() && storeSettings.districtName.isNotBlank()) {
                Region(code = storeSettings.districtCode, name = storeSettings.districtName, level = "DISTRICT", parentCode = storeSettings.regencyCode)
            } else null
        )
    }
    var selectedVillage by remember(storeSettings) {
        mutableStateOf(
            if (storeSettings.villageCode.isNotBlank() && storeSettings.villageName.isNotBlank()) {
                Region(code = storeSettings.villageCode, name = storeSettings.villageName, level = "VILLAGE", parentCode = storeSettings.districtCode)
            } else null
        )
    }

    var selectedLabelSize by remember(storeSettings) { mutableStateOf(storeSettings.labelSize) }
    var selectedPrinterAddress by remember(storeSettings, pairedPrinters) {
        mutableStateOf(storeSettings.defaultPrinterAddress.ifBlank { pairedPrinters.firstOrNull()?.address ?: "" })
    }

    var activeDialogLevel by remember { mutableStateOf<String?>(null) } // "PROVINCE", "REGENCY", "DISTRICT", "VILLAGE"
    var formError by remember { mutableStateOf<String?>(null) }
    var auditResult by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val provinces by viewModel.provinces.collectAsState()
    val regencies by viewModel.regencies.collectAsState()
    val districts by viewModel.districts.collectAsState()
    val villages by viewModel.villages.collectAsState()
    val isRegionLoading by viewModel.isRegionLoading.collectAsState()
    val regionError by viewModel.regionError.collectAsState()

    // Lazy load regions on display
    LaunchedEffect(Unit) {
        viewModel.loadProvinces()
        if (selectedProvince != null) {
            viewModel.loadRegencies(selectedProvince!!.code)
        }
        if (selectedRegency != null) {
            viewModel.loadDistricts(selectedRegency!!.code)
        }
        if (selectedDistrict != null) {
            viewModel.loadVillages(selectedDistrict!!.code)
        }
    }

    val scrollState = rememberScrollState()

    // Sub-dialog selector for Province
    if (activeDialogLevel == "PROVINCE") {
        SearchableRegionDialog(
            title = "Pilih Provinsi Toko",
            regions = provinces,
            isLoading = isRegionLoading && provinces.isEmpty(),
            errorMessage = regionError,
            onRetry = { viewModel.loadProvinces() },
            onSelect = { prov ->
                if (selectedProvince?.code != prov.code) {
                    selectedProvince = prov
                    selectedRegency = null
                    selectedDistrict = null
                    selectedVillage = null
                    viewModel.clearRegencies()
                    viewModel.loadRegencies(prov.code)
                }
                activeDialogLevel = null
            },
            onDismiss = { activeDialogLevel = null }
        )
    }

    // Sub-dialog selector for Regency / City
    if (activeDialogLevel == "REGENCY" && selectedProvince != null) {
        SearchableRegionDialog(
            title = "Pilih Kabupaten/Kota (${selectedProvince!!.name})",
            regions = regencies,
            isLoading = isRegionLoading && regencies.isEmpty(),
            errorMessage = regionError,
            onRetry = { viewModel.loadRegencies(selectedProvince!!.code) },
            onSelect = { reg ->
                if (selectedRegency?.code != reg.code) {
                    selectedRegency = reg
                    selectedDistrict = null
                    selectedVillage = null
                    viewModel.clearDistricts()
                    viewModel.loadDistricts(reg.code)
                }
                activeDialogLevel = null
            },
            onDismiss = { activeDialogLevel = null }
        )
    }

    // Sub-dialog selector for District (Kecamatan)
    if (activeDialogLevel == "DISTRICT" && selectedRegency != null) {
        SearchableRegionDialog(
            title = "Pilih Kecamatan (${selectedRegency!!.name})",
            regions = districts,
            isLoading = isRegionLoading && districts.isEmpty(),
            errorMessage = regionError,
            onRetry = { viewModel.loadDistricts(selectedRegency!!.code) },
            onSelect = { dist ->
                if (selectedDistrict?.code != dist.code) {
                    selectedDistrict = dist
                    selectedVillage = null
                    viewModel.clearVillages()
                    viewModel.loadVillages(dist.code)
                }
                activeDialogLevel = null
            },
            onDismiss = { activeDialogLevel = null }
        )
    }

    // Sub-dialog selector for Village (Desa / Kelurahan)
    if (activeDialogLevel == "VILLAGE" && selectedDistrict != null) {
        SearchableRegionDialog(
            title = "Pilih Desa/Kelurahan (${selectedDistrict!!.name})",
            regions = villages,
            isLoading = isRegionLoading && villages.isEmpty(),
            errorMessage = regionError,
            onRetry = { viewModel.loadVillages(selectedDistrict!!.code) },
            onSelect = { vil ->
                selectedVillage = vil
                activeDialogLevel = null
            },
            onDismiss = { activeDialogLevel = null }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Pengaturan & Printer",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Permission Warning Banner if not Root Admin (Section 11)
            if (!isRootAdmin) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = StatusDangerRed)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Mode Hanya Lihat (Read-Only)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = StatusDangerRed
                            )
                            Text(
                                text = "Hanya Root Admin yang berhak mengubah informasi dan alamat resmi toko.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // 1. Informasi Toko Card (Section 4 & 10)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Informasi Toko",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = storeName,
                        onValueChange = { storeName = it },
                        label = { Text("Nama Toko") },
                        enabled = isRootAdmin,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("store_name_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = storePhone,
                        onValueChange = { storePhone = it },
                        label = { Text("Nomor Handphone Toko") },
                        enabled = isRootAdmin,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth().testTag("store_phone_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = storeEmail,
                        onValueChange = { storeEmail = it },
                        label = { Text("Email Toko") },
                        enabled = isRootAdmin,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth().testTag("store_email_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Alamat Toko Berbasis Master Data Wilayah (Section 4, 5, 6, 7, 8, 9)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Alamat Toko (Master Wilayah)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = DustyPinkPrimary)
                    }

                    Text(
                        text = "Alamat toko digunakan sebagai origin resmi Cek Ongkir dan alamat pengirim DO.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Provinsi Picker
                    RegionSelectorField(
                        label = "Provinsi",
                        selectedRegionName = selectedProvince?.let { "${it.code} - ${it.name}" },
                        placeholder = "Pilih Provinsi...",
                        isEnabled = isRootAdmin,
                        isLoading = isRegionLoading && provinces.isEmpty(),
                        onClick = { if (isRootAdmin) activeDialogLevel = "PROVINCE" },
                        testTag = "store_province_selector"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Kabupaten/Kota Picker (Cascading dependent on Provinsi)
                    RegionSelectorField(
                        label = "Kabupaten / Kota",
                        selectedRegionName = selectedRegency?.let { "${it.code} - ${it.name}" },
                        placeholder = "Pilih Kabupaten/Kota...",
                        disabledPlaceholder = "Pilih provinsi terlebih dahulu",
                        isEnabled = isRootAdmin && selectedProvince != null,
                        isLoading = isRegionLoading && regencies.isEmpty() && selectedProvince != null,
                        onClick = { if (isRootAdmin && selectedProvince != null) activeDialogLevel = "REGENCY" },
                        testTag = "store_regency_selector"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Kecamatan Picker (Cascading dependent on Kabupaten)
                    RegionSelectorField(
                        label = "Kecamatan",
                        selectedRegionName = selectedDistrict?.let { "${it.code} - ${it.name}" },
                        placeholder = "Pilih Kecamatan...",
                        disabledPlaceholder = "Pilih kabupaten/kota terlebih dahulu",
                        isEnabled = isRootAdmin && selectedRegency != null,
                        isLoading = isRegionLoading && districts.isEmpty() && selectedRegency != null,
                        onClick = { if (isRootAdmin && selectedRegency != null) activeDialogLevel = "DISTRICT" },
                        testTag = "store_district_selector"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Desa / Kelurahan Picker (Cascading dependent on Kecamatan)
                    RegionSelectorField(
                        label = "Desa / Kelurahan",
                        selectedRegionName = selectedVillage?.let { "${it.code} - ${it.name}" },
                        placeholder = "Pilih Desa / Kelurahan...",
                        disabledPlaceholder = "Pilih kecamatan terlebih dahulu",
                        isEnabled = isRootAdmin && selectedDistrict != null,
                        isLoading = isRegionLoading && villages.isEmpty() && selectedDistrict != null,
                        onClick = { if (isRootAdmin && selectedDistrict != null) activeDialogLevel = "VILLAGE" },
                        testTag = "store_village_selector"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Detail Alamat (Jalan, Nomor, RT/RW, Blok)
                    OutlinedTextField(
                        value = detailAddress,
                        onValueChange = { detailAddress = it },
                        label = { Text("Alamat Detail (Jalan, No, RT/RW, Blok)") },
                        enabled = isRootAdmin,
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("store_detail_address_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Kode Pos (Opsional)
                    OutlinedTextField(
                        value = postalCode,
                        onValueChange = { postalCode = it.filter { c -> c.isDigit() } },
                        label = { Text("Kode Pos (Opsional)") },
                        enabled = isRootAdmin,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("store_postal_code_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Tampilan Ringkas Informasi & Alamat Toko (Section 20 & 22)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ringkasan Alamat Toko",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        val isComplete = selectedProvince != null && selectedRegency != null &&
                                selectedDistrict != null && selectedVillage != null && detailAddress.isNotBlank()
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isComplete) StatusSuccessGreen.copy(alpha = 0.15f) else StatusDangerRed.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (isComplete) "Lengkap" else "Belum Lengkap",
                                color = if (isComplete) StatusSuccessGreen else StatusDangerRed,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val previewAddress = buildString {
                        if (detailAddress.isNotBlank()) append(detailAddress)
                        if (selectedVillage != null) {
                            if (isNotEmpty()) append(", ")
                            append("Desa/Kel. ").append(selectedVillage!!.name)
                        }
                        if (selectedDistrict != null) {
                            if (isNotEmpty()) append(", ")
                            append("Kec. ").append(selectedDistrict!!.name)
                        }
                        if (selectedRegency != null) {
                            if (isNotEmpty()) append(", ")
                            append(selectedRegency!!.name)
                        }
                        if (selectedProvince != null) {
                            if (isNotEmpty()) append(", ")
                            append(selectedProvince!!.name)
                        }
                        if (postalCode.isNotBlank()) {
                            if (isNotEmpty()) append(" ").append(postalCode)
                        }
                    }.ifBlank { storeSettings.storeAddress.ifBlank { "Belum diisi" } }

                    Text(
                        text = previewAddress,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val previewOrigin = when {
                        selectedDistrict != null && selectedRegency != null -> "${selectedDistrict!!.name}, ${selectedRegency!!.name}"
                        selectedDistrict != null -> selectedDistrict!!.name
                        else -> "Banjaran"
                    }
                    Text(
                        text = "Origin Pengiriman / Cek Ongkir: $previewOrigin",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = DustyPinkPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Konfigurasi Printer Thermal
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Konfigurasi Printer Thermal", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        IconButton(onClick = { viewModel.refreshPrinters() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Segarkan")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Ukuran Kertas:", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.padding(vertical = 4.dp)) {
                        listOf("58mm", "80mm", "100mm").forEach { sz ->
                            FilterChip(
                                selected = selectedLabelSize == sz,
                                onClick = { selectedLabelSize = sz },
                                label = { Text(sz) },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Pilih Printer Bluetooth:", style = MaterialTheme.typography.labelMedium)
                    if (pairedPrinters.isEmpty()) {
                        Text(
                            text = "Tidak ada printer Bluetooth yang terpasang (paired).",
                            style = MaterialTheme.typography.bodySmall,
                            color = StatusDangerRed
                        )
                    } else {
                        pairedPrinters.forEach { p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedPrinterAddress = p.address }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = selectedPrinterAddress == p.address, onClick = { selectedPrinterAddress = p.address })
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "${p.name} (${p.address})", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = {
                            if (selectedPrinterAddress.isBlank()) {
                                viewModel.showMessage("Pilih printer terlebih dahulu")
                                return@OutlinedButton
                            }
                            viewModel.testPrint(selectedPrinterAddress)
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Print (Kirim ke Printer)")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (formError != null) {
                Text(
                    text = formError!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = StatusDangerRed,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            // Save Settings Button
            Button(
                onClick = {
                    if (!isRootAdmin) {
                        viewModel.showMessage("Hanya Root Admin yang berhak mengubah informasi dan alamat toko")
                        return@Button
                    }

                    if (storeName.isBlank()) {
                        formError = "Nama toko wajib diisi"
                        return@Button
                    }
                    if (storePhone.isBlank()) {
                        formError = "Nomor handphone toko wajib diisi"
                        return@Button
                    }
                    if (selectedProvince == null || selectedRegency == null || selectedDistrict == null || selectedVillage == null) {
                        formError = "Lengkapi seluruh pilihan wilayah (Provinsi, Kabupaten/Kota, Kecamatan, dan Desa/Kelurahan)"
                        return@Button
                    }
                    if (detailAddress.isBlank()) {
                        formError = "Alamat detail toko (jalan, no, RT/RW) wajib diisi"
                        return@Button
                    }

                    formError = null
                    val selPrinterName = pairedPrinters.find { it.address == selectedPrinterAddress }?.name ?: ""
                    viewModel.updateStoreSettings(
                        StoreSettings(
                            storeName = storeName.trim(),
                            storePhone = storePhone.trim(),
                            storeEmail = storeEmail.trim(),
                            storeAddress = storeSettings.storeAddress, // legacy fallback preserved
                            detailAddress = detailAddress.trim(),
                            provinceCode = selectedProvince?.code ?: "",
                            provinceName = selectedProvince?.name ?: "",
                            regencyCode = selectedRegency?.code ?: "",
                            regencyName = selectedRegency?.name ?: "",
                            districtCode = selectedDistrict?.code ?: "",
                            districtName = selectedDistrict?.name ?: "",
                            villageCode = selectedVillage?.code ?: "",
                            villageName = selectedVillage?.name ?: "",
                            postalCode = postalCode.trim(),
                            labelSize = selectedLabelSize,
                            defaultPrinterAddress = selectedPrinterAddress,
                            defaultPrinterName = selPrinterName
                        )
                    )
                },
                enabled = isRootAdmin,
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_store_settings_btn")
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Simpan Informasi & Alamat Toko")
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Integrasi Ekspedisi / RajaOngkir API (Section 1)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth().testTag("integrasi_rajaongkir_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.LocalShipping,
                                contentDescription = null,
                                tint = DustyPinkPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Integrasi RajaOngkir API",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Konfigurasi API Key ekspedisi pengiriman (Komerce)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isRootAdmin) {
                        Button(
                            onClick = onNavigateToRajaOngkir,
                            colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_kelola_rajaongkir_api")
                        ) {
                            Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Kelola RajaOngkir API Key")
                        }
                    } else {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = StatusDangerRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Hanya Root Admin yang berhak melihat dan mengubah API Key.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusDangerRed
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Diagnostic & Audit Duplicates per Section 14, 18, 95
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Audit & Diagnostik SKU / FAM", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Memeriksa apakah terdapat duplikasi nomor SKU atau Family pada database dan memeriksa integritas counter atomic.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val res = viewModel.runDuplicateAudit()
                                auditResult = "Hasil Audit:\n$res"
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors()
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Jalankan Audit Duplikat")
                    }

                    if (auditResult != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = auditResult!!,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
