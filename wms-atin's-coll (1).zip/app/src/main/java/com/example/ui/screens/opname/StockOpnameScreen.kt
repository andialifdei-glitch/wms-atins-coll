package com.example.ui.screens.opname

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.*
import com.example.ui.WmsViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingDialog
import com.example.ui.components.SearchBarField
import com.example.ui.components.WmsTopBar
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun StockOpnameScreen(
    viewModel: WmsViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val stockOpnames by viewModel.stockOpnames.collectAsState()
    val sopPostings by viewModel.sopPostings.collectAsState()

    val isRootAdmin = currentUser?.role == UserRole.ROOT_ADMIN.label

    var selectedTab by remember { mutableIntStateOf(0) }
    // 0: Opname & Counting, 1: Adjustment & Posting (Root Admin), 2: Riwayat & Laporan

    var showInitDialog by remember { mutableStateOf(false) }
    var initNotes by remember { mutableStateOf("") }

    var selectedSopForCounting by remember { mutableStateOf<StockOpname?>(null) }
    var selectedSopForAdjustment by remember { mutableStateOf<StockOpname?>(null) }
    var selectedSopForAudit by remember { mutableStateOf<String?>(null) }

    BackHandler {
        when {
            selectedSopForCounting != null -> selectedSopForCounting = null
            selectedSopForAdjustment != null -> selectedSopForAdjustment = null
            selectedSopForAudit != null -> selectedSopForAudit = null
            else -> onNavigateBack()
        }
    }

    if (isLoading) {
        LoadingDialog("Memproses data Stock Opname...")
    }

    // Active SOP for counting/adjustment
    val activeSop = stockOpnames.firstOrNull {
        it.status == "OPEN" || it.status == "COUNTING" || it.status == "COUNTING_COMPLETED" || it.status == "ADJUSTMENT"
    }

    // Update references if refreshed
    LaunchedEffect(stockOpnames) {
        if (selectedSopForCounting != null) {
            selectedSopForCounting = stockOpnames.firstOrNull { it.sopId == selectedSopForCounting?.sopId }
        }
        if (selectedSopForAdjustment != null) {
            selectedSopForAdjustment = stockOpnames.firstOrNull { it.sopId == selectedSopForAdjustment?.sopId }
        }
    }

    // Sub-view: Counting Screen
    if (selectedSopForCounting != null) {
        CountingScreenView(
            sop = selectedSopForCounting!!,
            viewModel = viewModel,
            isRootAdmin = isRootAdmin,
            onBack = { selectedSopForCounting = null }
        )
        return
    }

    // Sub-view: Adjustment Screen (Root Admin)
    if (selectedSopForAdjustment != null && isRootAdmin) {
        AdjustmentScreenView(
            sop = selectedSopForAdjustment!!,
            viewModel = viewModel,
            onBack = { selectedSopForAdjustment = null }
        )
        return
    }

    // Audit Trail Dialog
    if (selectedSopForAudit != null) {
        AuditTrailDialog(
            documentNo = selectedSopForAudit!!,
            viewModel = viewModel,
            onDismiss = { selectedSopForAudit = null }
        )
    }

    // Dialog: Initialize Stock Opname (Root Admin)
    if (showInitDialog) {
        AlertDialog(
            onDismissRequest = { showInitDialog = false },
            title = {
                Text("Initialize Stock Opname", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "Sistem akan membuat snapshot dari seluruh SKU aktif dan stok sistem saat ini sebagai baseline Stock Opname.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Nomor dokumen akan diterbitkan secara otomatis dengan format: SOP-YYYYMMDD-XXX",
                        style = MaterialTheme.typography.bodySmall,
                        color = DustyPinkPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = initNotes,
                        onValueChange = { initNotes = it },
                        label = { Text("Catatan Opname (Opsional)") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showInitDialog = false
                        viewModel.initializeStockOpname(initNotes) { createdSop ->
                            initNotes = ""
                            if (createdSop != null) {
                                selectedSopForCounting = createdSop
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                    modifier = Modifier.testTag("confirm_init_sop_button")
                ) {
                    Text("Inisialisasi SOP")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showInitDialog = false },
                    modifier = Modifier.testTag("cancel_init_sop_button")
                ) {
                    Text("Batal")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Stock Opname",
                userRole = "${currentUser?.name} (${currentUser?.role})",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isOnline = isOnline
            )
        },
        floatingActionButton = {
            if (isRootAdmin && activeSop == null && selectedTab == 0) {
                ExtendedFloatingActionButton(
                    onClick = { showInitDialog = true },
                    containerColor = DustyPinkPrimary,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Initialize SOP") },
                    modifier = Modifier.testTag("init_sop_fab")
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Tabs navigation
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = DustyPinkPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Opname & Counting", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                if (isRootAdmin) {
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Adjustment & Posting", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
                Tab(
                    selected = selectedTab == if (isRootAdmin) 2 else 1,
                    onClick = { selectedTab = if (isRootAdmin) 2 else 1 },
                    text = { Text("Riwayat & Laporan", fontWeight = if (selectedTab == (if (isRootAdmin) 2 else 1)) FontWeight.Bold else FontWeight.Normal) }
                )
            }

            // Tab Content
            when {
                selectedTab == 0 -> {
                    // TAB 0: Opname & Counting
                    ActiveOpnameTabContent(
                        activeSop = activeSop,
                        isRootAdmin = isRootAdmin,
                        onOpenCounting = { sop -> selectedSopForCounting = sop },
                        onInitializeClick = { showInitDialog = true },
                        onViewAudit = { docNo -> selectedSopForAudit = docNo }
                    )
                }
                isRootAdmin && selectedTab == 1 -> {
                    // TAB 1: Adjustment & Posting (Root Admin Only)
                    AdjustmentTabContent(
                        stockOpnames = stockOpnames,
                        onOpenAdjustment = { sop -> selectedSopForAdjustment = sop },
                        onPostSop = { sop ->
                            viewModel.postStockOpname(sop.sopId) {}
                        },
                        onViewAudit = { docNo -> selectedSopForAudit = docNo }
                    )
                }
                else -> {
                    // TAB 2: Riwayat & Laporan
                    HistoryReportTabContent(
                        stockOpnames = stockOpnames,
                        sopPostings = sopPostings,
                        isRootAdmin = isRootAdmin,
                        viewModel = viewModel,
                        onViewAudit = { docNo -> selectedSopForAudit = docNo }
                    )
                }
            }
        }
    }
}

@Composable
fun ActiveOpnameTabContent(
    activeSop: StockOpname?,
    isRootAdmin: Boolean,
    onOpenCounting: (StockOpname) -> Unit,
    onInitializeClick: () -> Unit,
    onViewAudit: (String) -> Unit
) {
    if (activeSop == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Inventory2,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Belum ada Stock Opname yang aktif.",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isRootAdmin) {
                    "Tekan tombol 'Initialize SOP' untuk memulai penghitungan stok fisik baru."
                } else {
                    "Silakan menunggu Initialize dari Root Admin."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (isRootAdmin) {
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onInitializeClick,
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("init_sop_center_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Initialize Stock Opname")
                }
            }
        }
    } else {
        // Display active Stock Opname Card
        val countedCount = activeSop.items.count { it.hasBeenCounted }
        val totalCount = activeSop.items.size
        val progress = if (totalCount > 0) countedCount.toFloat() / totalCount.toFloat() else 0f

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("active_sop_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeSop.documentNo,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = DustyPinkPrimary
                        )
                        Badge(
                            containerColor = when (activeSop.status) {
                                "OPEN" -> StatusBlue.copy(alpha = 0.15f)
                                "COUNTING" -> StatusWarningOrange.copy(alpha = 0.15f)
                                "COUNTING_COMPLETED" -> StatusSuccessGreen.copy(alpha = 0.15f)
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        ) {
                            Text(
                                text = activeSop.status,
                                color = when (activeSop.status) {
                                    "OPEN" -> StatusBlue
                                    "COUNTING" -> StatusWarningOrange
                                    "COUNTING_COMPLETED" -> StatusSuccessGreen
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Tanggal Opname: ${activeSop.opnameDate}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Initialized By: ${activeSop.initializedBy}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (activeSop.notes.isNotBlank()) {
                        Text(
                            text = "Catatan: ${activeSop.notes}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Progress Counting: $countedCount / $totalCount SKU (${(progress * 100).toInt()}%)",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = DustyPinkPrimary,
                        trackColor = DustyPinkPrimary.copy(alpha = 0.15f)
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onOpenCounting(activeSop) },
                            colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_counting_button")
                        ) {
                            Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (activeSop.status == "COUNTING_COMPLETED") "Lihat Hasil Count" else "Mulai Counting")
                        }

                        OutlinedButton(
                            onClick = { onViewAudit(activeSop.documentNo) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("sop_audit_button")
                        ) {
                            Icon(imageVector = Icons.Default.History, contentDescription = null)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CountingScreenView(
    sop: StockOpname,
    viewModel: WmsViewModel,
    isRootAdmin: Boolean,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var filterMode by remember { mutableIntStateOf(0) } // 0: Semua, 1: Belum Dihitung, 2: Sudah Dihitung

    var itemToCount by remember { mutableStateOf<StockOpnameItem?>(null) }
    var inputQtyText by remember { mutableStateOf("") }

    var showCompleteConfirmDialog by remember { mutableStateOf(false) }
    var showCancelSopDialog by remember { mutableStateOf(false) }
    var cancelSopCountdown by remember { mutableIntStateOf(10) }

    LaunchedEffect(showCancelSopDialog) {
        if (showCancelSopDialog) {
            cancelSopCountdown = 10
            while (cancelSopCountdown > 0) {
                kotlinx.coroutines.delay(1000)
                cancelSopCountdown--
            }
        }
    }

    val filteredItems = sop.items.filter { item ->
        val matchesSearch = item.skuId.contains(searchQuery, ignoreCase = true) ||
                item.itemName.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (filterMode) {
            1 -> !item.hasBeenCounted
            2 -> item.hasBeenCounted
            else -> true
        }
        matchesSearch && matchesFilter
    }

    val uncountedCount = sop.items.count { !it.hasBeenCounted }
    val isCancelled = sop.status == "CANCELLED" || sop.status == "CANCELED"
    val isLocked = sop.status == "COUNTING_COMPLETED" || sop.status == "POSTED" || isCancelled

    var cancelReasonInput by remember { mutableStateOf("") }

    // Dialog Cancel SOP (Section M)
    if (showCancelSopDialog) {
        AlertDialog(
            onDismissRequest = { showCancelSopDialog = false },
            title = {
                Text("Batalkan Stock Opname?", fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text("Dokumen:\n${sop.documentNo}", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Stock Opname yang dibatalkan tidak dapat dilanjutkan.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = cancelReasonInput,
                        onValueChange = { cancelReasonInput = it },
                        label = { Text("Alasan Pembatalan *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showCancelSopDialog = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Batal")
                    }
                    Button(
                        onClick = {
                            if (cancelReasonInput.isBlank()) {
                                Toast.makeText(context, "Alasan pembatalan wajib diisi", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            showCancelSopDialog = false
                            viewModel.cancelStockOpname(sop.sopId, cancelReasonInput) { success ->
                                if (success) onBack()
                            }
                        },
                        enabled = cancelSopCountdown == 0,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("confirm_cancel_sop_button")
                    ) {
                        Text(if (cancelSopCountdown > 0) "OK ($cancelSopCountdown)" else "OK")
                    }
                }
            },
            dismissButton = null
        )
    }

    // Dialog Input Counting
    if (itemToCount != null && !isLocked) {
        val currentItem = itemToCount!!
        AlertDialog(
            onDismissRequest = { itemToCount = null },
            title = {
                Text("Input Qty Fisik", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "SKU: ${currentItem.skuId}",
                        fontWeight = FontWeight.Bold,
                        color = DustyPinkPrimary
                    )
                    Text(
                        text = currentItem.itemName,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    // BLIND COUNTING: Never show systemQtySnapshot to Admin / Staff!
                    if (isRootAdmin) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "System Stock Snapshot: ${currentItem.systemQtySnapshot} pcs (Root Admin Only)",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = inputQtyText,
                        onValueChange = { inputQtyText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Qty Fisik Sebenarnya (Pcs)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_physical_qty_field")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = inputQtyText.toIntOrNull()
                        if (qty == null || qty < 0) {
                            Toast.makeText(context, "Masukkan jumlah fisik yang valid (>= 0)", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val sku = currentItem.skuId
                        itemToCount = null
                        inputQtyText = ""
                        viewModel.saveItemCount(sop.sopId, sku, qty) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                    modifier = Modifier.testTag("save_physical_qty_button")
                ) {
                    Text("Simpan Count")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { itemToCount = null },
                    modifier = Modifier.testTag("cancel_physical_qty_button")
                ) {
                    Text("Batal")
                }
            }
        )
    }

    // Confirmation Alert: Selesaikan Stock Opname
    if (showCompleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showCompleteConfirmDialog = false },
            title = {
                Text("Selesaikan Stock Opname?", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "Stock Opname selesai dihitung.\n\nApakah hasil penghitungan sudah sesuai?\n\nSetelah diselesaikan, data counting akan dikunci dan siap untuk direview/adjustment.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCompleteConfirmDialog = false
                        viewModel.completeCounting(sop.sopId) { success ->
                            if (success) onBack()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                    modifier = Modifier.testTag("confirm_complete_counting_button")
                ) {
                    Text("Ya, Selesaikan")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCompleteConfirmDialog = false },
                    modifier = Modifier.testTag("back_complete_counting_button")
                ) {
                    Text("Kembali")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Counting: ${sop.documentNo}",
                canNavigateBack = true,
                onNavigateBack = onBack,
                isOnline = isOnline
            )
        },
        bottomBar = {
            if (!isLocked) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = {
                                if (uncountedCount > 0) {
                                    Toast.makeText(
                                        context,
                                        "Stock Opname belum dapat diselesaikan.\n$uncountedCount SKU belum dihitung.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    showCompleteConfirmDialog = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (uncountedCount == 0) StatusSuccessGreen else DustyPinkPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("finish_stock_opname_button")
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (uncountedCount > 0) "Selesaikan ($uncountedCount belum)" else "Selesaikan Stock Opname"
                            )
                        }

                        if (sop.status == "OPEN") {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { showCancelSopDialog = true },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDangerRed),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("cancel_sop_button")
                            ) {
                                Icon(imageVector = Icons.Default.Cancel, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Cancel SOP")
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // CANCELLED BANNER: Shows cancellation notice with cancelReason and locks counting
            if (isCancelled) {
                Card(
                    shape = RoundedCornerShape(0.dp),
                    colors = CardDefaults.cardColors(containerColor = StatusDangerRed.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, StatusDangerRed.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sop_cancelled_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cancel,
                            contentDescription = null,
                            tint = StatusDangerRed,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "SESI AUDIT STOCK OPNAME DIBATALKAN",
                                fontWeight = FontWeight.Bold,
                                color = StatusDangerRed,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            val reasonText = sop.cancelReason.ifBlank { "Sesi Stock Opname telah dibatalkan dari Web Portal / Pengguna." }
                            Text(
                                text = "Alasan: $reasonText",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (sop.cancelledBy.isNotBlank()) {
                                Text(
                                    text = "Dibatalkan oleh: ${sop.cancelledBy}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }
                            Text(
                                text = "Seluruh input fisik terkunci dan tidak dapat diubah.",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = StatusDangerRed
                            )
                        }
                    }
                }
            }

            // Search and filter
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                SearchBarField(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "Cari SKU atau nama barang..."
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = filterMode == 0,
                        onClick = { filterMode = 0 },
                        label = { Text("Semua (${sop.items.size})") }
                    )
                    FilterChip(
                        selected = filterMode == 1,
                        onClick = { filterMode = 1 },
                        label = { Text("Belum ($uncountedCount)") }
                    )
                    FilterChip(
                        selected = filterMode == 2,
                        onClick = { filterMode = 2 },
                        label = { Text("Sudah (${sop.items.size - uncountedCount})") }
                    )
                }
            }

            if (filteredItems.isEmpty()) {
                EmptyStateView(
                    title = "Tidak ada SKU",
                    description = "Tidak ada SKU yang cocok dengan filter pencarian"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredItems, key = { it.skuId }) { item ->
                        CountingItemCard(
                            item = item,
                            isLocked = isLocked,
                            isRootAdmin = isRootAdmin,
                            onItemClick = {
                                if (!isLocked) {
                                    itemToCount = item
                                    inputQtyText = (item.physicalQty ?: "").toString()
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CountingItemCard(
    item: StockOpnameItem,
    isLocked: Boolean,
    isRootAdmin: Boolean,
    onItemClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.hasBeenCounted) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isLocked, onClick = onItemClick)
            .testTag("counting_item_${item.skuId}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.skuId,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = DustyPinkPrimary
                )
                Text(
                    text = item.itemName,
                    style = MaterialTheme.typography.bodyMedium
                )

                if (isRootAdmin) {
                    Text(
                        text = "Snapshot: ${item.systemQtySnapshot} pcs",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                if (item.hasBeenCounted && item.countedBy.isNotBlank()) {
                    val countTimeStr = item.countedAt?.toDate()?.let {
                        SimpleDateFormat("HH:mm", Locale.getDefault()).format(it)
                    } ?: ""
                    Text(
                        text = "Dihitung oleh: ${item.countedBy} ${if (countTimeStr.isNotBlank()) "• $countTimeStr" else ""}",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusSuccessGreen
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                if (item.hasBeenCounted && item.physicalQty != null) {
                    Text(
                        text = "${item.physicalQty} pcs",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = StatusSuccessGreen
                    )
                    Text(
                        text = "Sudah Dihitung",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusSuccessGreen
                    )
                } else {
                    Text(
                        text = "Belum dihitung",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusWarningOrange,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (!isLocked) {
                        Text(
                            text = "Tap untuk input",
                            style = MaterialTheme.typography.labelSmall,
                            color = DustyPinkPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdjustmentTabContent(
    stockOpnames: List<StockOpname>,
    onOpenAdjustment: (StockOpname) -> Unit,
    onPostSop: (StockOpname) -> Unit,
    onViewAudit: (String) -> Unit
) {
    // Only show SOPs ready for adjustment (COUNTING_COMPLETED or ADJUSTMENT)
    val adjustableSops = stockOpnames.filter {
        it.status == "COUNTING_COMPLETED" || it.status == "ADJUSTMENT"
    }

    if (adjustableSops.isEmpty()) {
        EmptyStateView(
            title = "Tidak ada dokumen Stock Opname",
            description = "SOP harus berstatus COUNTING_COMPLETED terlebih dahulu."
        )
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(adjustableSops, key = { it.sopId }) { sop ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = sop.documentNo,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = DustyPinkPrimary
                            )
                            Badge(containerColor = StatusSuccessGreen.copy(alpha = 0.15f)) {
                                Text(
                                    text = sop.status,
                                    color = StatusSuccessGreen,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Tanggal: ${sop.opnameDate}", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = "Completed By: ${sop.countingCompletedBy}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        val netDiff = sop.items.sumOf { (it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot }
                        val surplus = sop.items.filter { ((it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot) > 0 }
                            .sumOf { (it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot }
                        val shortage = sop.items.filter { ((it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot) < 0 }
                            .sumOf { it.systemQtySnapshot - (it.physicalQty ?: it.systemQtySnapshot) }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Total Surplus: +$surplus | Total Shortage: -$shortage | Net: ${if (netDiff > 0) "+$netDiff" else "$netDiff"} pcs",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onOpenAdjustment(sop) },
                                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("open_adjustment_btn_${sop.sopId}")
                            ) {
                                Icon(imageVector = Icons.Default.Tune, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Adjustment & Review")
                            }

                            OutlinedButton(
                                onClick = { onViewAudit(sop.documentNo) },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.History, contentDescription = null)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdjustmentScreenView(
    sop: StockOpname,
    viewModel: WmsViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedItemForEdit by remember { mutableStateOf<StockOpnameItem?>(null) }
    var inputRealStock by remember { mutableStateOf("") }
    var inputReason by remember { mutableStateOf("") }
    var showPostConfirmation by remember { mutableStateOf(false) }

    val filteredItems = sop.items.filter {
        it.skuId.contains(searchQuery, ignoreCase = true) ||
                it.itemName.contains(searchQuery, ignoreCase = true)
    }

    // Modal Edit Adjustment per SKU per Requirement 11 & 12
    if (selectedItemForEdit != null) {
        val item = selectedItemForEdit!!
        val currentPhysical = inputRealStock.toIntOrNull() ?: (item.physicalQty ?: item.systemQtySnapshot)
        val calculatedDiff = currentPhysical - item.systemQtySnapshot

        AlertDialog(
            onDismissRequest = { selectedItemForEdit = null },
            title = {
                Text("ADJUSTMENT STOCK OPNAME", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(text = "SOP: ${sop.documentNo}", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "SKU: ${item.skuId}", fontWeight = FontWeight.Bold, color = DustyPinkPrimary)
                    Text(text = "Nama: ${item.itemName}", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "System Stock: ${item.systemQtySnapshot} pcs", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = inputRealStock,
                        onValueChange = { inputRealStock = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Real Physical Stock") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("adjustment_real_stock_field")
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Difference: ${if (calculatedDiff > 0) "+$calculatedDiff" else "$calculatedDiff"}",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = when {
                            calculatedDiff < 0 -> StatusDangerRed
                            calculatedDiff > 0 -> StatusSuccessGreen
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = inputReason,
                        onValueChange = { inputReason = it },
                        label = { Text("Alasan Penyesuaian") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val realStock = inputRealStock.toIntOrNull()
                        if (realStock == null || realStock < 0) {
                            Toast.makeText(context, "Masukkan real physical stock yang valid", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val sku = item.skuId
                        val reason = inputReason
                        selectedItemForEdit = null
                        viewModel.saveAdjustment(sop.sopId, sku, realStock, reason) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                    modifier = Modifier.testTag("save_adjustment_btn")
                ) {
                    Text("Simpan Adjustment")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedItemForEdit = null }) {
                    Text("Batal")
                }
            }
        )
    }

    // Confirmation Post Stock Opname Dialog
    if (showPostConfirmation) {
        AlertDialog(
            onDismissRequest = { showPostConfirmation = false },
            title = {
                Text("POST STOCK OPNAME", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "Apakah Anda yakin ingin melakukan POST Stock Opname ${sop.documentNo}?\n\n" +
                            "• Stok inventory master akan diperbarui secara permanen sesuai hasil fisik final.\n" +
                            "• Mutasi stok (Stock Movement) dengan referensi SOP akan dicatat ke ledger.\n" +
                            "• Dokumen POST-YYYYMMDD-XXX akan diterbitkan secara atomic.\n" +
                            "• Dokumen SOP akan dikunci (POSTED) dan menjadi immutable.\n\n" +
                            "Tindakan ini tidak dapat dibatalkan.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPostConfirmation = false
                        viewModel.postStockOpname(sop.sopId) { createdPosting ->
                            if (createdPosting != null) {
                                onBack()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                    modifier = Modifier.testTag("confirm_post_sop_btn")
                ) {
                    Text("Ya, Post Sekarang")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPostConfirmation = false }) {
                    Text("Batal")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Adjustment: ${sop.documentNo}",
                canNavigateBack = true,
                onNavigateBack = onBack
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Button(
                        onClick = { showPostConfirmation = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("post_stock_opname_button")
                    ) {
                        Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("POST STOCK OPNAME")
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                SearchBarField(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "Cari SKU untuk adjustment..."
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredItems, key = { it.skuId }) { item ->
                    val diff = (item.physicalQty ?: item.systemQtySnapshot) - item.systemQtySnapshot
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedItemForEdit = item
                                inputRealStock = (item.physicalQty ?: item.systemQtySnapshot).toString()
                                inputReason = item.adjustmentReason
                            }
                            .testTag("adjust_item_${item.skuId}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.skuId,
                                    fontWeight = FontWeight.Bold,
                                    color = DustyPinkPrimary
                                )
                                Text(
                                    text = item.itemName,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "System: ${item.systemQtySnapshot}  •  Fisik: ${item.physicalQty ?: item.systemQtySnapshot}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (item.adjustmentReason.isNotBlank()) {
                                    Text(
                                        text = "Alasan: ${item.adjustmentReason}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (diff > 0) "+$diff" else "$diff",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = when {
                                        diff < 0 -> StatusDangerRed
                                        diff > 0 -> StatusSuccessGreen
                                        else -> Color.Gray
                                    }
                                )
                                Text(
                                    text = "Difference",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                                Text(
                                    text = "Tap to edit",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = DustyPinkPrimary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryReportTabContent(
    stockOpnames: List<StockOpname>,
    sopPostings: List<SopPosting>,
    isRootAdmin: Boolean,
    viewModel: WmsViewModel,
    onViewAudit: (String) -> Unit
) {
    if (stockOpnames.isEmpty()) {
        EmptyStateView(
            title = "Belum Ada Riwayat",
            description = "Belum ada dokumen Stock Opname yang tercatat"
        )
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(stockOpnames, key = { it.sopId }) { sop ->
                val posting = sopPostings.firstOrNull { it.sopId == sop.sopId || it.sopDocumentNo == sop.documentNo }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = sop.documentNo,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = DustyPinkPrimary
                            )
                            Badge(
                                containerColor = if (sop.status == "POSTED") StatusSuccessGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = sop.status,
                                    color = if (sop.status == "POSTED") StatusSuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        if (sop.postingId.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Posting No: ${sop.postingId}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = StatusSuccessGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "Tanggal: ${sop.opnameDate}", style = MaterialTheme.typography.bodySmall)
                        Text(text = "Initialized By: ${sop.initializedBy}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        if (sop.postedBy.isNotBlank()) {
                            Text(text = "Posted By: ${sop.postedBy}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }

                        val totalDiff = sop.items.sumOf { (it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Total SKU: ${sop.totalSku}  |  Net Diff: ${if (totalDiff > 0) "+$totalDiff" else "$totalDiff"} pcs",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )

                        // Action Buttons for Reports & Audit
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // SOP Report PDF
                            OutlinedButton(
                                onClick = { viewModel.generateAndShareSopPdf(sop) },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("report_sop_pdf_${sop.sopId}")
                            ) {
                                Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("SOP PDF", fontSize = 11.sp)
                            }

                            // If Posted: POST PDF & Excel
                            if (posting != null || sop.status == "POSTED") {
                                OutlinedButton(
                                    onClick = {
                                        val p = posting ?: SopPosting(
                                            postingId = sop.postingId,
                                            documentNo = sop.postingId,
                                            sopId = sop.sopId,
                                            sopDocumentNo = sop.documentNo,
                                            date = sop.opnameDate,
                                            postedBy = sop.postedBy,
                                            totalSku = sop.totalSku,
                                            items = sop.items.map {
                                                PostingItem(
                                                    sku = it.skuId,
                                                    itemName = it.itemName,
                                                    stockBefore = it.systemQtySnapshot,
                                                    physicalCount = it.physicalQty ?: it.systemQtySnapshot,
                                                    adjustment = (it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot,
                                                    stockAfter = it.physicalQty ?: it.systemQtySnapshot
                                                )
                                            }
                                        )
                                        viewModel.generateAndSharePostPdf(p, sop)
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("report_post_pdf_${sop.sopId}")
                                ) {
                                    Icon(imageVector = Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("POST PDF", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        val p = posting ?: SopPosting(
                                            postingId = sop.postingId,
                                            documentNo = sop.postingId,
                                            sopId = sop.sopId,
                                            sopDocumentNo = sop.documentNo,
                                            date = sop.opnameDate,
                                            postedBy = sop.postedBy,
                                            totalSku = sop.totalSku,
                                            items = sop.items.map {
                                                PostingItem(
                                                    sku = it.skuId,
                                                    itemName = it.itemName,
                                                    stockBefore = it.systemQtySnapshot,
                                                    physicalCount = it.physicalQty ?: it.systemQtySnapshot,
                                                    adjustment = (it.physicalQty ?: it.systemQtySnapshot) - it.systemQtySnapshot,
                                                    stockAfter = it.physicalQty ?: it.systemQtySnapshot
                                                )
                                            }
                                        )
                                        viewModel.exportAndSharePostExcel(p)
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("report_post_excel_${sop.sopId}")
                                ) {
                                    Icon(imageVector = Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Excel", fontSize = 11.sp)
                                }
                            }

                            // Audit trail button
                            IconButton(
                                onClick = { onViewAudit(sop.documentNo) },
                                modifier = Modifier.testTag("audit_btn_${sop.sopId}")
                            ) {
                                Icon(imageVector = Icons.Default.History, contentDescription = "Audit Trail")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuditTrailDialog(
    documentNo: String,
    viewModel: WmsViewModel,
    onDismiss: () -> Unit
) {
    val auditTrails by viewModel.getAuditTrails(documentNo).collectAsState(initial = emptyList())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Audit Trail: $documentNo", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
            ) {
                if (auditTrails.isEmpty()) {
                    Text("Memuat log audit trail...", color = TextMuted)
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(auditTrails) { log ->
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = log.action,
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                            color = DustyPinkPrimary
                                        )
                                        val timeStr = log.timestamp?.toDate()?.let {
                                            SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(it)
                                        } ?: ""
                                        Text(text = timeStr, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${log.userId} (${log.role})",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (log.reason.isNotBlank()) {
                                        Text(text = log.reason, style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (log.oldPhysicalQty != null && log.newPhysicalQty != null) {
                                        Text(
                                            text = "Qty: ${log.oldPhysicalQty} -> ${log.newPhysicalQty}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = StatusSuccessGreen
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Tutup")
            }
        }
    )
}
