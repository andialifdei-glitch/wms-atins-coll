package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = DustyPinkPrimary,
    onPrimary = Color.White,
    primaryContainer = DustyPinkContainer,
    onPrimaryContainer = OnDustyPinkContainer,
    secondary = SoftSecondary,
    onSecondary = Color.White,
    secondaryContainer = SecondaryContainer,
    onSecondaryContainer = OnDustyPinkContainer,
    background = SoftGrayBg,
    onBackground = TextDark,
    surface = CardSurface,
    onSurface = TextDark,
    surfaceVariant = Color(0xFFF3ECEE),
    onSurfaceVariant = TextMuted,
    outline = BorderLight
)

private val DarkColorScheme = darkColorScheme(
    primary = DustyPinkLight,
    onPrimary = Color(0xFF4A1024),
    primaryContainer = DustyPinkDark,
    onPrimaryContainer = Color(0xFFFFD9E2),
    secondary = Color(0xFFE4BDC6),
    onSecondary = Color(0xFF432931),
    background = Color(0xFF1B1416),
    onBackground = Color(0xFFEDE0E2),
    surface = Color(0xFF241B1E),
    onSurface = Color(0xFFEDE0E2),
    surfaceVariant = Color(0xFF3B2E32),
    onSurfaceVariant = Color(0xFFD2C2C6)
)

@Composable
fun WmsAtinTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
