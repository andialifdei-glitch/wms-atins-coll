package com.example.ui.screens.inventory

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Family
import com.example.data.models.Product
import com.example.data.models.StockAdjustment
import com.example.data.models.UserRole
import com.example.ui.WmsViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.LoadingDialog
import com.example.ui.components.SearchBarField
import com.example.ui.components.WmsTopBar
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    viewModel: WmsViewModel,
    onNavigateBack: () -> Unit
) {
    var selectedSection by remember { mutableIntStateOf(0) }
    // 0 = Produk & Stok, 1 = Family, 2 = Penyesuaian Stok, 3 = Kerusakan (Breakage), 4 = Return, 5 = Histori Mutasi

    val products by viewModel.products.collectAsState()
    val families by viewModel.families.collectAsState()
    val stockMovements by viewModel.stockMovements.collectAsState()
    val stockAdjustments by viewModel.stockAdjustments.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val isRootAdmin = currentUser?.role == UserRole.ROOT_ADMIN.label

    var showAddProductDialog by remember { mutableStateOf(false) }
    var showAddFamilyDialog by remember { mutableStateOf(false) }
    var selectedProductForDetail by remember { mutableStateOf<Product?>(null) }
    var selectedProductForEdit by remember { mutableStateOf<Product?>(null) }
    var selectedFamilyForEdit by remember { mutableStateOf<Family?>(null) }
    var familyToDelete by remember { mutableStateOf<Family?>(null) }

    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

    if (isLoading) {
        LoadingDialog("Memproses database...")
    }

    // Dialog: Tambah Family
    if (showAddFamilyDialog) {
        AddFamilyDialog(
            viewModel = viewModel,
            onDismiss = { showAddFamilyDialog = false }
        )
    }

    // Dialog: Tambah Produk
    if (showAddProductDialog) {
        AddProductDialog(
            viewModel = viewModel,
            families = families,
            onDismiss = { showAddProductDialog = false },
            onAddFamilyRequested = { showAddFamilyDialog = true }
        )
    }

    // Dialog: Product Detail / View Only (Section B1)
    if (selectedProductForDetail != null) {
        ProductDetailDialog(
            product = selectedProductForDetail!!,
            isRootAdmin = isRootAdmin,
            viewModel = viewModel,
            onEditRequested = {
                val p = selectedProductForDetail!!
                selectedProductForDetail = null
                selectedProductForEdit = p
            },
            onDismiss = { selectedProductForDetail = null }
        )
    }

    // Dialog: Edit Produk (Section B2 - Root Admin only)
    if (selectedProductForEdit != null && isRootAdmin) {
        EditProductDialog(
            product = selectedProductForEdit!!,
            viewModel = viewModel,
            onDismiss = { selectedProductForEdit = null }
        )
    }

    // Dialog: Edit Family (Section E - Root Admin only)
    if (selectedFamilyForEdit != null && isRootAdmin) {
        EditFamilyDialog(
            family = selectedFamilyForEdit!!,
            families = families,
            viewModel = viewModel,
            onDismiss = { selectedFamilyForEdit = null }
        )
    }

    // Dialog: Hapus Family Confirmation (Section F - Root Admin only)
    if (familyToDelete != null && isRootAdmin) {
        AlertDialog(
            onDismissRequest = { familyToDelete = null },
            title = { Text("Hapus Family?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Data family '${familyToDelete?.familyName} (${familyToDelete?.familyCode})' akan dihapus.\nApakah Anda yakin?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val code = familyToDelete!!.familyCode
                        familyToDelete = null
                        viewModel.deleteFamily(code) { success -> }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
                    modifier = Modifier.testTag("confirm_delete_family_btn")
                ) {
                    Text("Hapus")
                }
            },
            dismissButton = {
                TextButton(onClick = { familyToDelete = null }) {
                    Text("Batal")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            WmsTopBar(
                title = "Inventory & Persediaan",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                isOnline = isOnline
            )
        },
        floatingActionButton = {
            if (selectedSection == 0) {
                FloatingActionButton(
                    onClick = { showAddProductDialog = true },
                    containerColor = DustyPinkPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_add_product")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah Produk")
                }
            } else if (selectedSection == 1) {
                FloatingActionButton(
                    onClick = { showAddFamilyDialog = true },
                    containerColor = DustyPinkPrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_add_family")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah Family")
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Horizontal scrollable section chips
            ScrollableTabRow(
                selectedTabIndex = selectedSection,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = DustyPinkPrimary
            ) {
                Tab(
                    selected = selectedSection == 0,
                    onClick = { selectedSection = 0 },
                    text = { Text("Produk & Stok (${products.size})") },
                    modifier = Modifier.testTag("inventory_tab_products")
                )
                Tab(
                    selected = selectedSection == 1,
                    onClick = { selectedSection = 1 },
                    text = { Text("Family (${families.size})") },
                    modifier = Modifier.testTag("inventory_tab_family")
                )
                Tab(
                    selected = selectedSection == 2,
                    onClick = { selectedSection = 2 },
                    text = { Text("Stock Adjustment") },
                    modifier = Modifier.testTag("inventory_tab_adjustment")
                )
                Tab(
                    selected = selectedSection == 3,
                    onClick = { selectedSection = 3 },
                    text = { Text("Breakage (Rusak)") },
                    modifier = Modifier.testTag("inventory_tab_breakage")
                )
                Tab(
                    selected = selectedSection == 4,
                    onClick = { selectedSection = 4 },
                    text = { Text("Return") },
                    modifier = Modifier.testTag("inventory_tab_return")
                )
                Tab(
                    selected = selectedSection == 5,
                    onClick = { selectedSection = 5 },
                    text = { Text("Histori Mutasi") },
                    modifier = Modifier.testTag("inventory_tab_movement")
                )
            }

            // Section Body
            when (selectedSection) {
                0 -> ProductsListView(
                    products = products,
                    families = families,
                    onProductClick = { selectedProductForDetail = it }
                )
                1 -> FamiliesListView(
                    families = families,
                    isRootAdmin = isRootAdmin,
                    onAddFamily = { showAddFamilyDialog = true },
                    onEditFamily = { selectedFamilyForEdit = it },
                    onDeleteFamily = { familyToDelete = it }
                )
                2 -> StockAdjustmentScreenView(
                    viewModel = viewModel,
                    products = products,
                    adjustments = stockAdjustments
                )
                3 -> BreakageFormView(
                    viewModel = viewModel,
                    products = products
                )
                4 -> ReturnFormView(
                    viewModel = viewModel,
                    products = products
                )
                5 -> StockMovementListView(
                    movements = stockMovements
                )
            }
        }
    }
}

// -------------------------------------------------------------
// SUB-VIEWS
// -------------------------------------------------------------

@Composable
fun ProductsListView(
    products: List<Product>,
    families: List<Family>,
    onProductClick: (Product) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf("Semua") } // "Semua", "Aktif", "Nonaktif", "Tidak Valid"
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    val familyNameMap = remember(families) { families.associate { it.familyCode to it.familyName } }

    val filteredProducts = products.filter { prod ->
        val matchesSearch = prod.sku.contains(searchQuery, ignoreCase = true) ||
            prod.itemName.contains(searchQuery, ignoreCase = true) ||
            prod.familyCode.contains(searchQuery, ignoreCase = true) ||
            (familyNameMap[prod.familyCode] ?: "").contains(searchQuery, ignoreCase = true) ||
            prod.masterStatusLabel.contains(searchQuery, ignoreCase = true)

        val matchesStatus = when (selectedStatusFilter) {
            "Aktif" -> prod.active == true
            "Nonaktif" -> prod.active == false
            "Tidak Valid" -> prod.active == null
            else -> true
        }

        matchesSearch && matchesStatus
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.padding(16.dp)) {
            SearchBarField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Cari SKU, Nama Produk, Family, Status...",
                testTag = "product_search_bar"
            )
        }

        // Status Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Semua", "Aktif", "Nonaktif", "Tidak Valid").forEach { filterOption ->
                FilterChip(
                    selected = selectedStatusFilter == filterOption,
                    onClick = { selectedStatusFilter = filterOption },
                    label = { Text(filterOption) },
                    modifier = Modifier.testTag("filter_status_${filterOption.lowercase().replace(" ", "_")}"),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = when (filterOption) {
                            "Aktif" -> StatusSuccessGreen.copy(alpha = 0.2f)
                            "Nonaktif" -> StatusDangerRed.copy(alpha = 0.2f)
                            "Tidak Valid" -> StatusWarningOrange.copy(alpha = 0.2f)
                            else -> DustyPinkPrimary.copy(alpha = 0.2f)
                        },
                        selectedLabelColor = when (filterOption) {
                            "Aktif" -> StatusSuccessGreen
                            "Nonaktif" -> StatusDangerRed
                            "Tidak Valid" -> StatusWarningOrange
                            else -> DustyPinkPrimary
                        }
                    )
                )
            }
        }

        if (filteredProducts.isEmpty()) {
            EmptyStateView(
                title = if (searchQuery.isEmpty() && selectedStatusFilter == "Semua") "Belum ada Produk" else "Produk tidak ditemukan",
                description = "Klik tombol '+' di pojok kanan bawah untuk menambah produk baru"
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredProducts, key = { it.sku }) { prod ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onProductClick(prod) }
                            .testTag("product_card_${prod.sku}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        color = DustyPinkPrimary.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "${prod.familyCode} • ${familyNameMap[prod.familyCode] ?: "Family"}",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = DustyPinkPrimary,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }

                                    // Status Master Badge based strictly on field `active`
                                    Surface(
                                        color = when (prod.active) {
                                            true -> StatusSuccessGreen.copy(alpha = 0.15f)
                                            false -> StatusDangerRed.copy(alpha = 0.15f)
                                            null -> StatusWarningOrange.copy(alpha = 0.15f)
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = prod.masterStatusLabel,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = when (prod.active) {
                                                true -> StatusSuccessGreen
                                                false -> StatusDangerRed
                                                null -> StatusWarningOrange
                                            },
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = prod.sku,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = prod.itemName,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Stok: ${prod.stock} pcs",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = when {
                                            prod.stock <= 0 -> StatusDangerRed
                                            prod.stock < 10 -> StatusWarningOrange
                                            else -> StatusSuccessGreen
                                        }
                                    )
                                )
                                Text(
                                    text = "Harga: ${rupiahFormat.format(prod.netPrice)}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Text(
                                text = "Beli: ${rupiahFormat.format(prod.purchasingPrice)} • Last Recv: ${prod.lastReceiving}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FamiliesListView(
    families: List<Family>,
    isRootAdmin: Boolean,
    onAddFamily: () -> Unit,
    onEditFamily: (Family) -> Unit,
    onDeleteFamily: (Family) -> Unit
) {
    if (families.isEmpty()) {
        EmptyStateView(
            title = "Belum ada Family",
            description = "Family digunakan untuk mengelompokkan produk dan membuat penomoran SKU otomatis.",
            actionButtonText = if (isRootAdmin) "+ Tambah Family" else null,
            onActionClick = if (isRootAdmin) onAddFamily else null
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(families, key = { it.familyCode }) { fam ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth().testTag("family_card_${fam.familyCode}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = fam.familyCode,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = DustyPinkPrimary
                                )
                            )
                            Text(
                                text = fam.familyName,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }

                        if (isRootAdmin) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { onEditFamily(fam) },
                                    modifier = Modifier.testTag("edit_family_${fam.familyCode}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Family",
                                        tint = DustyPinkPrimary
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteFamily(fam) },
                                    modifier = Modifier.testTag("delete_family_${fam.familyCode}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus Family",
                                        tint = StatusDangerRed
                                    )
                                }
                            }
                        } else {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Active",
                                tint = StatusSuccessGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditFamilyDialog(
    family: Family,
    families: List<Family>,
    viewModel: WmsViewModel,
    onDismiss: () -> Unit
) {
    var familyCode by remember { mutableStateOf(family.familyCode) }
    var familyName by remember { mutableStateOf(family.familyName) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Family", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Perubahan Kode dan Nama Family harus unik dan tidak boleh sama dengan Family lain.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = familyCode,
                    onValueChange = {
                        familyCode = it.uppercase()
                        errorMsg = null
                    },
                    label = { Text("Kode Family *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_family_code_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = familyName,
                    onValueChange = {
                        familyName = it
                        errorMsg = null
                    },
                    label = { Text("Nama Family *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_family_name_input")
                )
                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = errorMsg!!, color = StatusDangerRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmedCode = familyCode.trim().uppercase()
                    val trimmedName = familyName.trim()
                    if (trimmedCode.isBlank()) {
                        errorMsg = "Kode Family tidak boleh kosong"
                        return@Button
                    }
                    if (trimmedName.isBlank()) {
                        errorMsg = "Nama Family tidak boleh kosong"
                        return@Button
                    }

                    // Uniqueness validation (Section D & E)
                    val nameDuplicate = families.any {
                        it.familyCode != family.familyCode &&
                        it.familyName.equals(trimmedName, ignoreCase = true)
                    }
                    if (nameDuplicate) {
                        errorMsg = "Nama Family '$trimmedName' sudah digunakan oleh Family lain"
                        return@Button
                    }

                    val codeDuplicate = families.any {
                        it.familyCode != family.familyCode &&
                        it.familyCode.equals(trimmedCode, ignoreCase = true)
                    }
                    if (codeDuplicate) {
                        errorMsg = "Kode Family '$trimmedCode' sudah digunakan oleh Family lain"
                        return@Button
                    }

                    viewModel.updateFamily(family.familyId, trimmedCode, trimmedName) { success ->
                        if (success) onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                modifier = Modifier.testTag("submit_edit_family_btn")
            ) {
                Text("Simpan Perubahan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun ProductDetailDialog(
    product: Product,
    isRootAdmin: Boolean,
    viewModel: WmsViewModel? = null,
    onEditRequested: () -> Unit,
    onDismiss: () -> Unit
) {
    val rupiahFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "Detail Produk", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                Surface(
                    color = DustyPinkPrimary.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = product.sku, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = DustyPinkPrimary)
                        Text(text = product.itemName, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                        Text(text = "Family: ${product.familyCode}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Stok Fisik Gudang:", style = MaterialTheme.typography.bodyMedium)
                    Text("${product.stock} pcs", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = if (product.stock > 0) StatusSuccessGreen else StatusDangerRed)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Berat Satuan:", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = if (product.weightInGrams > 0) "${product.weightInGrams} gram" else "Belum Diisi (Nonaktif untuk transaksi)",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = if (product.weightInGrams > 0) MaterialTheme.colorScheme.onSurface else StatusDangerRed
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Harga Beli (HPP):", style = MaterialTheme.typography.bodyMedium)
                    Text(rupiahFormat.format(product.purchasingPrice), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Harga Jual (Net):", style = MaterialTheme.typography.bodyMedium)
                    Text(rupiahFormat.format(product.netPrice), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = DustyPinkPrimary)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Status Master:", style = MaterialTheme.typography.bodyMedium)
                    Surface(
                        color = when (product.active) {
                            true -> StatusSuccessGreen.copy(alpha = 0.15f)
                            false -> StatusDangerRed.copy(alpha = 0.15f)
                            null -> StatusWarningOrange.copy(alpha = 0.15f)
                        },
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = product.masterStatusLabel,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = when (product.active) {
                                true -> StatusSuccessGreen
                                false -> StatusDangerRed
                                null -> StatusWarningOrange
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                if (isRootAdmin && viewModel != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    if (product.active == true) {
                        OutlinedButton(
                            onClick = {
                                viewModel.toggleProductStatus(product.sku, false) { success ->
                                    if (success) onDismiss()
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDangerRed),
                            border = BorderStroke(1.dp, StatusDangerRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("toggle_status_deactivate_btn")
                        ) {
                            Text("Nonaktifkan Produk")
                        }
                    } else {
                        Button(
                            onClick = {
                                viewModel.toggleProductStatus(product.sku, true) { success ->
                                    if (success) onDismiss()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("toggle_status_activate_btn")
                        ) {
                            Text("Aktifkan Produk")
                        }
                    }
                }
                if (!isRootAdmin) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Mode View Only (Hanya Root Admin yang berhak mengedit data master produk).",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
            }
        },
        confirmButton = {
            if (isRootAdmin) {
                Button(
                    onClick = onEditRequested,
                    colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                    modifier = Modifier.testTag("product_detail_edit_btn")
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Edit Data Produk")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.testTag("product_detail_close_btn")) {
                Text("Tutup")
            }
        }
    )
}

@Composable
fun AddFamilyDialog(
    viewModel: WmsViewModel,
    onDismiss: () -> Unit
) {
    var familyName by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Family Baru", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Kode Family (FAM-001, FAM-002, dll) akan dibuat secara otomatis dan atomic oleh sistem.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = familyName,
                    onValueChange = {
                        familyName = it
                        errorMsg = null
                    },
                    label = { Text("Nama Family (misal: Daster, Kulot)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_family_name_input")
                )
                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = errorMsg!!, color = StatusDangerRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (familyName.trim().isBlank()) {
                        errorMsg = "Nama Family tidak boleh kosong"
                        return@Button
                    }
                    viewModel.createFamily(familyName) { success ->
                        if (success) onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                modifier = Modifier.testTag("dialog_save_family_button")
            ) {
                Text("Simpan Family")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProductDialog(
    viewModel: WmsViewModel,
    families: List<Family>,
    onDismiss: () -> Unit,
    onAddFamilyRequested: () -> Unit
) {
    var selectedFamilyCode by remember { mutableStateOf("") }
    var familySearchQuery by remember { mutableStateOf("") }
    var itemName by remember { mutableStateOf("") }
    var purchasingPriceStr by remember { mutableStateOf("") }
    var netPriceStr by remember { mutableStateOf("") }
    var weightInGramsStr by remember { mutableStateOf("") }
    var initialStockStr by remember { mutableStateOf("0") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val selectedFamily = families.find { it.familyCode == selectedFamilyCode }

    val filteredFamilies = remember(familySearchQuery, families) {
        if (familySearchQuery.isBlank()) {
            families.take(5)
        } else {
            families.filter { fam ->
                fam.familyName.contains(familySearchQuery, ignoreCase = true) ||
                fam.familyCode.contains(familySearchQuery, ignoreCase = true)
            }.take(8)
        }
    }

    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Produk Baru", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                Text(
                    text = "SKU akan dibuat otomatis dengan format SKU-[FFF][PPP] berdasarkan Family terpilih.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Family Selection with Search Bar (Part B)
                Text("Family *", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))

                if (selectedFamily != null) {
                    // Selected Family Display Card (Compact, with clear [X] button)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DustyPinkPrimary.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, DustyPinkPrimary.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("selected_family_display")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Category,
                                    contentDescription = null,
                                    tint = DustyPinkPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = selectedFamily.familyName,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = selectedFamily.familyCode,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = DustyPinkPrimary
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    selectedFamilyCode = ""
                                    familySearchQuery = ""
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("clear_selected_family_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Ganti Family",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                } else {
                    // Family Search Bar
                    OutlinedTextField(
                        value = familySearchQuery,
                        onValueChange = {
                            familySearchQuery = it
                            errorMsg = null
                        },
                        placeholder = { Text("🔍 Cari Family (nama atau kode)...", style = MaterialTheme.typography.bodyMedium) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Cari", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        },
                        trailingIcon = {
                            if (familySearchQuery.isNotEmpty()) {
                                IconButton(onClick = { familySearchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(18.dp))
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("family_search_input")
                    )

                    // Search Results Suggestions
                    if (families.isEmpty()) {
                        Text(
                            text = "Belum ada master Family. Silakan buat Family baru terlebih dahulu.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    } else if (familySearchQuery.isNotBlank() && filteredFamilies.isEmpty()) {
                        Text(
                            text = "Tidak ditemukan Family dengan kata kunci '$familySearchQuery'",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    } else if (filteredFamilies.isNotEmpty()) {
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                        ) {
                            Column {
                                if (familySearchQuery.isBlank()) {
                                    Text(
                                        text = "Pilih Family atau ketik untuk mencari:",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted,
                                        modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 4.dp)
                                    )
                                }
                                filteredFamilies.forEachIndexed { index, fam ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selectedFamilyCode = fam.familyCode
                                                familySearchQuery = ""
                                                errorMsg = null
                                            }
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                            .testTag("family_result_${fam.familyCode}"),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(
                                                text = fam.familyName,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                            )
                                            Text(
                                                text = fam.familyCode,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = DustyPinkPrimary
                                            )
                                        }
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = DustyPinkPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    if (index < filteredFamilies.size - 1) {
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                    }
                                }
                            }
                        }
                    }

                    // Secondary action: + Tambah Family Baru
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = onAddFamilyRequested,
                            modifier = Modifier.testTag("add_new_family_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tambah Family Baru", fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = itemName,
                    onValueChange = {
                        itemName = it
                        errorMsg = null
                    },
                    label = { Text("Nama Barang / Produk *") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_product_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = purchasingPriceStr,
                    onValueChange = { purchasingPriceStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Harga Beli (Rp) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_product_purchasing_price_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = netPriceStr,
                    onValueChange = { netPriceStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Harga Jual Net (Rp) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_product_net_price_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = weightInGramsStr,
                    onValueChange = { weightInGramsStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Berat Produk (gram) *") },
                    placeholder = { Text("Contoh: 250") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_product_weight_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = initialStockStr,
                    onValueChange = { initialStockStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Stok Awal (pcs)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_product_stock_input")
                )

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMsg!!, color = StatusDangerRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedFamilyCode.isBlank()) {
                        errorMsg = "Family harus dipilih"
                        return@Button
                    }
                    if (itemName.trim().isBlank()) {
                        errorMsg = "Nama barang harus diisi"
                        return@Button
                    }
                    val buyPrice = purchasingPriceStr.toLongOrNull() ?: 0L
                    val sellPrice = netPriceStr.toLongOrNull() ?: 0L
                    val weight = weightInGramsStr.toIntOrNull() ?: 0
                    if (weight <= 0) {
                        errorMsg = "Berat produk wajib diisi angka valid dalam gram (> 0)"
                        return@Button
                    }
                    val stock = initialStockStr.toIntOrNull() ?: 0

                    viewModel.createProduct(
                        familyCode = selectedFamilyCode,
                        itemName = itemName,
                        purchasingPrice = buyPrice,
                        netPrice = sellPrice,
                        initialStock = stock,
                        weightInGrams = weight
                    ) { success ->
                        if (success) onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
                modifier = Modifier.testTag("add_product_submit_button")
            ) {
                Text("Simpan Produk")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun EditProductDialog(
    product: Product,
    viewModel: WmsViewModel,
    onDismiss: () -> Unit
) {
    var itemName by remember { mutableStateOf(product.itemName) }
    var purchasingPriceStr by remember { mutableStateOf(product.purchasingPrice.toString()) }
    var netPriceStr by remember { mutableStateOf(product.netPrice.toString()) }
    var weightInGramsStr by remember { mutableStateOf(if (product.weightInGrams > 0) product.weightInGrams.toString() else "") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Produk ${product.sku}", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Family: ${product.familyCode} | SKU: ${product.sku} (Permanen)",
                    style = MaterialTheme.typography.labelSmall,
                    color = DustyPinkPrimary,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = itemName,
                    onValueChange = { itemName = it },
                    label = { Text("Nama Barang") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_product_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = weightInGramsStr,
                    onValueChange = { weightInGramsStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Berat Produk (gram)") },
                    placeholder = { Text("Contoh: 250") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_product_weight_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = purchasingPriceStr,
                    onValueChange = { purchasingPriceStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Harga Beli (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_product_purchasing_price_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = netPriceStr,
                    onValueChange = { netPriceStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Harga Jual Net (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_product_net_price_input")
                )

                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMsg!!, color = StatusDangerRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val buy = purchasingPriceStr.toLongOrNull() ?: product.purchasingPrice
                    val sell = netPriceStr.toLongOrNull() ?: product.netPrice
                    val weight = weightInGramsStr.toIntOrNull() ?: product.weightInGrams
                    if (weight <= 0) {
                        errorMsg = "Berat produk wajib diisi angka valid dalam gram (> 0)"
                        return@Button
                    }
                    viewModel.updateProduct(product.sku, itemName, buy, sell, weight) { success ->
                        if (success) onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary)
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

// -------------------------------------------------------------
// STOCK ADJUSTMENT SCREEN VIEW (WEB PORTAL INITIALIZED + MANUAL)
// -------------------------------------------------------------
@Composable
fun StockAdjustmentScreenView(
    viewModel: WmsViewModel,
    products: List<Product>,
    adjustments: List<StockAdjustment>
) {
    var subTab by remember { mutableIntStateOf(0) } // 0: Antrian Inisialisasi Web, 1: Form Manual, 2: Riwayat
    val initializedAdjustments = adjustments.filter {
        it.status.equals("INITIALIZED", ignoreCase = true) || it.status.isBlank()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = subTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = DustyPinkPrimary
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Inisialisasi Web")
                        if (initializedAdjustments.isNotEmpty()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Badge(containerColor = StatusWarningOrange) {
                                Text(
                                    text = initializedAdjustments.size.toString(),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                )
                            }
                        }
                    }
                },
                modifier = Modifier.testTag("adj_subtab_initialized")
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Input Manual") },
                modifier = Modifier.testTag("adj_subtab_manual")
            )
            Tab(
                selected = subTab == 2,
                onClick = { subTab = 2 },
                text = { Text("Riwayat (${adjustments.size})") },
                modifier = Modifier.testTag("adj_subtab_history")
            )
        }

        when (subTab) {
            0 -> InitializedAdjustmentsListView(
                initializedList = initializedAdjustments,
                viewModel = viewModel,
                products = products
            )
            1 -> StockAdjustmentFormView(
                viewModel = viewModel,
                products = products
            )
            2 -> AdjustmentHistoryListView(
                adjustments = adjustments
            )
        }
    }
}

@Composable
fun InitializedAdjustmentsListView(
    initializedList: List<StockAdjustment>,
    viewModel: WmsViewModel,
    products: List<Product>
) {
    var adjustmentToConfirm by remember { mutableStateOf<StockAdjustment?>(null) }

    if (adjustmentToConfirm != null) {
        val targetAdj = adjustmentToConfirm!!
        val targetProd = products.find { it.sku == targetAdj.sku }
        val currentStk = targetProd?.stock ?: targetAdj.currentStock
        val isIncrease = targetAdj.adjustmentType.equals("INCREASE", ignoreCase = true)
        val calculatedNewStock = if (isIncrease) currentStk + targetAdj.adjustmentQty else currentStk - targetAdj.adjustmentQty

        AlertDialog(
            onDismissRequest = { adjustmentToConfirm = null },
            title = {
                Text("Konfirmasi Eksekusi Stok", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "Apakah petugas gudang menyetujui penyesuaian stok ini?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "SKU: ${targetAdj.sku}", fontWeight = FontWeight.Bold, color = DustyPinkPrimary)
                            Text(text = targetAdj.itemName.ifBlank { targetProd?.itemName ?: "-" }, style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Jenis: ${if (isIncrease) "TAMBAH STOK (+)" else "KURANGI STOK (-)"} ${targetAdj.adjustmentQty} pcs",
                                fontWeight = FontWeight.SemiBold,
                                color = if (isIncrease) StatusSuccessGreen else StatusDangerRed
                            )
                            Text(text = "Stok Saat Ini: $currentStk pcs", style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "Stok Setelah Eksekusi: $calculatedNewStock pcs",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = DustyPinkPrimary
                            )
                            if (targetAdj.reason.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "Alasan: ${targetAdj.reason}", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Sistem akan mengupdate stok secara atomik via Firestore Transaction, memperbarui status menjadi COMPLETED, dan mencatat mutasi stok (ADJUSTMENT).",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val adjId = targetAdj.adjustmentId
                        adjustmentToConfirm = null
                        viewModel.executeAdjustment(adjId) { }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                    modifier = Modifier.testTag("confirm_execute_adjustment_btn")
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Setujui & Eksekusi Stok")
                }
            },
            dismissButton = {
                TextButton(onClick = { adjustmentToConfirm = null }) {
                    Text("Batal")
                }
            }
        )
    }

    if (initializedList.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            EmptyStateView(
                title = "Tidak Ada Antrian Inisialisasi",
                description = "Saat ini tidak ada dokumen penyesuaian stok berstatus INITIALIZED dari Web Portal WMS."
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = StatusWarningOrange.copy(alpha = 0.12f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = StatusWarningOrange,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Ditemukan ${initializedList.size} penyesuaian stok yang diinisialisasi oleh Web Portal. Klik 'Konfirmasi Eksekusi' untuk mengupdate stok fisik secara atomik.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            items(initializedList, key = { it.adjustmentId }) { adj ->
                val prod = products.find { it.sku == adj.sku }
                val currentStk = prod?.stock ?: adj.currentStock
                val isIncrease = adj.adjustmentType.equals("INCREASE", ignoreCase = true)

                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("initialized_adj_card_${adj.adjustmentId}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = adj.sku,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = DustyPinkPrimary
                                )
                                Text(
                                    text = adj.itemName.ifBlank { prod?.itemName ?: "-" },
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Badge(
                                containerColor = StatusWarningOrange.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "INITIALIZED",
                                    color = StatusWarningOrange,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Penyesuaian: ${if (isIncrease) "+" else "-"}${adj.adjustmentQty} pcs",
                                fontWeight = FontWeight.Bold,
                                color = if (isIncrease) StatusSuccessGreen else StatusDangerRed
                            )
                            Text(
                                text = "Stok saat ini: $currentStk pcs",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        }

                        if (adj.reason.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Alasan: ${adj.reason}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (adj.notes.isNotBlank()) {
                            Text(
                                text = "Catatan: ${adj.notes}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { adjustmentToConfirm = adj },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusSuccessGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_execute_adj_${adj.adjustmentId}")
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("KONFIRMASI EKSEKUSI STOK")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdjustmentHistoryListView(
    adjustments: List<StockAdjustment>
) {
    if (adjustments.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            EmptyStateView(
                title = "Belum Ada Riwayat Penyesuaian",
                description = "Seluruh riwayat penyesuaian stok akan ditampilkan di sini."
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(adjustments, key = { it.adjustmentId }) { adj ->
                val isIncrease = adj.adjustmentType.equals("INCREASE", ignoreCase = true)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = adj.sku, fontWeight = FontWeight.Bold, color = DustyPinkPrimary)
                            Badge(
                                containerColor = when (adj.status.uppercase()) {
                                    "COMPLETED" -> StatusSuccessGreen.copy(alpha = 0.15f)
                                    "INITIALIZED" -> StatusWarningOrange.copy(alpha = 0.15f)
                                    "CANCELLED" -> StatusDangerRed.copy(alpha = 0.15f)
                                    else -> StatusBlue.copy(alpha = 0.15f)
                                }
                            ) {
                                Text(
                                    text = adj.status.ifBlank { "COMPLETED" },
                                    color = when (adj.status.uppercase()) {
                                        "COMPLETED" -> StatusSuccessGreen
                                        "INITIALIZED" -> StatusWarningOrange
                                        "CANCELLED" -> StatusDangerRed
                                        else -> StatusBlue
                                    },
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(text = adj.itemName, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${if (isIncrease) "+" else "-"}${adj.adjustmentQty} pcs (Stok: ${adj.currentStock} → ${adj.newStock})",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isIncrease) StatusSuccessGreen else StatusDangerRed
                        )
                        Text(
                            text = "Alasan: ${adj.reason} • Tgl: ${adj.date} • Oleh: ${adj.executedBy.ifBlank { adj.user }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// STOCK ADJUSTMENT FORM VIEW
// -------------------------------------------------------------
@Composable
fun StockAdjustmentFormView(
    viewModel: WmsViewModel,
    products: List<Product>
) {
    var selectedSku by remember { mutableStateOf("") }
    var adjustmentType by remember { mutableStateOf("INCREASE") } // INCREASE or DECREASE
    var qtyStr by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var productSearch by remember { mutableStateOf("") }
    var isProductPickerOpen by remember { mutableStateOf(false) }

    val selectedProduct = products.find { it.sku == selectedSku }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "Form Penyesuaian Stok (Stock Adjustment)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Penyesuaian stok akan otomatis menghasilkan record penyesuaian dan mutasi stok.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Product Selector
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Pilih Produk:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(6.dp))
                if (selectedProduct != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = selectedProduct.itemName, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${selectedProduct.sku} • Stok saat ini: ${selectedProduct.stock} pcs",
                                style = MaterialTheme.typography.bodySmall,
                                color = DustyPinkPrimary
                            )
                        }
                        TextButton(onClick = { isProductPickerOpen = true }) {
                            Text("Ganti")
                        }
                    }
                } else {
                    Button(
                        onClick = { isProductPickerOpen = true },
                        colors = ButtonDefaults.outlinedButtonColors()
                    ) {
                        Text("Pilih Produk dari Master")
                    }
                }
            }
        }

        if (isProductPickerOpen) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    SearchBarField(
                        query = productSearch,
                        onQueryChange = { productSearch = it },
                        placeholder = "Cari SKU atau nama..."
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    val filtered = products.filter {
                        it.sku.contains(productSearch, ignoreCase = true) ||
                        it.itemName.contains(productSearch, ignoreCase = true)
                    }
                    filtered.take(5).forEach { p ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedSku = p.sku
                                    isProductPickerOpen = false
                                }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = p.itemName, fontWeight = FontWeight.SemiBold)
                            Text(text = "${p.sku} (${p.stock} pcs)", style = MaterialTheme.typography.bodySmall)
                        }
                        HorizontalDivider(color = BorderLight)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Type
        Text("Jenis Penyesuaian:", style = MaterialTheme.typography.labelMedium)
        Row(modifier = Modifier.padding(vertical = 4.dp)) {
            FilterChip(
                selected = adjustmentType == "INCREASE",
                onClick = { adjustmentType = "INCREASE" },
                label = { Text("Tambah Stok (+)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StatusSuccessGreen,
                    selectedLabelColor = Color.White
                )
            )
            Spacer(modifier = Modifier.width(10.dp))
            FilterChip(
                selected = adjustmentType == "DECREASE",
                onClick = { adjustmentType = "DECREASE" },
                label = { Text("Kurangi Stok (-)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StatusDangerRed,
                    selectedLabelColor = Color.White
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = qtyStr,
            onValueChange = { qtyStr = it.filter { c -> c.isDigit() } },
            label = { Text("Jumlah Penyesuaian (pcs) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = reason,
            onValueChange = { reason = it },
            label = { Text("Alasan Penyesuaian (misal: Koreksi stok opname) *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            label = { Text("Catatan Tambahan (opsional)") },
            singleLine = false,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (selectedSku.isBlank()) {
                    viewModel.showMessage("Harap pilih produk")
                    return@Button
                }
                val qty = qtyStr.toIntOrNull() ?: 0
                if (qty <= 0) {
                    viewModel.showMessage("Jumlah penyesuaian harus lebih dari 0")
                    return@Button
                }
                if (reason.isBlank()) {
                    viewModel.showMessage("Alasan penyesuaian wajib diisi")
                    return@Button
                }

                viewModel.adjustStock(selectedSku, adjustmentType, qty, reason, notes) { success ->
                    if (success) {
                        qtyStr = ""
                        reason = ""
                        notes = ""
                    }
                }
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DustyPinkPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("SIMPAN PENYESUAIAN STOK")
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// -------------------------------------------------------------
// BREAKAGE FORM VIEW
// -------------------------------------------------------------
@Composable
fun BreakageFormView(
    viewModel: WmsViewModel,
    products: List<Product>
) {
    var selectedSku by remember { mutableStateOf("") }
    var qtyStr by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var productSearch by remember { mutableStateOf("") }
    var isPickerOpen by remember { mutableStateOf(false) }

    val selectedProduct = products.find { it.sku == selectedSku }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "Laporan Barang Rusak / Cacat (Breakage)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Pencatatan barang rusak akan otomatis memotong stok fisik dan mencatat mutasi stok.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Product Selector
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Pilih Produk Rusak:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(6.dp))
                if (selectedProduct != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = selectedProduct.itemName, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${selectedProduct.sku} • Stok saat ini: ${selectedProduct.stock} pcs",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusDangerRed
                            )
                        }
                        TextButton(onClick = { isPickerOpen = true }) {
                            Text("Ganti")
                        }
                    }
                } else {
                    Button(
                        onClick = { isPickerOpen = true },
                        colors = ButtonDefaults.outlinedButtonColors()
                    ) {
                        Text("Pilih Produk dari Master")
                    }
                }
            }
        }

        if (isPickerOpen) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    SearchBarField(
                        query = productSearch,
                        onQueryChange = { productSearch = it },
                        placeholder = "Cari SKU atau nama..."
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    products.filter {
                        it.sku.contains(productSearch, ignoreCase = true) ||
                        it.itemName.contains(productSearch, ignoreCase = true)
                    }.take(5).forEach { p ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedSku = p.sku
                                    isPickerOpen = false
                                }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = p.itemName, fontWeight = FontWeight.SemiBold)
                            Text(text = "${p.sku} (${p.stock} pcs)", style = MaterialTheme.typography.bodySmall)
                        }
                        HorizontalDivider(color = BorderLight)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = qtyStr,
            onValueChange = { qtyStr = it.filter { c -> c.isDigit() } },
            label = { Text("Jumlah Rusak / Cacat (pcs) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = reason,
            onValueChange = { reason = it },
            label = { Text("Alasan / Kerusakan (misal: Sobek, Noda, Jahitan Lepas) *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            label = { Text("Catatan Penanganan (opsional)") },
            singleLine = false,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (selectedSku.isBlank()) {
                    viewModel.showMessage("Pilih produk terlebih dahulu")
                    return@Button
                }
                val qty = qtyStr.toIntOrNull() ?: 0
                if (qty <= 0) {
                    viewModel.showMessage("Jumlah rusak harus lebih dari 0")
                    return@Button
                }
                if (reason.isBlank()) {
                    viewModel.showMessage("Alasan kerusakan wajib diisi")
                    return@Button
                }

                viewModel.recordBreakage(selectedSku, qty, reason, notes) { success ->
                    if (success) {
                        qtyStr = ""
                        reason = ""
                        notes = ""
                    }
                }
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(Icons.Default.BrokenImage, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("SIMPAN LAPORAN KERUSAKAN")
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// -------------------------------------------------------------
// RETURN FORM VIEW
// -------------------------------------------------------------
@Composable
fun ReturnFormView(
    viewModel: WmsViewModel,
    products: List<Product>
) {
    var returnType by remember { mutableStateOf("CUSTOMER") } // "CUSTOMER" or "SUPPLIER"
    var refNumber by remember { mutableStateOf("") }
    var partyName by remember { mutableStateOf("") }
    var selectedSku by remember { mutableStateOf("") }
    var qtyStr by remember { mutableStateOf("1") }
    var reason by remember { mutableStateOf("") }
    var condition by remember { mutableStateOf("Bagus (Kembali ke Stok)") }
    var notes by remember { mutableStateOf("") }
    var productSearch by remember { mutableStateOf("") }
    var isPickerOpen by remember { mutableStateOf(false) }

    var showConfirmDialog by remember { mutableStateOf(false) }
    var countdown by remember { mutableIntStateOf(10) }

    val selectedProduct = products.find { it.sku == selectedSku }
    val scrollState = rememberScrollState()

    LaunchedEffect(showConfirmDialog) {
        if (showConfirmDialog) {
            countdown = 10
            while (countdown > 0) {
                kotlinx.coroutines.delay(1000)
                countdown--
            }
        }
    }

    if (showConfirmDialog && selectedProduct != null) {
        val qty = qtyStr.toIntOrNull() ?: 1
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            title = {
                Text(
                    text = if (returnType == "CUSTOMER") "Konfirmasi Retur Customer?" else "Konfirmasi Retur Supplier?",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = if (returnType == "CUSTOMER")
                            "Stok fisik produk akan bertambah kembali ke gudang."
                        else
                            "Stok fisik produk akan dipotong dari gudang untuk dikembalikan ke supplier.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "No Referensi: $refNumber", fontWeight = FontWeight.SemiBold)
                    Text(text = if (returnType == "CUSTOMER") "Customer: $partyName" else "Supplier: $partyName")
                    Text(text = "Produk: ${selectedProduct.itemName} (${selectedProduct.sku})")
                    Text(text = "Jumlah: $qty pcs", fontWeight = FontWeight.Bold, color = if (returnType == "CUSTOMER") StatusSuccessGreen else StatusDangerRed)
                    Text(text = "Alasan: $reason")
                    if (notes.isNotBlank()) Text(text = "Catatan: $notes", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showConfirmDialog = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Batal")
                    }
                    Button(
                        onClick = {
                            showConfirmDialog = false
                            if (returnType == "CUSTOMER") {
                                viewModel.recordReturn(refNumber, partyName, selectedSku, qty, reason, condition, notes) { success ->
                                    if (success) {
                                        refNumber = ""
                                        partyName = ""
                                        qtyStr = "1"
                                        reason = ""
                                        notes = ""
                                    }
                                }
                            } else {
                                viewModel.recordSupplierReturn(refNumber, partyName, selectedSku, qty, reason, notes) { success ->
                                    if (success) {
                                        refNumber = ""
                                        partyName = ""
                                        qtyStr = "1"
                                        reason = ""
                                        notes = ""
                                    }
                                }
                            }
                        },
                        enabled = countdown == 0,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (returnType == "CUSTOMER") StatusSuccessGreen else StatusDangerRed
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("confirm_return_button")
                    ) {
                        Text(if (countdown > 0) "Posting Retur ($countdown)" else "Posting Retur")
                    }
                }
            },
            dismissButton = null
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "Form Pengembalian Barang (Return)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Pilih tipe retur untuk menyesuaikan mutasi stok gudang.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Return Type Tabs (Section M1 & M2)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = returnType == "CUSTOMER",
                onClick = { returnType = "CUSTOMER" },
                label = { Text("Retur Customer (Masuk)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StatusSuccessGreen,
                    selectedLabelColor = Color.White
                ),
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = returnType == "SUPPLIER",
                onClick = { returnType = "SUPPLIER" },
                label = { Text("Retur Supplier (Keluar)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = StatusDangerRed,
                    selectedLabelColor = Color.White
                ),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = refNumber,
            onValueChange = { refNumber = it },
            label = { Text(if (returnType == "CUSTOMER") "No Referensi / No Resi / No SO *" else "No Referensi / No PO / Surat Jalan *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = partyName,
            onValueChange = { partyName = it },
            label = { Text(if (returnType == "CUSTOMER") "Nama Customer *" else "Nama Supplier / Pabrik *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Product Selector
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Pilih Produk yang Diretur:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(6.dp))
                if (selectedProduct != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = selectedProduct.itemName, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${selectedProduct.sku} • Stok saat ini: ${selectedProduct.stock} pcs",
                                style = MaterialTheme.typography.bodySmall,
                                color = DustyPinkPrimary
                            )
                        }
                        TextButton(onClick = { isPickerOpen = true }) {
                            Text("Ganti")
                        }
                    }
                } else {
                    Button(
                        onClick = { isPickerOpen = true },
                        colors = ButtonDefaults.outlinedButtonColors()
                    ) {
                        Text("Pilih Produk dari Master")
                    }
                }
            }
        }

        if (isPickerOpen) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    SearchBarField(
                        query = productSearch,
                        onQueryChange = { productSearch = it },
                        placeholder = "Cari SKU atau nama..."
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    products.filter {
                        it.sku.contains(productSearch, ignoreCase = true) ||
                        it.itemName.contains(productSearch, ignoreCase = true)
                    }.take(5).forEach { p ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedSku = p.sku
                                    isPickerOpen = false
                                }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = p.itemName, fontWeight = FontWeight.SemiBold)
                            Text(text = "${p.sku} (${p.stock} pcs)", style = MaterialTheme.typography.bodySmall)
                        }
                        HorizontalDivider(color = BorderLight)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = qtyStr,
            onValueChange = { qtyStr = it.filter { c -> c.isDigit() } },
            label = { Text("Jumlah Retur (pcs) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = reason,
            onValueChange = { reason = it },
            label = { Text("Alasan Retur (misal: Salah ukuran, tukar warna) *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = condition,
            onValueChange = { condition = it },
            label = { Text("Kondisi Barang") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            label = { Text("Catatan Tambahan (opsional)") },
            singleLine = false,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (refNumber.isBlank()) {
                    viewModel.showMessage("No referensi wajib diisi")
                    return@Button
                }
                if (partyName.isBlank()) {
                    viewModel.showMessage(if (returnType == "CUSTOMER") "Nama customer wajib diisi" else "Nama supplier wajib diisi")
                    return@Button
                }
                if (selectedSku.isBlank()) {
                    viewModel.showMessage("Pilih produk terlebih dahulu")
                    return@Button
                }
                val qty = qtyStr.toIntOrNull() ?: 0
                if (qty <= 0) {
                    viewModel.showMessage("Jumlah retur harus lebih dari 0")
                    return@Button
                }
                if (reason.isBlank()) {
                    viewModel.showMessage("Alasan retur wajib diisi")
                    return@Button
                }

                showConfirmDialog = true
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (returnType == "CUSTOMER") StatusSuccessGreen else StatusDangerRed
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("submit_return_button")
        ) {
            Icon(Icons.Default.Replay, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (returnType == "CUSTOMER") "PROSES RETUR CUSTOMER (TAMBAH STOK)" else "PROSES RETUR SUPPLIER (POTONG STOK)")
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// -------------------------------------------------------------
// STOCK MOVEMENT LIST VIEW
// -------------------------------------------------------------
@Composable
fun StockMovementListView(
    movements: List<com.example.data.models.StockMovement>
) {
    if (movements.isEmpty()) {
        EmptyStateView(
            title = "Belum Ada Mutasi Stok",
            description = "Mutasi stok otomatis tercatat saat Receiving, Pengiriman DO, Adjustment, Return, dan Breakage."
        )
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(movements, key = { it.movementId }) { m ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = when (m.type) {
                                        "RECEIVING", "RETURN" -> StatusSuccessGreen.copy(alpha = 0.15f)
                                        "DELIVERY" -> StatusBlue.copy(alpha = 0.15f)
                                        "BREAKAGE" -> StatusDangerRed.copy(alpha = 0.15f)
                                        else -> StatusWarningOrange.copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = m.type,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = when (m.type) {
                                            "RECEIVING", "RETURN" -> StatusSuccessGreen
                                            "DELIVERY" -> StatusBlue
                                            "BREAKAGE" -> StatusDangerRed
                                            else -> StatusWarningOrange
                                        },
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = m.itemCode,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = m.itemNameSnapshot,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "${m.date} • Ref: ${m.referenceId} • User: ${m.user}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                            if (m.reason.isNotBlank()) {
                                Text(
                                    text = m.reason,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val qtyChange = if (m.qtyIn > 0) "+${m.qtyIn}" else "-${m.qtyOut}"
                            val qtyColor = if (m.qtyIn > 0) StatusSuccessGreen else StatusDangerRed
                            Text(
                                text = "$qtyChange pcs",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = qtyColor
                                )
                            )
                            Text(
                                text = "Stok: ${m.previousStock} → ${m.newStock}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}
