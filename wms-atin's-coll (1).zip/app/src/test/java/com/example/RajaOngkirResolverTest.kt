package com.example

import com.example.data.repositories.AdminRegionQuery
import com.example.data.repositories.RajaOngkirResolver
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RajaOngkirResolverTest {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val resolver = RajaOngkirResolver(httpClient = httpClient)

    @Test
    fun testNormalizationFunction() {
        assertEquals("karawang", RajaOngkirResolver.normalizeName("Kabupaten Karawang"))
        assertEquals("karawang", RajaOngkirResolver.normalizeName("Karawang"))
        assertEquals("bandung", RajaOngkirResolver.normalizeName("Kota Bandung"))
        assertEquals("bandung", RajaOngkirResolver.normalizeName("Bandung"))
        assertEquals("jayakerta", RajaOngkirResolver.normalizeName("Kec. Jayakerta"))
        assertEquals("jayakerta", RajaOngkirResolver.normalizeName("Kecamatan Jayakerta"))
        assertEquals("jawa barat", RajaOngkirResolver.normalizeName("Prov. Jawa Barat"))
    }

    @Test
    fun testRawQueryParsing() {
        val parsed = RajaOngkirResolver.parseRawQuery("Jayakerta, Kabupaten Karawang, Jawa Barat")
        assertEquals("Jayakerta", parsed.district)
        assertEquals("Kabupaten Karawang", parsed.regency)
        assertEquals("Jawa Barat", parsed.province)
    }

    @Test
    fun testPrimaryResolutionJayakertaKarawang() {
        // Customer: Jayakerta, Kabupaten Karawang, Jawa Barat
        val result = resolver.resolveLocation(
            district = "Jayakerta",
            regency = "Kabupaten Karawang",
            province = "Jawa Barat"
        )

        assertTrue("Resolution for Jayakerta must succeed", result.isSuccess)
        val loc = result.getOrThrow()
        assertNotNull(loc)
        // Verified RajaOngkir ID for Jayakerta, Karawang
        assertTrue("RajaOngkir ID must be in Jayakerta range", loc.id in 37948..37955)
        assertTrue("Label contains JAYAKERTA", loc.label.contains("JAYAKERTA", ignoreCase = true))
        assertTrue("City contains KARAWANG", loc.cityName.contains("KARAWANG", ignoreCase = true))
    }

    @Test
    fun testResolutionBanjaranBandungOrigin() {
        // Store Origin: Banjaran, Kabupaten Bandung
        val result = resolver.resolveLocation(
            district = "Banjaran",
            regency = "Kabupaten Bandung",
            province = "Jawa Barat"
        )

        assertTrue("Resolution for Banjaran must succeed", result.isSuccess)
        val loc = result.getOrThrow()
        assertNotNull(loc)
        assertTrue("City contains BANDUNG", loc.cityName.contains("BANDUNG", ignoreCase = true))
    }

    @Test
    fun testResolutionGenericOtherLocations() {
        // Test location 2: Coblong, Kota Bandung
        val resultCoblong = resolver.resolveLocation(
            district = "Coblong",
            regency = "Kota Bandung",
            province = "Jawa Barat"
        )
        assertTrue("Resolution for Coblong must succeed", resultCoblong.isSuccess)
        assertEquals("COBLONG", resultCoblong.getOrThrow().districtName)

        // Test location 3: Tebet, Kota Jakarta Selatan
        val resultTebet = resolver.resolveLocation(
            district = "Tebet",
            regency = "Kota Jakarta Selatan",
            province = "DKI Jakarta"
        )
        assertTrue("Resolution for Tebet must succeed", resultTebet.isSuccess)
        assertEquals("TEBET", resultTebet.getOrThrow().districtName)
    }
}
