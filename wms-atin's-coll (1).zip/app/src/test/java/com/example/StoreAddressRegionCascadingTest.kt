package com.example

import com.example.data.models.Region
import com.example.data.models.StoreSettings
import com.example.data.models.UserRole
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StoreAddressRegionCascadingTest {

    @Test
    fun testStoreAddressFourLevelCascadingAndReset() {
        val provinces = listOf(
            Region(code = "32", name = "Jawa Barat", level = "PROVINCE"),
            Region(code = "33", name = "Jawa Tengah", level = "PROVINCE")
        )

        val regencies = listOf(
            Region(code = "32.04", name = "Kabupaten Bandung", level = "REGENCY", parentCode = "32"),
            Region(code = "32.73", name = "Kota Bandung", level = "REGENCY", parentCode = "32"),
            Region(code = "33.74", name = "Kota Semarang", level = "REGENCY", parentCode = "33")
        )

        val districts = listOf(
            Region(code = "32.04.13", name = "Banjaran", level = "DISTRICT", parentCode = "32.04"),
            Region(code = "32.04.37", name = "Soreang", level = "DISTRICT", parentCode = "32.04"),
            Region(code = "32.73.01", name = "Sukasari", level = "DISTRICT", parentCode = "32.73")
        )

        val villages = listOf(
            Region(code = "32.04.13.2001", name = "Kamasan", level = "VILLAGE", parentCode = "32.04.13"),
            Region(code = "32.04.13.2002", name = "Banjaran Wetan", level = "VILLAGE", parentCode = "32.04.13"),
            Region(code = "32.04.37.2001", name = "Soreang", level = "VILLAGE", parentCode = "32.04.37")
        )

        // 1. Initial State: Select Jawa Barat
        var selectedProvince: Region? = provinces.find { it.code == "32" }
        var selectedRegency: Region? = null
        var selectedDistrict: Region? = null
        var selectedVillage: Region? = null

        assertNotNull(selectedProvince)
        assertEquals("Jawa Barat", selectedProvince?.name)

        // Filter regencies
        val filteredRegencies = regencies.filter { it.parentCode == selectedProvince?.code }
        assertEquals(2, filteredRegencies.size)

        // 2. Select Kabupaten Bandung
        selectedRegency = filteredRegencies.find { it.code == "32.04" }
        assertNotNull(selectedRegency)
        assertEquals("Kabupaten Bandung", selectedRegency?.name)

        // Filter districts
        val filteredDistricts = districts.filter { it.parentCode == selectedRegency?.code }
        assertEquals(2, filteredDistricts.size)

        // 3. Select Banjaran
        selectedDistrict = filteredDistricts.find { it.code == "32.04.13" }
        assertNotNull(selectedDistrict)
        assertEquals("Banjaran", selectedDistrict?.name)

        // Filter villages
        val filteredVillages = villages.filter { it.parentCode == selectedDistrict?.code }
        assertEquals(2, filteredVillages.size)

        // 4. Select Kamasan
        selectedVillage = filteredVillages.find { it.code == "32.04.13.2001" }
        assertNotNull(selectedVillage)
        assertEquals("Kamasan", selectedVillage?.name)

        // 5. Test Cascading Reset: Changing Regency resets District and Village
        val newRegency = regencies.find { it.code == "32.73" }
        if (selectedRegency?.code != newRegency?.code) {
            selectedRegency = newRegency
            selectedDistrict = null
            selectedVillage = null
        }
        assertEquals("Kota Bandung", selectedRegency?.name)
        assertNull(selectedDistrict)
        assertNull(selectedVillage)

        // 6. Test Cascading Reset: Changing Province resets Regency, District, and Village
        selectedRegency = regencies.find { it.code == "32.04" }
        selectedDistrict = districts.find { it.code == "32.04.13" }
        selectedVillage = villages.find { it.code == "32.04.13.2001" }

        val newProvince = provinces.find { it.code == "33" }
        if (selectedProvince?.code != newProvince?.code) {
            selectedProvince = newProvince
            selectedRegency = null
            selectedDistrict = null
            selectedVillage = null
        }
        assertEquals("Jawa Tengah", selectedProvince?.name)
        assertNull(selectedRegency)
        assertNull(selectedDistrict)
        assertNull(selectedVillage)
    }

    @Test
    fun testStoreAddressValidationAndFormatting() {
        // Incomplete store settings
        val incompleteStore = StoreSettings(
            storeName = "Atin's Collection",
            storePhone = "0899-7884-435",
            provinceCode = "32",
            provinceName = "Jawa Barat",
            regencyCode = "32.04",
            regencyName = "Kabupaten Bandung",
            districtCode = "", // Incomplete!
            districtName = "",
            villageCode = "",
            villageName = "",
            detailAddress = "Jl. Raya Banjaran No. 123"
        )
        assertFalse(incompleteStore.isRegionAddressComplete())

        // Complete store settings
        val completeStore = StoreSettings(
            storeName = "Atin's Collection",
            storePhone = "0899-7884-435",
            storeEmail = "cs@atinscoll.com",
            provinceCode = "32",
            provinceName = "Jawa Barat",
            regencyCode = "32.04",
            regencyName = "Kabupaten Bandung",
            districtCode = "32.04.13",
            districtName = "Banjaran",
            villageCode = "32.04.13.2001",
            villageName = "Kamasan",
            detailAddress = "Jl. Raya Banjaran No. 123, RT 02/RW 04",
            postalCode = "40377"
        )
        assertTrue(completeStore.isRegionAddressComplete())

        // Formatted address test
        val fullAddr = completeStore.getFullAddress()
        assertTrue(fullAddr.contains("Jl. Raya Banjaran No. 123, RT 02/RW 04"))
        assertTrue(fullAddr.contains("Kamasan"))
        assertTrue(fullAddr.contains("Banjaran"))
        assertTrue(fullAddr.contains("Kabupaten Bandung"))
        assertTrue(fullAddr.contains("Jawa Barat"))
        assertTrue(fullAddr.contains("40377"))

        // Shipping Origin name test
        assertEquals("Banjaran, Kabupaten Bandung", completeStore.getShippingOriginName())
    }

    @Test
    fun testLegacyAddressBackwardCompatibility() {
        val legacyStore = StoreSettings(
            storeName = "Atin's Collection",
            storePhone = "0899-7884-435",
            storeAddress = "Jl. Stasiun No. 5 Banjaran, Bandung"
            // No region codes set
        )
        assertFalse(legacyStore.isRegionAddressComplete())
        assertEquals("Jl. Stasiun No. 5 Banjaran, Bandung", legacyStore.getFullAddress())
        assertEquals("Banjaran", legacyStore.getShippingOriginName())
    }

    @Test
    fun testRolePermissionCheck() {
        val rootAdminRole = UserRole.ROOT_ADMIN.label
        val warehouseAdminRole = UserRole.ADMIN_GUDANG.label
        val warehouseStaffRole = UserRole.STAFF_GUDANG.label

        assertTrue(rootAdminRole == "Root Admin")
        assertFalse(warehouseAdminRole == "Root Admin")
        assertFalse(warehouseStaffRole == "Root Admin")
    }
}
