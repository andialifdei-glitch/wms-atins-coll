package com.example

import com.example.data.models.*
import org.junit.Assert.*
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StockOpnameBusinessLogicTest {

    @Test
    fun `test SOP document number format`() {
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val seq = 1
        val sopNumber = String.format("SOP-%s-%03d", dateStr, seq)
        val regex = Regex("^SOP-\\d{8}-\\d{3}$")
        assertTrue("SOP document number must follow SOP-YYYYMMDD-XXX format", regex.matches(sopNumber))
        assertEquals("SOP-$dateStr-001", sopNumber)
    }

    @Test
    fun `test POST document number format`() {
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val seq = 2
        val postNumber = String.format("POST-%s-%03d", dateStr, seq)
        val regex = Regex("^POST-\\d{8}-\\d{3}$")
        assertTrue("POST document number must follow POST-YYYYMMDD-XXX format", regex.matches(postNumber))
        assertEquals("POST-$dateStr-002", postNumber)
    }

    @Test
    fun `test negative adjustment calculation - Scenario 7`() {
        val systemStock = 100
        val physicalStock = 98
        val difference = physicalStock - systemStock
        assertEquals(-2, difference)
        assertTrue("Negative adjustment must be preserved as valid", difference < 0)
    }

    @Test
    fun `test positive adjustment calculation - Scenario 8`() {
        val systemStock = 50
        val physicalStock = 55
        val difference = physicalStock - systemStock
        assertEquals(+5, difference)
        assertTrue("Positive adjustment must be preserved as valid", difference > 0)
    }

    @Test
    fun `test zero adjustment calculation - Scenario 9`() {
        val systemStock = 25
        val physicalStock = 25
        val difference = physicalStock - systemStock
        assertEquals(0, difference)
    }

    @Test
    fun `test stock opname summary calculation - Section 14`() {
        val items = listOf(
            StockOpnameItem(skuId = "SKU-001", itemName = "Item A", systemQtySnapshot = 100, physicalQty = 98, isCounted = true),
            StockOpnameItem(skuId = "SKU-002", itemName = "Item B", systemQtySnapshot = 50, physicalQty = 55, isCounted = true),
            StockOpnameItem(skuId = "SKU-003", itemName = "Item C", systemQtySnapshot = 25, physicalQty = 25, isCounted = true)
        )

        val totalSku = items.size
        val surplusCount = items.count { (it.physicalQty!! - it.systemQtySnapshot) > 0 }
        val shortageCount = items.count { (it.physicalQty!! - it.systemQtySnapshot) < 0 }
        val matchCount = items.count { (it.physicalQty!! - it.systemQtySnapshot) == 0 }

        val totalSurplus = items.filter { (it.physicalQty!! - it.systemQtySnapshot) > 0 }
            .sumOf { it.physicalQty!! - it.systemQtySnapshot }
        val totalShortage = items.filter { (it.physicalQty!! - it.systemQtySnapshot) < 0 }
            .sumOf { it.systemQtySnapshot - it.physicalQty!! }
        val netDifference = items.sumOf { it.physicalQty!! - it.systemQtySnapshot }

        assertEquals(3, totalSku)
        assertEquals(1, surplusCount)
        assertEquals(1, shortageCount)
        assertEquals(1, matchCount)
        assertEquals(5, totalSurplus)
        assertEquals(2, totalShortage)
        assertEquals(3, netDifference) // -2 + 5 + 0 = +3
    }

    @Test
    fun `test incomplete counting validation - Scenario 4`() {
        val items = listOf(
            StockOpnameItem(skuId = "SKU-001", itemName = "Item A", systemQtySnapshot = 100, physicalQty = 98, isCounted = true),
            StockOpnameItem(skuId = "SKU-002", itemName = "Item B", systemQtySnapshot = 50, physicalQty = null, isCounted = false)
        )

        val uncounted = items.filter { !it.isCounted || it.physicalQty == null }
        assertEquals(1, uncounted.size)
        assertEquals("SKU-002", uncounted.first().skuId)

        val canComplete = uncounted.isEmpty()
        assertFalse("Stock Opname cannot complete when items are uncounted", canComplete)
    }

    @Test
    fun `test completion locking - Scenario 5`() {
        val items = listOf(
            StockOpnameItem(skuId = "SKU-001", itemName = "Item A", systemQtySnapshot = 100, physicalQty = 98, isCounted = true),
            StockOpnameItem(skuId = "SKU-002", itemName = "Item B", systemQtySnapshot = 50, physicalQty = 55, isCounted = true)
        )

        val canComplete = items.all { it.isCounted && it.physicalQty != null }
        assertTrue("All items counted, can complete", canComplete)

        var status = "OPEN"
        status = "COUNTING_COMPLETED"
        assertEquals("COUNTING_COMPLETED", status)

        val isLocked = status == "COUNTING_COMPLETED" || status == "POSTED"
        assertTrue("Admin and Staff cannot edit counts when locked", isLocked)
    }

    @Test
    fun `test role permissions for stock opname - Section 2`() {
        val rootAdminRole = UserRole.ROOT_ADMIN.label
        val adminGudangRole = UserRole.ADMIN_GUDANG.label
        val staffGudangRole = UserRole.STAFF_GUDANG.label

        // Initialize permission
        assertTrue("Root Admin can initialize", rootAdminRole == UserRole.ROOT_ADMIN.label)
        assertFalse("Admin Gudang cannot initialize", adminGudangRole == UserRole.ROOT_ADMIN.label)
        assertFalse("Staff Gudang cannot initialize", staffGudangRole == UserRole.ROOT_ADMIN.label)

        // Adjustment & Posting permission
        assertTrue("Root Admin can adjust and post", rootAdminRole == UserRole.ROOT_ADMIN.label)
        assertFalse("Admin Gudang cannot adjust and post", adminGudangRole == UserRole.ROOT_ADMIN.label)
        assertFalse("Staff Gudang cannot adjust and post", staffGudangRole == UserRole.ROOT_ADMIN.label)
    }

    @Test
    fun `test stock cut-off with intermediate warehouse movements - Section 24`() {
        val snapshotStock = 100
        val physicalCount = 98
        val opnameDifference = physicalCount - snapshotStock // -2

        // Case A: No intermediate transaction occurred between snapshot and post
        val liveStockCaseA = 100
        val finalStockA = if (liveStockCaseA == snapshotStock) {
            physicalCount
        } else {
            (liveStockCaseA + opnameDifference).coerceAtLeast(0)
        }
        assertEquals(98, finalStockA)

        // Case B: A Delivery Order deducted 5 pcs while opname was running (live stock becomes 95)
        val liveStockCaseB = 95
        val finalStockB = if (liveStockCaseB == snapshotStock) {
            physicalCount
        } else {
            (liveStockCaseB + opnameDifference).coerceAtLeast(0)
        }
        // 95 + (-2) = 93 (preserves the DO transaction of 5 pcs, applies the 2 pcs opname shortage!)
        assertEquals(93, finalStockB)
    }

    @Test
    fun `test idempotent posting prevents duplicate execution - Scenario 11`() {
        val sop = StockOpname(
            sopId = "SOP-20261003-001",
            documentNo = "SOP-20261003-001",
            status = "POSTED",
            postingId = "POST-20261003-001"
        )

        val isAlreadyPosted = sop.status == "POSTED" || sop.postingId.isNotBlank()
        assertTrue("Must detect that posting has already been executed", isAlreadyPosted)
    }

    @Test
    fun `test active SKU with zero stock is included in snapshot - Test B`() {
        val products = listOf(
            Product(sku = "SKU-001001", itemName = "Daster A", stock = 0, active = true),
            Product(sku = "SKU-001002", itemName = "Daster B", stock = 50, active = true),
            Product(sku = "SKU-001003", itemName = "Daster C (Inactive)", stock = 10, active = false)
        )

        val eligible = products.filter { it.isProductActive && it.sku.isNotBlank() }
        assertEquals(2, eligible.size)
        assertTrue("SKU with stock = 0 must be included", eligible.any { it.sku == "SKU-001001" && it.stock == 0 })
        assertFalse("Inactive SKU must be excluded", eligible.any { it.sku == "SKU-001003" })
    }

    @Test
    fun `test empty eligible products returns correct message - Test C`() {
        val products = listOf(
            Product(sku = "SKU-001001", itemName = "Daster Inactive", stock = 0, active = false)
        )
        val eligible = products.filter { it.isProductActive && it.sku.isNotBlank() }
        assertTrue(eligible.isEmpty())
        val errorMsg = if (eligible.isEmpty()) "Tidak ada produk aktif dalam master data untuk Stock Opname." else null
        assertEquals("Tidak ada produk aktif dalam master data untuk Stock Opname.", errorMsg)
    }

    @Test
    fun `test firestore error is distinct from empty products - Test D`() {
        val firestoreException = Exception("PERMISSION_DENIED: Missing or insufficient permissions.")
        val errorMsg = "Gagal mengambil data produk master: ${firestoreException.localizedMessage}"
        assertFalse("Must not say 'tidak ada produk aktif' when query fails", errorMsg.contains("Tidak ada produk aktif"))
        assertTrue(errorMsg.contains("PERMISSION_DENIED"))
    }

    @Test
    fun `test family search filtering - Test F, G, H`() {
        val families = listOf(
            Family(familyCode = "FAM-001", familyName = "Daster Pendek"),
            Family(familyCode = "FAM-002", familyName = "Daster Premium"),
            Family(familyCode = "FAM-003", familyName = "Daster Rayon"),
            Family(familyCode = "FAM-010", familyName = "Gamis Syari")
        )

        // Search by name lowercase "rayon"
        val queryRayon = "rayon"
        val resultsRayon = families.filter {
            it.familyName.contains(queryRayon, ignoreCase = true) || it.familyCode.contains(queryRayon, ignoreCase = true)
        }
        assertEquals(1, resultsRayon.size)
        assertEquals("FAM-003", resultsRayon.first().familyCode)

        // Search by code "001"
        val query001 = "001"
        val results001 = families.filter {
            it.familyName.contains(query001, ignoreCase = true) || it.familyCode.contains(query001, ignoreCase = true)
        }
        assertEquals(1, results001.size)
        assertEquals("Daster Pendek", results001.first().familyName)

        // Search "daster" case-insensitive
        val queryDaster = "DASTER"
        val resultsDaster = families.filter {
            it.familyName.contains(queryDaster, ignoreCase = true) || it.familyCode.contains(queryDaster, ignoreCase = true)
        }
        assertEquals(3, resultsDaster.size)
    }

    @Test
    fun `test family validation on save product - Test J`() {
        var selectedFamilyCode = ""
        val errorMsg = if (selectedFamilyCode.isBlank()) "Silakan pilih Family." else null
        assertEquals("Silakan pilih Family.", errorMsg)

        selectedFamilyCode = "FAM-001"
        val errorMsgAfter = if (selectedFamilyCode.isBlank()) "Silakan pilih Family." else null
        assertNull(errorMsgAfter)
    }

    @Test
    fun `test physicalQty 0 is strictly treated as counted and valid`() {
        val itemZero = StockOpnameItem(
            skuId = "SKU-001",
            itemName = "Daster Zero",
            systemQtySnapshot = 10,
            physicalQty = 0,
            isCounted = true
        )
        assertTrue("Item with physicalQty = 0 must be considered counted", itemZero.hasBeenCounted)
        assertEquals("Status text must be Sudah dihitung", "Sudah dihitung", if (itemZero.hasBeenCounted) "Sudah dihitung" else "Belum dihitung")
        assertEquals(-10, itemZero.physicalQty!! - itemZero.systemQtySnapshot)

        val itemNull = StockOpnameItem(
            skuId = "SKU-002",
            itemName = "Daster Null",
            systemQtySnapshot = 10,
            physicalQty = null,
            isCounted = false
        )
        assertFalse("Item with physicalQty = null must be considered uncounted", itemNull.hasBeenCounted)
        assertEquals("Status text must be Belum dihitung", "Belum dihitung", if (itemNull.hasBeenCounted) "Sudah dihitung" else "Belum dihitung")
    }

    @Test
    fun `test custom price on SO does not mutate master product price`() {
        val masterProduct = Product(
            sku = "SKU-PROD-001",
            itemName = "Produk A",
            netPrice = 50_000L,
            purchasingPrice = 30_000L
        )

        val soItem1 = SoItem(
            sku = masterProduct.sku,
            itemName = masterProduct.itemName,
            qty = 2,
            price = 47_000L, // Custom negotiated price on SO-001
            subtotal = 94_000L,
            purchasingPriceSnapshot = masterProduct.purchasingPrice
        )

        val soItem2 = SoItem(
            sku = masterProduct.sku,
            itemName = masterProduct.itemName,
            qty = 1,
            price = masterProduct.netPrice, // Standard price on SO-002: 50,000
            subtotal = masterProduct.netPrice,
            purchasingPriceSnapshot = masterProduct.purchasingPrice
        )

        assertEquals("Master product selling price remains untouched", 50_000L, masterProduct.netPrice)
        assertEquals("SO-001 has snapshot price 47,000", 47_000L, soItem1.price)
        assertEquals("SO-002 has snapshot price 50,000", 50_000L, soItem2.price)
        assertEquals("SO-001 subtotal calculation correct", 94_000L, soItem1.subtotal)
    }

    @Test
    fun `test sales order status transitions CONFIRMED to PROCESSING to READY TO DELIVER`() {
        var so = SalesOrder(
            soId = "SO-20261004-001",
            status = "CONFIRMED",
            items = listOf(SoItem(sku = "SKU-1", price = 10_000L, qty = 1, subtotal = 10_000L))
        )

        // On CONFIRMED: can add items
        val canAddItemsOnConfirmed = so.status == "CONFIRMED"
        assertTrue("Can add items when SO is CONFIRMED", canAddItemsOnConfirmed)

        // Transition to PROCESSING
        so = so.copy(status = "PROCESSING")
        val canAddItemsOnProcessing = so.status == "CONFIRMED"
        assertFalse("Cannot add items when SO is in PROCESSING", canAddItemsOnProcessing)

        // On PROCESSING: Ready to Deliver button is available
        val canMarkReadyToDeliver = so.status == "PROCESSING"
        assertTrue("Can advance from PROCESSING to READY TO DELIVER", canMarkReadyToDeliver)

        // Transition to READY TO DELIVER
        so = so.copy(status = "READY TO DELIVER")
        assertEquals("READY TO DELIVER", so.status)
    }

    @Test
    fun `test family name and code uniqueness enforcement`() {
        val existingFamilies = listOf(
            Family(familyCode = "FAM-001", familyName = "Daster Rayon"),
            Family(familyCode = "FAM-002", familyName = "Kulot Santai")
        )

        // Case A: duplicate family name case-insensitive
        val isNameDuplicate = existingFamilies.any { it.familyName.equals("daster rayon", ignoreCase = true) }
        assertTrue("Duplicate family name must be detected", isNameDuplicate)

        // Case B: duplicate family code case-insensitive
        val isCodeDuplicate = existingFamilies.any { it.familyCode.equals("fam-001", ignoreCase = true) }
        assertTrue("Duplicate family code must be detected", isCodeDuplicate)

        // Case C: unique family
        val isUnique = existingFamilies.none {
            it.familyName.equals("Gamis Modern", ignoreCase = true) ||
            it.familyCode.equals("FAM-003", ignoreCase = true)
        }
        assertTrue("New unique family is allowed", isUnique)
    }

    @Test
    fun `test stock opname cancellation restricted to OPEN or COUNTING`() {
        val openSop = StockOpname(sopId = "SOP-1", status = "OPEN")
        val countingSop = StockOpname(sopId = "SOP-2", status = "COUNTING")
        val completedSop = StockOpname(sopId = "SOP-3", status = "COUNTING_COMPLETED")
        val postedSop = StockOpname(sopId = "SOP-4", status = "POSTED")

        assertTrue("OPEN can be cancelled", openSop.status == "OPEN" || openSop.status == "COUNTING")
        assertTrue("COUNTING can be cancelled", countingSop.status == "OPEN" || countingSop.status == "COUNTING")
        assertFalse("COUNTING_COMPLETED cannot be cancelled directly", completedSop.status == "OPEN" || completedSop.status == "COUNTING")
        assertFalse("POSTED cannot be cancelled", postedSop.status == "OPEN" || postedSop.status == "COUNTING")
    }
}
