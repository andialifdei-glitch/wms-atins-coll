package com.example

import com.example.data.models.DeliveryOrder
import com.example.data.models.DoShippingLabelData
import com.example.data.models.Product
import com.example.data.models.SoItem
import com.example.data.models.StoreSettings
import com.example.data.models.UserAccount
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DoShippingLabelSecurityTest {

    @Test
    fun `test DoShippingLabelData contains revised format and excludes all sensitive internal data`() {
        val fullInternalDo = DeliveryOrder(
            doId = "DO-20261007-001",
            soId = "SO-20261007-001",
            date = "2026-10-07",
            expedition = "Wahana Economy",
            senderName = "Atin's Collection Toko Pusat",
            senderPhone = "0899-7884-435",
            senderAddress = "Jl. Raya Banjaran No. 123, Bandung, Jawa Barat",
            recipientName = "Budi Hartono",
            recipientPhone = "0812-3456-7890",
            recipientAddress = "Jl. Merdeka No. 45, RT 01/RW 02, Kel. Kedaton, Kec. Kedaton, Kota Bandar Lampung, Lampung, 35141",
            totalItems = 2,
            totalPcs = 5,
            totalWeightInGrams = 1500,
            shippingCost = 22000L,
            shippingCourier = "wahana",
            shippingServiceName = "Wahana Economy",
            items = listOf(
                SoItem(sku = "SKU-DRESS-001", itemName = "Gamis Premium Satin Silk", qty = 2, price = 150000L, purchasingPriceSnapshot = 90000L, subtotal = 300000L),
                SoItem(sku = "SKU-HIJAB-002", itemName = "Pashmina Ceruty Baby Doll", qty = 3, price = 45000L, purchasingPriceSnapshot = 25000L, subtotal = 135000L)
            )
        )

        val storeSettings = StoreSettings(
            storeName = "Atin's Collection Pusat",
            storePhone = "0899-7884-435",
            storeAddress = "Bandung, Jawa Barat"
        )

        val user = UserAccount(
            name = "Rina Admin",
            email = "rina@atinscoll.com"
        )

        val testPrintDate = "08 Oktober 2026, 14:30"
        val labelData = DoShippingLabelData.fromDeliveryOrder(
            doOrder = fullInternalDo,
            storeSettings = storeSettings,
            userAccount = user,
            printDate = testPrintDate
        )

        // Verify required fields
        assertEquals("DO-20261007-001", labelData.doNumber)
        assertEquals("Wahana Economy", labelData.shippingService)
        assertEquals("Atin's Collection Pusat", labelData.senderName)
        assertEquals("0899-7884-435", labelData.senderPhone)
        assertEquals("Budi Hartono", labelData.recipientName)
        assertEquals("0812-3456-7890", labelData.recipientPhone)
        assertEquals("Jl. Merdeka No. 45, RT 01/RW 02, Kel. Kedaton, Kec. Kedaton, Kota Bandar Lampung, Lampung, 35141", labelData.recipientAddress)
        assertEquals("SO-20261007-001", labelData.soNumber)
        assertEquals("08 Oktober 2026, 14:30", labelData.printDate)
        assertEquals("Rina Admin", labelData.printedBy)

        // Exact revised label structure
        val labelText = """
            DELIVERY ORDER

            DO : ${labelData.doNumber}
            Ekspedisi : ${labelData.shippingService}

            ---

            PENGIRIM
            ${labelData.senderName}

            NO HANDPHONE
            ${labelData.senderPhone}

            ---

            PENERIMA
            ${labelData.recipientName}

            ALAMAT
            ${labelData.recipientAddress}

            NO HANDPHONE
            ${labelData.recipientPhone}

            ---

            SO : ${labelData.soNumber}
            Tanggal Cetak : ${labelData.printDate}
            By : ${labelData.printedBy}
        """.trimIndent()

        // Verify prohibited internal/sensitive fields NEVER appear
        assertFalse("Alamat pengirim must NOT appear in label", labelText.contains("Jl. Raya Banjaran", ignoreCase = true))
        assertFalse("Alamat pengirim dari settings must NOT appear in label", labelText.contains("Bandung, Jawa Barat", ignoreCase = true))
        assertFalse("Harga ongkir must NOT appear in label", labelText.contains("22000"))
        assertFalse("Daftar item must NOT appear in label", labelText.contains("Gamis Premium", ignoreCase = true))
        assertFalse("Daftar item must NOT appear in label", labelText.contains("Pashmina Ceruty", ignoreCase = true))
        assertFalse("SKU must NOT appear in label", labelText.contains("SKU-DRESS-001"))
        assertFalse("Qty must NOT appear in label", labelText.contains("5 pcs", ignoreCase = true))
        assertFalse("Harga jual must NOT appear in label", labelText.contains("150000"))
        assertFalse("HPP must NOT appear in label", labelText.contains("90000"))
        assertFalse("Subtotal must NOT appear in label", labelText.contains("300000"))
        assertFalse("Total berat must NOT appear in label", labelText.contains("1500 gram", ignoreCase = true))

        // Ensure database entity unchanged
        assertEquals(22000L, fullInternalDo.shippingCost)
        assertEquals(2, fullInternalDo.items.size)
        assertEquals("Jl. Raya Banjaran No. 123, Bandung, Jawa Barat", fullInternalDo.senderAddress)
    }

    @Test
    fun `test Product masterStatusLabel strictly follows database active field`() {
        // active = true -> Aktif
        val activeProd = Product(
            sku = "SKU-001001",
            itemName = "Daster Rayon",
            stock = 0, // Even with 0 stock, status must purely follow active field
            active = true
        )
        assertEquals("Aktif", activeProd.masterStatusLabel)
        assertTrue(activeProd.isProductActive)

        // active = false -> Nonaktif
        val inactiveProd = Product(
            sku = "SKU-001002",
            itemName = "Kulot Linen",
            stock = 100, // Even with 100 stock, status must purely follow active field
            active = false
        )
        assertEquals("Nonaktif", inactiveProd.masterStatusLabel)
        assertFalse(inactiveProd.isProductActive)

        // active = null -> Status Tidak Valid (must not assume active)
        val invalidProd = Product(
            sku = "SKU-001003",
            itemName = "Tunik Batik",
            stock = 50,
            active = null
        )
        assertEquals("Status Tidak Valid", invalidProd.masterStatusLabel)
        assertFalse("Null active must never be assumed active", invalidProd.isProductActive)
    }
}
