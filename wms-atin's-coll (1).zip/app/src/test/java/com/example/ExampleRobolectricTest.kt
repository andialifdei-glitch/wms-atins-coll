package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repositories.ShippingCostRepository
import kotlinx.coroutines.runBlocking
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("WMS Atin's Coll", appName)
  }

  private fun createMockHttpClient(): OkHttpClient {
    val interceptor = Interceptor { chain ->
      val request = chain.request()
      val url = request.url.toString()
      val jsonMediaType = "application/json; charset=utf-8".toMediaType()

      val responseString = when {
        url.contains("destination/domestic-destination") -> {
          when {
            url.contains("Coblong", ignoreCase = true) || url.contains("Bandung", ignoreCase = true) ->
              """{"meta":{"code":200,"status":"success"},"data":[{"id":4916,"label":"CIPAGANTI, COBLONG, BANDUNG, JAWA BARAT, 40131","subdistrict_name":"CIPAGANTI"}]}"""
            url.contains("Klari", ignoreCase = true) || url.contains("Karawang", ignoreCase = true) ->
              """{"meta":{"code":200,"status":"success"},"data":[{"id":37785,"label":"KLARI, KLARI, KARAWANG, JAWA BARAT, 41371","subdistrict_name":"KLARI"}]}"""
            url.contains("Kedaton", ignoreCase = true) || url.contains("Lampung", ignoreCase = true) ->
              """{"meta":{"code":200,"status":"success"},"data":[{"id":73914,"label":"KEDATON, KEDATON, BANDAR LAMPUNG, LAMPUNG, 35141","subdistrict_name":"KEDATON"}]}"""
            url.contains("Banjaran", ignoreCase = true) ->
              """{"meta":{"code":200,"status":"success"},"data":[{"id":4997,"label":"BANJARAN KULON, BANJARAN, BANDUNG, JAWA BARAT, 40377","subdistrict_name":"BANJARAN KULON"}]}"""
            else ->
              """{"meta":{"code":200,"status":"success"},"data":[]}"""
          }
        }
        url.contains("calculate/domestic-cost") -> {
          // Read form body to check destination and courier
          val requestBody = request.body
          val buffer = okio.Buffer()
          requestBody?.writeTo(buffer)
          val bodyStr = buffer.readUtf8()

          val dest = if (bodyStr.contains("destination=4916")) "bandung"
                     else if (bodyStr.contains("destination=37785")) "karawang"
                     else if (bodyStr.contains("destination=73914")) "lampung"
                     else "other"

          val courier = if (bodyStr.contains("courier=wahana")) "wahana"
                        else if (bodyStr.contains("courier=lion")) "lion"
                        else if (bodyStr.contains("courier=spx")) "spx"
                        else "unknown"

          when (dest) {
            "bandung" -> when (courier) {
              "wahana" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"Express","description":"Layanan Express","cost":5000,"etd":"2 day"}]}"""
              "lion" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"REGPACK","description":"Regular Package","cost":7490,"etd":"1-2 day"}]}"""
              "spx" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"SPX Standard","description":"SPX Standard","cost":7100,"etd":"2 day"}]}"""
              else -> """{"meta":{"code":200,"status":"success"},"data":[]}"""
            }
            "karawang" -> when (courier) {
              "wahana" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"Express","description":"Layanan Express","cost":6000,"etd":"3 day"}]}"""
              "lion" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"REGPACK","description":"Regular Package","cost":8000,"etd":"2-3 day"}]}"""
              "spx" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"SPX Standard","description":"SPX Standard","cost":9000,"etd":"2-3 day"}]}"""
              else -> """{"meta":{"code":200,"status":"success"},"data":[]}"""
            }
            "lampung" -> when (courier) {
              "wahana" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"Express","description":"Layanan Express","cost":10000,"etd":"4 day"}]}"""
              "lion" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"REGPACK","description":"Regular Package","cost":14000,"etd":"3-4 day"}]}"""
              "spx" -> """{"meta":{"code":200,"status":"success"},"data":[{"service":"SPX Standard","description":"SPX Standard","cost":16000,"etd":"3-4 day"}]}"""
              else -> """{"meta":{"code":200,"status":"success"},"data":[]}"""
            }
            else -> """{"meta":{"code":200,"status":"success"},"data":[]}"""
          }
        }
        else -> """{"meta":{"code":404,"status":"error"},"data":null}"""
      }

      Response.Builder()
        .request(request)
        .protocol(Protocol.HTTP_1_1)
        .code(200)
        .message("OK")
        .body(responseString.toResponseBody(jsonMediaType))
        .build()
    }

    return OkHttpClient.Builder().addInterceptor(interceptor).build()
  }

  @Test
  fun `test destination resolution returns distinct IDs for different locations`() = runBlocking {
    val repo = ShippingCostRepository(customHttpClient = createMockHttpClient())
    val bandungId = repo.resolveDestinationId("Coblong, Bandung, Jawa Barat").getOrNull()
    val karawangId = repo.resolveDestinationId("Klari, Karawang, Jawa Barat").getOrNull()
    val lampungId = repo.resolveDestinationId("Kedaton, Bandar Lampung, Lampung").getOrNull()

    assertTrue("Bandung ID should be resolved", bandungId != null && bandungId > 0)
    assertTrue("Karawang ID should be resolved", karawangId != null && karawangId > 0)
    assertTrue("Lampung ID should be resolved", lampungId != null && lampungId > 0)

    assertNotEquals("Bandung and Karawang IDs must be distinct", bandungId, karawangId)
    assertNotEquals("Karawang and Lampung IDs must be distinct", karawangId, lampungId)
    assertNotEquals("Bandung and Lampung IDs must be distinct", bandungId, lampungId)
  }

  @Test
  fun `test shipping calculation returns distinct realistic costs for different locations`() = runBlocking {
    val repo = ShippingCostRepository(customHttpClient = createMockHttpClient())
    val origin = "Banjaran, Bandung, Jawa Barat"

    val bandungRates = repo.calculateShippingCost(origin, "Coblong, Bandung, Jawa Barat", 1000).getOrNull().orEmpty()
    val karawangRates = repo.calculateShippingCost(origin, "Klari, Karawang, Jawa Barat", 1000).getOrNull().orEmpty()
    val lampungRates = repo.calculateShippingCost(origin, "Kedaton, Bandar Lampung, Lampung", 1000).getOrNull().orEmpty()

    assertEquals("Must have 3 courier options for Bandung", 3, bandungRates.size)
    assertEquals("Must have 3 courier options for Karawang", 3, karawangRates.size)
    assertEquals("Must have 3 courier options for Lampung", 3, lampungRates.size)

    val wahanaBandung = bandungRates.first { it.courier == "wahana" }.cost
    val wahanaKarawang = karawangRates.first { it.courier == "wahana" }.cost
    val wahanaLampung = lampungRates.first { it.courier == "wahana" }.cost

    // Bandung: 5000, Karawang: 6000, Lampung: 10000
    assertEquals(5000L, wahanaBandung)
    assertEquals(6000L, wahanaKarawang)
    assertEquals(10000L, wahanaLampung)

    assertNotEquals("Bandung cost should differ from Karawang cost", wahanaBandung, wahanaKarawang)
    assertNotEquals("Bandung cost should differ from Lampung cost", wahanaBandung, wahanaLampung)
  }
}


