package com.example

import com.example.data.firebase.AuthManager
import com.example.data.models.UserAccount
import com.example.data.models.UserRole
import com.example.data.repositories.StockOpnameRepository
import org.junit.Assert.*
import org.junit.Test

class AuthSecurityVerificationTest {

    @Test
    fun `test 1 - Root Admin identifier mapping and default credentials`() {
        val email = AuthManager.userIdToEmail("admin")
        assertEquals("admin@wms.atinscoll.com", email)
        assertEquals("admin", AuthManager.ROOT_ADMIN_ID)
        assertEquals("rootadmin", AuthManager.ROOT_ADMIN_DEFAULT_PASS)

        val adminUser = UserAccount(
            userId = AuthManager.ROOT_ADMIN_ID,
            name = "Root Administrator",
            role = UserRole.ROOT_ADMIN.label,
            email = email,
            isActive = true
        )
        assertEquals("Root Admin", adminUser.role)
        assertTrue(StockOpnameRepository.isRootAdmin(adminUser.role))
    }

    @Test
    fun `test 2 - Password validation rejecting empty and invalid inputs`() {
        // Empty password validation
        val emptyPass = ""
        val blankPass = "   "
        assertTrue(emptyPass.isBlank())
        assertTrue(blankPass.isBlank())

        // Minimum length 6 characters required by Firebase Auth
        val shortPass = "12345"
        assertTrue(shortPass.length < 6)

        val validPass = "rootadmin"
        assertTrue(validPass.length >= 6)
    }

    @Test
    fun `test 3 - User ID to Firebase Auth identifier mapping`() {
        assertEquals("usertidakada@wms.atinscoll.com", AuthManager.userIdToEmail("usertidakada"))
        assertEquals("staff_gudang1@wms.atinscoll.com", AuthManager.userIdToEmail("staff_gudang1"))
        assertEquals("admin_gudang@wms.atinscoll.com", AuthManager.userIdToEmail("ADMIN_GUDANG"))

        // If user enters an actual email address, it is preserved
        assertEquals("user@domain.com", AuthManager.userIdToEmail("user@domain.com"))
    }

    @Test
    fun `test 4 - Role hierarchy and Root Admin enforcement`() {
        assertEquals("Root Admin", UserRole.ROOT_ADMIN.label)
        assertEquals("Admin Gudang", UserRole.ADMIN_GUDANG.label)
        assertEquals("Staff Gudang", UserRole.STAFF_GUDANG.label)

        assertTrue(StockOpnameRepository.isRootAdmin("Root Admin"))
        assertTrue(StockOpnameRepository.isRootAdmin("root_admin"))
        assertTrue(StockOpnameRepository.isRootAdmin("ROOT_ADMIN"))
        assertTrue(StockOpnameRepository.isRootAdmin("admin"))

        assertFalse(StockOpnameRepository.isRootAdmin("Admin Gudang"))
        assertFalse(StockOpnameRepository.isRootAdmin("Staff Gudang"))
        assertFalse(StockOpnameRepository.isRootAdmin("Staff"))
    }

    @Test
    fun `test 5 - Security and zero plaintext password storage`() {
        val userClass = UserAccount::class.java
        val fieldNames = userClass.declaredFields.map { it.name }

        // Plaintext password field must NOT exist in the model
        assertFalse("UserAccount must not have a 'password' field", fieldNames.contains("password"))
        assertFalse("UserAccount must not have a 'plainPassword' field", fieldNames.contains("plainPassword"))
    }
}
