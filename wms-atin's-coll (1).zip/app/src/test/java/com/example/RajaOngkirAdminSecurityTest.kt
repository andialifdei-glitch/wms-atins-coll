package com.example

import com.example.data.models.TestApiKeyResult
import com.example.data.models.UserRole
import com.example.data.repositories.RajaOngkirAdminRepository
import kotlinx.coroutines.runBlocking
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RajaOngkirAdminSecurityTest {

    private fun createMockHttpClient(responseCode: Int, responseBody: String): OkHttpClient {
        val interceptor = Interceptor { chain ->
            val request = chain.request()
            val jsonMediaType = "application/json; charset=utf-8".toMediaType()

            Response.Builder()
                .request(request)
                .protocol(Protocol.HTTP_1_1)
                .code(responseCode)
                .message("OK")
                .body(responseBody.toResponseBody(jsonMediaType))
                .build()
        }
        return OkHttpClient.Builder().addInterceptor(interceptor).build()
    }

    @Test
    fun `test non root admin is denied access to test api key`() = runBlocking {
        val repo = RajaOngkirAdminRepository(db = null, customHttpClient = createMockHttpClient(200, "{}"))

        val adminGudangResult = repo.testApiKey("dummy_key", "user1", UserRole.ADMIN_GUDANG.label)
        assertTrue("Admin Gudang should be rejected", adminGudangResult.isFailure)

        val staffGudangResult = repo.testApiKey("dummy_key", "user2", UserRole.STAFF_GUDANG.label)
        assertTrue("Staff Gudang should be rejected", staffGudangResult.isFailure)
    }

    @Test
    fun `test valid api key returns success result`() = runBlocking {
        val validJson = """{"meta":{"code":200,"status":"success"},"data":[{"id":4997,"label":"BANJARAN"}]}"""
        val client = createMockHttpClient(200, validJson)
        val repo = RajaOngkirAdminRepository(db = null, customHttpClient = client)

        val res = repo.testApiKey("valid_key_123", "admin", UserRole.ROOT_ADMIN.label)
        assertTrue("Result should be success", res.isSuccess)
        assertEquals(TestApiKeyResult.Success, res.getOrNull())
    }

    @Test
    fun `test invalid api key returns InvalidKey error type`() = runBlocking {
        val invalidJson = """{"meta":{"code":401,"status":"error","message":"Invalid API key"},"data":null}"""
        val client = createMockHttpClient(401, invalidJson)
        val repo = RajaOngkirAdminRepository(db = null, customHttpClient = client)

        val res = repo.testApiKey("bad_key_123", "admin", UserRole.ROOT_ADMIN.label)
        assertTrue("Result should be success wrapper", res.isSuccess)
        assertTrue("Error should be InvalidKey", res.getOrNull() is TestApiKeyResult.InvalidKey)
    }

    @Test
    fun `test quota exceeded returns QuotaExceeded error type`() = runBlocking {
        val quotaJson = """{"meta":{"code":429,"status":"error","message":"Daily limit exceeded"},"data":null}"""
        val client = createMockHttpClient(429, quotaJson)
        val repo = RajaOngkirAdminRepository(db = null, customHttpClient = client)

        val res = repo.testApiKey("exhausted_key", "admin", UserRole.ROOT_ADMIN.label)
        assertTrue("Result should be success wrapper", res.isSuccess)
        assertTrue("Error should be QuotaExceeded", res.getOrNull() is TestApiKeyResult.QuotaExceeded)
    }

    @Test
    fun `test empty api key validation fails without network call`() = runBlocking {
        val repo = RajaOngkirAdminRepository(db = null, customHttpClient = createMockHttpClient(200, "{}"))

        val res = repo.testApiKey("   ", "admin", UserRole.ROOT_ADMIN.label)
        assertTrue("Empty key must fail immediately", res.isFailure)
    }
}
