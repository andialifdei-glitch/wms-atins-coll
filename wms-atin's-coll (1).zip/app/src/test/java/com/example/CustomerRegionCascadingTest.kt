package com.example

import com.example.data.models.Customer
import com.example.data.models.Region
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CustomerRegionCascadingTest {

    @Test
    fun testRegionCascadingSelectionAndReset() {
        val provinces = listOf(
            Region(code = "32", name = "Jawa Barat", level = "PROVINCE", parentCode = null),
            Region(code = "33", name = "Jawa Tengah", level = "PROVINCE", parentCode = null)
        )

        val regencies = listOf(
            Region(code = "32.01", name = "Kabupaten Bogor", level = "REGENCY", parentCode = "32"),
            Region(code = "32.04", name = "Kabupaten Bandung", level = "REGENCY", parentCode = "32"),
            Region(code = "33.01", name = "Kabupaten Cilacap", level = "REGENCY", parentCode = "33")
        )

        val districts = listOf(
            Region(code = "32.04.05", name = "Banjaran", level = "DISTRICT", parentCode = "32.04"),
            Region(code = "32.04.06", name = "Cileunyi", level = "DISTRICT", parentCode = "32.04"),
            Region(code = "32.01.01", name = "Cibinong", level = "DISTRICT", parentCode = "32.01")
        )

        // 1. Initial State: Select Province Jawa Barat (32)
        var selectedProvince: Region? = provinces.find { it.code == "32" }
        var selectedRegency: Region? = null
        var selectedDistrict: Region? = null

        assertNotNull(selectedProvince)
        assertEquals("Jawa Barat", selectedProvince?.name)

        // Filter regencies by selected province
        val filteredRegencies = regencies.filter { it.parentCode == selectedProvince?.code }
        assertEquals(2, filteredRegencies.size)
        assertTrue(filteredRegencies.all { it.parentCode == "32" })
        assertFalse(filteredRegencies.any { it.name == "Kabupaten Cilacap" })

        // 2. Select Kabupaten Bandung (32.04)
        selectedRegency = filteredRegencies.find { it.code == "32.04" }
        assertNotNull(selectedRegency)
        assertEquals("Kabupaten Bandung", selectedRegency?.name)

        // Filter districts by selected regency
        val filteredDistricts = districts.filter { it.parentCode == selectedRegency?.code }
        assertEquals(2, filteredDistricts.size)
        assertTrue(filteredDistricts.all { it.parentCode == "32.04" })

        // 3. Select Banjaran (32.04.05)
        selectedDistrict = filteredDistricts.find { it.code == "32.04.05" }
        assertNotNull(selectedDistrict)
        assertEquals("Banjaran", selectedDistrict?.name)

        // 4. Test Cascading Reset: Changing province to Jawa Tengah (33)
        // Acceptance Test 2: Kabupaten & Kecamatan must be reset!
        val newProvince = provinces.find { it.code == "33" }
        if (selectedProvince?.code != newProvince?.code) {
            selectedProvince = newProvince
            selectedRegency = null
            selectedDistrict = null
        }

        assertEquals("Jawa Tengah", selectedProvince?.name)
        assertNull(selectedRegency)
        assertNull(selectedDistrict)

        // 5. Test Cascading Reset: Changing regency resets district
        // Acceptance Test 3: Select Jawa Barat -> Kabupaten Bandung -> Banjaran, then change to Kabupaten Bogor
        selectedProvince = provinces.find { it.code == "32" }
        selectedRegency = regencies.find { it.code == "32.04" }
        selectedDistrict = districts.find { it.code == "32.04.05" }

        val newRegency = regencies.find { it.code == "32.01" }
        if (selectedRegency?.code != newRegency?.code) {
            selectedRegency = newRegency
            selectedDistrict = null
        }

        assertEquals("Kabupaten Bogor", selectedRegency?.name)
        assertNull(selectedDistrict)
    }

    @Test
    fun testSearchFiltering() {
        val districts = listOf(
            Region(code = "32.04.01", name = "Banjaran", level = "DISTRICT", parentCode = "32.04"),
            Region(code = "32.04.02", name = "Baleendah", level = "DISTRICT", parentCode = "32.04"),
            Region(code = "32.04.03", name = "Cangkuang", level = "DISTRICT", parentCode = "32.04"),
            Region(code = "32.04.04", name = "Bojongsoang", level = "DISTRICT", parentCode = "32.04")
        )

        // Case-insensitive search with "Ban"
        val query = "Ban"
        val results = districts.filter {
            it.name.contains(query, ignoreCase = true) || it.code.contains(query, ignoreCase = true)
        }

        assertEquals(1, results.size)
        assertEquals("Banjaran", results[0].name)

        // Search with "bo"
        val resultsBo = districts.filter {
            it.name.contains("bo", ignoreCase = true)
        }
        assertEquals(1, resultsBo.size)
        assertEquals("Bojongsoang", resultsBo[0].name)
    }

    @Test
    fun testCustomerModelAndBackwardCompatibility() {
        // New customer with full region fields
        val customer = Customer(
            customerId = "cust-1",
            customerCode = "CS-001",
            customerName = "Toko Atin Collection",
            phone = "08123456789",
            addressDetail = "Jl. Raya Banjaran No. 123",
            provinceCode = "32",
            provinceName = "Jawa Barat",
            regencyCode = "32.04",
            regencyName = "Kabupaten Bandung",
            districtCode = "32.04.05",
            districtName = "Banjaran",
            fullAddress = "Jl. Raya Banjaran No. 123, Kec. Banjaran, Kabupaten Bandung, Prov. Jawa Barat"
        )

        assertEquals("CS-001", customer.customerCode)
        assertEquals("Toko Atin Collection", customer.customerName)
        assertEquals("Jl. Raya Banjaran No. 123, Kec. Banjaran, Kabupaten Bandung, Prov. Jawa Barat", customer.displayAddress)

        // Legacy customer without separate region fields
        val legacyCustomer = Customer(
            customerId = "legacy-1",
            customerName = "Pelanggan Lama",
            phone = "089999999",
            fullAddress = "Alamat lama tanpa breakdown wilayah"
        )

        assertEquals("", legacyCustomer.customerCode)
        assertEquals("Alamat lama tanpa breakdown wilayah", legacyCustomer.displayAddress)
        assertEquals("Alamat lama tanpa breakdown wilayah", legacyCustomer.fullAddress)
    }

    @Test
    fun testRegionJsonParsing() {
        val sampleJson = """
            {
              "data": [
                {
                  "id": "32",
                  "name": "Jawa Barat"
                },
                {
                  "id": "33",
                  "name": "Jawa Tengah"
                }
              ]
            }
        """.trimIndent()

        val jsonObject = JSONObject(sampleJson)
        val dataArray = jsonObject.getJSONArray("data")
        val regions = mutableListOf<Region>()
        for (i in 0 until dataArray.length()) {
            val item = dataArray.getJSONObject(i)
            regions.add(
                Region(
                    code = item.getString("id"),
                    name = item.getString("name"),
                    level = "PROVINCE",
                    parentCode = null
                )
            )
        }

        assertEquals(2, regions.size)
        assertEquals("32", regions[0].code)
        assertEquals("Jawa Barat", regions[0].name)
        assertEquals("33", regions[1].code)
        assertEquals("Jawa Tengah", regions[1].name)
    }
}
