const functions = require("firebase-functions");
const admin = require("firebase-admin");

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();

// Secret name in Google Cloud Secret Manager
const SECRET_NAME = "RAJAONGKIR_API_KEY";

// Fallback constant only if neither Secret Manager nor env var is provided
const DEFAULT_FALLBACK_KEY = "KYr1MRBPb4a4667b8ed8a865DPqsFp5n";
const RAJAONGKIR_CALCULATE_URL = "https://rajaongkir.komerce.id/api/v1/calculate/domestic-cost";
const RAJAONGKIR_DESTINATION_URL = "https://rajaongkir.komerce.id/api/v1/destination/domestic-destination";

// Origin warehouse: Atin's Coll Banjaran, Bandung (ID 4997: BANJARAN KULON, BANJARAN, BANDUNG)
const DEFAULT_ORIGIN_ID = 4997;

/**
 * Lazily loads the Google Cloud Secret Manager client.
 */
let secretManagerClient = null;
function getSecretClient() {
  if (!secretManagerClient) {
    try {
      const { SecretManagerServiceClient } = require("@google-cloud/secret-manager");
      secretManagerClient = new SecretManagerServiceClient();
    } catch (e) {
      console.warn("[SecretManager] @google-cloud/secret-manager module not available in this environment");
    }
  }
  return secretManagerClient;
}

/**
 * Resolves the active RajaOngkir API Key:
 * 1. Cloud Secret Manager (projects/<PROJECT_ID>/secrets/RAJAONGKIR_API_KEY/versions/latest)
 * 2. Process environment variable (process.env.RAJAONGKIR_API_KEY)
 * 3. Default key
 */
async function getActiveRajaOngkirApiKey() {
  const client = getSecretClient();
  const projectId = process.env.GCP_PROJECT || process.env.GCLOUD_PROJECT || "gen-lang-client-0158803339";

  if (client) {
    try {
      const name = `projects/${projectId}/secrets/${SECRET_NAME}/versions/latest`;
      const [version] = await client.accessSecretVersion({ name });
      const payload = version.payload?.data?.toString("utf8");
      if (payload && payload.trim()) {
        return payload.trim();
      }
    } catch (e) {
      // Secret not found or permission not granted yet; proceed to env / fallback
    }
  }

  return process.env.RAJAONGKIR_API_KEY || process.env.KOMERCE_API_KEY || DEFAULT_FALLBACK_KEY;
}

/**
 * Verifies that the authenticated user has the ROOT_ADMIN role.
 */
async function assertRootAdmin(context) {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "User harus terautentikasi untuk mengakses fitur ini."
    );
  }

  const uid = context.auth.uid;
  // Check custom claims
  if (context.auth.token?.role === "Root Admin" || context.auth.token?.role === "ROOT_ADMIN") {
    return { uid, role: "ROOT_ADMIN" };
  }

  // Check Firestore users collection
  try {
    const userDoc = await db.collection("users").doc(uid).get();
    if (userDoc.exists) {
      const role = userDoc.data()?.role;
      if (role === "Root Admin" || role === "ROOT_ADMIN") {
        return { uid, role: "ROOT_ADMIN" };
      }
    }

    // Also check admin document by ID
    const adminDoc = await db.collection("users").doc("admin").get();
    if (adminDoc.exists && adminDoc.data()?.firebaseUid === uid) {
      return { uid, role: "ROOT_ADMIN" };
    }
  } catch (e) {
    console.error("[AuthCheck] Error checking user role:", e.message);
  }

  throw new functions.https.HttpsError(
    "permission-denied",
    "Akses ditolak: Hanya ROOT_ADMIN yang memiliki wewenang untuk mengubah atau menguji API Key."
  );
}

const ALLOWED_COURIERS = [
  {
    code: "wahana",
    displayName: "Wahana Ekonomis",
    matcher: (s, desc) => {
      const lower = s.toLowerCase();
      const lowerDesc = desc.toLowerCase();
      return lower.includes("ekonomis") || lower.includes("ekonomi") || lower.includes("hemat") ||
             lower.includes("express") || lowerDesc.includes("hemat");
    }
  },
  {
    code: "lion",
    displayName: "Lion Parcel JagoPack",
    matcher: (s, desc) => {
      const lower = s.toLowerCase();
      const lowerDesc = desc.toLowerCase();
      return lower.includes("jago") || lower.includes("jagopack") || lowerDesc.includes("jago");
    }
  },
  {
    code: "spx",
    displayName: "SPX Hemat",
    matcher: (s, desc) => {
      const lower = s.toLowerCase();
      const lowerDesc = desc.toLowerCase();
      return (lower.includes("hemat") || lowerDesc.includes("hemat")) && !lower.includes("standard") && !lower.includes("reguler");
    }
  },
  {
    code: "spx",
    displayName: "SPX Reguler (COD)",
    matcher: (s, desc) => {
      const lower = s.toLowerCase();
      const lowerDesc = desc.toLowerCase();
      return lower.includes("standard") || lower.includes("reguler") || lowerDesc.includes("standard") || lowerDesc.includes("reguler");
    }
  }
];

async function fetchDestinations(query, apiKey) {
  try {
    const res = await fetch(`${RAJAONGKIR_DESTINATION_URL}?search=${encodeURIComponent(query)}`, {
      headers: { "key": apiKey }
    });
    const data = await res.json();
    return Array.isArray(data?.data) ? data.data : [];
  } catch (e) {
    console.error("[ShippingAudit] Error fetching destinations from RajaOngkir:", e.message);
    return [];
  }
}

function normalizeRegion(str) {
  if (!str) return "";
  return String(str)
    .toLowerCase()
    .replace(/(kabupaten|kab\.|kota|adm\.|administrasi|kecamatan|kec\.|kelurahan|kel\.|desa|provinsi|prov\.)/gi, " ")
    .replace(/[,/\-_()]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function selectBestDestination(candidates, normDistrict, normRegency, normProvince) {
  let highestScore = -1;
  let best = null;

  for (const cand of candidates) {
    const candDistrict = normalizeRegion(cand.district_name);
    const candCity = normalizeRegion(cand.city_name);
    const candProvince = normalizeRegion(cand.province_name);

    let score = 0;
    let districtMatched = false;
    let regencyMatched = false;

    if (normDistrict && candDistrict) {
      if (candDistrict === normDistrict) {
        score += 100;
        districtMatched = true;
      } else if (candDistrict.includes(normDistrict) || normDistrict.includes(candDistrict)) {
        score += 70;
        districtMatched = true;
      }
    }

    if (normRegency && candCity) {
      if (candCity === normRegency) {
        score += 50;
        regencyMatched = true;
      } else if (candCity.includes(normRegency) || normRegency.includes(candCity)) {
        score += 35;
        regencyMatched = true;
      }
    }

    if (normProvince && candProvince) {
      if (candProvince === normProvince || candProvince.includes(normProvince) || normProvince.includes(candProvince)) {
        score += 25;
      }
    }

    if (cand.subdistrict_name && cand.subdistrict_name !== "-") {
      score += 5;
    }

    const minMatch = (normDistrict && districtMatched) || (normRegency && regencyMatched);
    if (minMatch && score > highestScore) {
      highestScore = score;
      best = cand;
    }
  }

  return best;
}

async function resolveDestinationId(destQuery, apiKey) {
  if (!destQuery) {
    throw new Error("Parameter 'destination' wajib diisi.");
  }
  const numericId = parseInt(destQuery, 10);
  if (!isNaN(numericId) && numericId > 0) {
    return numericId;
  }

  const rawQuery = String(destQuery).trim();
  const parts = rawQuery.split(",").map(p => p.trim()).filter(Boolean);

  let rawDistrict = "";
  let rawRegency = "";
  let rawProvince = "";

  if (parts.length >= 3) {
    rawDistrict = parts[0];
    rawRegency = parts[1];
    rawProvince = parts.slice(2).join(" ");
  } else if (parts.length === 2) {
    rawDistrict = parts[0];
    rawRegency = parts[1];
  } else if (parts.length === 1) {
    rawDistrict = parts[0];
  }

  const normDistrict = normalizeRegion(rawDistrict);
  const normRegency = normalizeRegion(rawRegency);
  const normProvince = normalizeRegion(rawProvince);

  const searchTiers = [];
  if (normDistrict && normRegency) searchTiers.push(`${normDistrict} ${normRegency}`);
  if (normDistrict && !searchTiers.includes(normDistrict)) searchTiers.push(normDistrict);
  if (normRegency && !searchTiers.includes(normRegency)) searchTiers.push(normRegency);

  const allCandidates = [];

  for (const tierQuery of searchTiers) {
    const list = await fetchDestinations(tierQuery, apiKey);
    if (list.length > 0) {
      allCandidates.push(...list);
      const match = selectBestDestination(list, normDistrict, normRegency, normProvince);
      if (match) {
        return match.id;
      }
    }
  }

  if (allCandidates.length > 0) {
    const best = selectBestDestination(allCandidates, normDistrict, normRegency, normProvince);
    if (best) return best.id;
  }

  // Fallback to cleaned token search
  const cleanTokens = normalizeRegion(rawQuery);
  if (cleanTokens) {
    const fallbackList = await fetchDestinations(cleanTokens, apiKey);
    if (fallbackList.length > 0) {
      const valid = fallbackList.find(c => c.subdistrict_name && c.subdistrict_name !== "-");
      return (valid || fallbackList[0]).id;
    }
  }

  throw new Error("Lokasi tujuan belum tersedia di RajaOngkir.");
}

async function resolveOriginId(originInput, apiKey) {
  if (!originInput || originInput === "Banjaran" || originInput === "DEFAULT") {
    return DEFAULT_ORIGIN_ID;
  }
  const numericId = parseInt(originInput, 10);
  if (!isNaN(numericId) && numericId > 0) {
    return numericId;
  }
  try {
    return await resolveDestinationId(originInput, apiKey);
  } catch (e) {
    return DEFAULT_ORIGIN_ID;
  }
}

async function computeShippingRates(originInput, destInput, weightInput) {
  if (!destInput) {
    throw new Error("Parameter 'destination' wajib diisi");
  }

  // Dynamically load current active API key from Secret Manager or env
  const apiKey = await getActiveRajaOngkirApiKey();

  const safeWeight = isNaN(weightInput) || weightInput <= 0 ? 1000 : parseInt(weightInput, 10);
  const originId = await resolveOriginId(originInput, apiKey);
  const destId = await resolveDestinationId(destInput, apiKey);

  const results = [];

  for (const courierConfig of ALLOWED_COURIERS) {
    const params = new URLSearchParams();
    params.append("origin", originId.toString());
    params.append("destination", destId.toString());
    params.append("weight", safeWeight.toString());
    params.append("courier", courierConfig.code);
    params.append("price", "lowest");

    try {
      const apiRes = await fetch(RAJAONGKIR_CALCULATE_URL, {
        method: "POST",
        headers: {
          "key": apiKey,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: params.toString()
      });

      const apiJson = await apiRes.json();
      const servicesList = apiJson?.data || [];

      const matchingServices = servicesList.filter(item =>
        courierConfig.matcher(item.service || "", item.description || "") && (parseInt(item.cost, 10) || 0) > 0
      );

      if (matchingServices.length > 0) {
        // Pick lowest cost among matching services
        matchingServices.sort((a, b) => (parseInt(a.cost, 10) || 0) - (parseInt(b.cost, 10) || 0));
        const matched = matchingServices[0];
        const costVal = parseInt(matched.cost, 10) || 0;
        results.push({
          courier: courierConfig.code,
          serviceCode: matched.service || courierConfig.code,
          serviceName: courierConfig.displayName,
          cost: costVal,
          etd: matched.etd ? matched.etd.replace("day", "hari").trim() : "-",
          isAvailable: costVal > 0
        });
      } else {
        results.push({
          courier: courierConfig.code,
          serviceCode: courierConfig.code,
          serviceName: courierConfig.displayName,
          cost: 0,
          etd: "-",
          isAvailable: false,
          message: "Layanan tidak tersedia untuk rute ini."
        });
      }
    } catch (courierErr) {
      results.push({
        courier: courierConfig.code,
        serviceCode: courierConfig.code,
        serviceName: courierConfig.displayName,
        cost: 0,
        etd: "-",
        isAvailable: false,
        message: "Layanan tidak tersedia: " + courierErr.message
      });
    }
  }

  return {
    success: true,
    originId,
    destinationId: destId,
    weight: safeWeight,
    services: results
  };
}

// -------------------------------------------------------------
// 1. Firebase Callable Function: calculateShippingCost
// -------------------------------------------------------------
exports.calculateShippingCost = functions.region("us-central1").https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "User harus terautentikasi untuk mengecek ongkir."
    );
  }

  try {
    const origin = data?.origin || "Banjaran";
    const destination = data?.destination;
    const weight = parseInt(data?.weight || "1000", 10);
    return await computeShippingRates(origin, destination, weight);
  } catch (err) {
    throw new functions.https.HttpsError("internal", err.message);
  }
});

// -------------------------------------------------------------
// 2. Firebase HTTPS Function: calculateShippingCostHttp
// -------------------------------------------------------------
exports.calculateShippingCostHttp = functions.region("us-central1").https.onRequest(async (req, res) => {
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    return res.status(204).send("");
  }

  try {
    const origin = req.body?.origin || req.query?.origin || "Banjaran";
    const destination = req.body?.destination || req.query?.destination;
    const weight = parseInt(req.body?.weight || req.query?.weight || "1000", 10);
    const result = await computeShippingRates(origin, destination, weight);
    return res.status(200).json(result);
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// -------------------------------------------------------------
// 3. Callable: testRajaOngkirApiKey (ROOT_ADMIN Only)
// Exactly 1 minimal hit to RajaOngkir to test candidate API key.
// Never logs or leaks the API Key.
// -------------------------------------------------------------
exports.testRajaOngkirApiKey = functions.region("us-central1").https.onCall(async (data, context) => {
  // Authorization check: ROOT_ADMIN only
  const { uid } = await assertRootAdmin(context);

  const testKey = data?.apiKey?.toString().trim();
  if (!testKey) {
    throw new functions.https.HttpsError("invalid-argument", "API Key wajib diisi.");
  }

  console.log(`[RajaOngkirTest] Testing candidate key by user: ${uid} (action: TEST_RAJAONGKIR_API_KEY)`);

  try {
    // Exactly 1 minimal hit to domestic destination search endpoint
    const url = `${RAJAONGKIR_DESTINATION_URL}?search=Banjaran`;
    const response = await fetch(url, {
      method: "GET",
      headers: { "key": testKey }
    });

    const status = response.status;
    const bodyText = await response.text();
    let bodyJson = null;
    try {
      bodyJson = JSON.parse(bodyText);
    } catch (_) {}

    const metaCode = bodyJson?.meta?.code || status;
    const metaStatus = bodyJson?.meta?.status || "";

    if (status === 200 && (metaCode === 200 || metaStatus === "success")) {
      return {
        valid: true,
        errorType: null,
        message: "API Key berhasil digunakan untuk mengakses RajaOngkir."
      };
    } else if (status === 401 || metaCode === 401 || metaCode === 400) {
      return {
        valid: false,
        errorType: "AUTH_INVALID",
        message: "RajaOngkir menolak API Key yang diberikan."
      };
    } else if (status === 403 || metaCode === 403) {
      return {
        valid: false,
        errorType: "FORBIDDEN",
        message: "Akses ditolak (Forbidden) oleh server RajaOngkir."
      };
    } else if (status === 429 || metaCode === 429) {
      return {
        valid: false,
        errorType: "RATE_LIMIT",
        message: "Batas kuota harian RajaOngkir telah tercapai."
      };
    } else if (status >= 500) {
      return {
        valid: false,
        errorType: "SERVER_ERROR",
        message: "Terjadi gangguan pada server RajaOngkir."
      };
    } else {
      return {
        valid: false,
        errorType: "UNKNOWN",
        message: `Response dari server: HTTP ${status}`
      };
    }
  } catch (err) {
    console.error("[RajaOngkirTest] Network error:", err.message);
    return {
      valid: false,
      errorType: "NETWORK_ERROR",
      message: "Tidak dapat terhubung ke server RajaOngkir."
    };
  }
});

// -------------------------------------------------------------
// 4. Callable: updateRajaOngkirApiKey (ROOT_ADMIN Only)
// Safely updates the backend Secret Manager. Never returns the secret.
// -------------------------------------------------------------
exports.updateRajaOngkirApiKey = functions.region("us-central1").https.onCall(async (data, context) => {
  // Authorization check: ROOT_ADMIN only
  const { uid } = await assertRootAdmin(context);

  const newKey = data?.apiKey?.toString().trim();
  if (!newKey) {
    throw new functions.https.HttpsError("invalid-argument", "API Key wajib diisi.");
  }

  console.log(`[RajaOngkirUpdate] Updating Secret Manager for user: ${uid}`);

  const client = getSecretClient();
  const projectId = process.env.GCP_PROJECT || process.env.GCLOUD_PROJECT || "gen-lang-client-0158803339";

  let secretSavedInSecretManager = false;

  if (client) {
    try {
      const parent = `projects/${projectId}`;
      const secretId = SECRET_NAME;

      // 1. Ensure secret exists, create if not
      try {
        await client.getSecret({ name: `${parent}/secrets/${secretId}` });
      } catch (getErr) {
        if (getErr.code === 5 || getErr.message.includes("NOT_FOUND")) {
          await client.createSecret({
            parent,
            secretId,
            secret: {
              replication: {
                automatic: {}
              }
            }
          });
        } else {
          throw getErr;
        }
      }

      // 2. Add secret version
      await client.addSecretVersion({
        parent: `${parent}/secrets/${secretId}`,
        payload: {
          data: Buffer.from(newKey, "utf8")
        }
      });

      secretSavedInSecretManager = true;
      console.log(`[RajaOngkirUpdate] Successfully stored new secret version in Secret Manager.`);
    } catch (e) {
      console.warn(`[RajaOngkirUpdate] Secret Manager operation failed or permission not granted: ${e.message}`);
    }
  }

  // Record audit log entry in Firestore (metadata only, NO secret)
  try {
    await db.collection("audit_trails").add({
      action: "UPDATE_RAJAONGKIR_API_KEY",
      userId: uid,
      role: "ROOT_ADMIN",
      result: "SUCCESS",
      secretManagerUpdated: secretSavedInSecretManager,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
  } catch (auditErr) {
    console.error("[RajaOngkirUpdate] Error recording audit trail:", auditErr.message);
  }

  return {
    success: true,
    secretManagerUpdated: secretSavedInSecretManager,
    message: "API Key berhasil diperbarui."
  };
});
